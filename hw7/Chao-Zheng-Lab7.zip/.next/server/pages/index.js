/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "__barrel_optimize__?names=Box,Button,Card,CardContent,Grid,Typography!=!./node_modules/@mui/material/index.js":
/*!*********************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Box,Button,Card,CardContent,Grid,Typography!=!./node_modules/@mui/material/index.js ***!
  \*********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Box: () => (/* reexport default from dynamic */ _Box__WEBPACK_IMPORTED_MODULE_0___default.a),\n/* harmony export */   Button: () => (/* reexport default from dynamic */ _Button__WEBPACK_IMPORTED_MODULE_1___default.a),\n/* harmony export */   Card: () => (/* reexport default from dynamic */ _Card__WEBPACK_IMPORTED_MODULE_2___default.a),\n/* harmony export */   CardContent: () => (/* reexport default from dynamic */ _CardContent__WEBPACK_IMPORTED_MODULE_3___default.a),\n/* harmony export */   Grid: () => (/* reexport default from dynamic */ _Grid__WEBPACK_IMPORTED_MODULE_4___default.a),\n/* harmony export */   Typography: () => (/* reexport default from dynamic */ _Typography__WEBPACK_IMPORTED_MODULE_5___default.a)\n/* harmony export */ });\n/* harmony import */ var _Box__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Box */ \"./node_modules/@mui/material/node/Box/index.js\");\n/* harmony import */ var _Box__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Box__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ \"./node_modules/@mui/material/node/Button/index.js\");\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Button__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Card */ \"./node_modules/@mui/material/node/Card/index.js\");\n/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Card__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _CardContent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CardContent */ \"./node_modules/@mui/material/node/CardContent/index.js\");\n/* harmony import */ var _CardContent__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_CardContent__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _Grid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Grid */ \"./node_modules/@mui/material/node/Grid/index.js\");\n/* harmony import */ var _Grid__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Grid__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Typography */ \"./node_modules/@mui/material/node/Typography/index.js\");\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_Typography__WEBPACK_IMPORTED_MODULE_5__);\n\n\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1Cb3gsQnV0dG9uLENhcmQsQ2FyZENvbnRlbnQsR3JpZCxUeXBvZ3JhcGh5IT0hLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ3NDO0FBQ007QUFDSjtBQUNjO0FBQ2QiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vbm9kZV9tb2R1bGVzL0BtdWkvbWF0ZXJpYWwvaW5kZXguanM/OGRhMCJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQm94IH0gZnJvbSBcIi4vQm94XCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQnV0dG9uIH0gZnJvbSBcIi4vQnV0dG9uXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQ2FyZCB9IGZyb20gXCIuL0NhcmRcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBDYXJkQ29udGVudCB9IGZyb20gXCIuL0NhcmRDb250ZW50XCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgR3JpZCB9IGZyb20gXCIuL0dyaWRcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBUeXBvZ3JhcGh5IH0gZnJvbSBcIi4vVHlwb2dyYXBoeVwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Box,Button,Card,CardContent,Grid,Typography!=!./node_modules/@mui/material/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Breadcrumbs,Typography!=!./node_modules/@mui/material/index.js":
/*!************************************************************************************************!*\
  !*** __barrel_optimize__?names=Breadcrumbs,Typography!=!./node_modules/@mui/material/index.js ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Breadcrumbs: () => (/* reexport default from dynamic */ _Breadcrumbs__WEBPACK_IMPORTED_MODULE_0___default.a),\n/* harmony export */   Typography: () => (/* reexport default from dynamic */ _Typography__WEBPACK_IMPORTED_MODULE_1___default.a)\n/* harmony export */ });\n/* harmony import */ var _Breadcrumbs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Breadcrumbs */ \"./node_modules/@mui/material/node/Breadcrumbs/index.js\");\n/* harmony import */ var _Breadcrumbs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Breadcrumbs__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Typography */ \"./node_modules/@mui/material/node/Typography/index.js\");\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Typography__WEBPACK_IMPORTED_MODULE_1__);\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1CcmVhZGNydW1icyxUeXBvZ3JhcGh5IT0hLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQ3NEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbGFiNy8uL25vZGVfbW9kdWxlcy9AbXVpL21hdGVyaWFsL2luZGV4LmpzP2IyM2QiXSwic291cmNlc0NvbnRlbnQiOlsiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEJyZWFkY3J1bWJzIH0gZnJvbSBcIi4vQnJlYWRjcnVtYnNcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBUeXBvZ3JhcGh5IH0gZnJvbSBcIi4vVHlwb2dyYXBoeVwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Breadcrumbs,Typography!=!./node_modules/@mui/material/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!./node_modules/@mui/material/index.js":
/*!***************************************************************************************************!*\
  !*** __barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!./node_modules/@mui/material/index.js ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Fab: () => (/* reexport default from dynamic */ _Fab__WEBPACK_IMPORTED_MODULE_0___default.a),\n/* harmony export */   Zoom: () => (/* reexport safe */ _Zoom__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   useScrollTrigger: () => (/* reexport safe */ _useScrollTrigger__WEBPACK_IMPORTED_MODULE_2__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Fab__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Fab */ \"./node_modules/@mui/material/node/Fab/index.js\");\n/* harmony import */ var _Fab__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Fab__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Zoom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Zoom */ \"./node_modules/@mui/material/node/Zoom/index.js\");\n/* harmony import */ var _useScrollTrigger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useScrollTrigger */ \"./node_modules/@mui/material/node/useScrollTrigger/index.js\");\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1GYWIsWm9vbSx1c2VTY3JvbGxUcmlnZ2VyIT0hLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUNzQztBQUNFIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbGFiNy8uL25vZGVfbW9kdWxlcy9AbXVpL21hdGVyaWFsL2luZGV4LmpzP2JiZDQiXSwic291cmNlc0NvbnRlbnQiOlsiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEZhYiB9IGZyb20gXCIuL0ZhYlwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIFpvb20gfSBmcm9tIFwiLi9ab29tXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgdXNlU2Nyb2xsVHJpZ2dlciB9IGZyb20gXCIuL3VzZVNjcm9sbFRyaWdnZXJcIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!./node_modules/@mui/material/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=HiMenu!=!./node_modules/react-icons/hi/index.mjs":
/*!**********************************************************************************!*\
  !*** __barrel_optimize__?names=HiMenu!=!./node_modules/react-icons/hi/index.mjs ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var E_CS_554_hw_hw7_node_modules_react_icons_hi_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/react-icons/hi/index.mjs */ "./node_modules/react-icons/hi/index.mjs");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in E_CS_554_hw_hw7_node_modules_react_icons_hi_index_mjs__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => E_CS_554_hw_hw7_node_modules_react_icons_hi_index_mjs__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "./public/img/logo.jpg":
/*!*****************************!*\
  !*** ./public/img/logo.jpg ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({\"src\":\"/_next/static/media/logo.e29ae997.jpg\",\"height\":160,\"width\":1280,\"blurDataURL\":\"/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Flogo.e29ae997.jpg&w=8&q=70\",\"blurWidth\":8,\"blurHeight\":1});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wdWJsaWMvaW1nL2xvZ28uanBnIiwibWFwcGluZ3MiOiI7Ozs7QUFBQSxpRUFBZSxDQUFDLDZMQUE2TCIsInNvdXJjZXMiOlsid2VicGFjazovL2xhYjcvLi9wdWJsaWMvaW1nL2xvZ28uanBnPzM5NDIiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL21lZGlhL2xvZ28uZTI5YWU5OTcuanBnXCIsXCJoZWlnaHRcIjoxNjAsXCJ3aWR0aFwiOjEyODAsXCJibHVyRGF0YVVSTFwiOlwiL19uZXh0L2ltYWdlP3VybD0lMkZfbmV4dCUyRnN0YXRpYyUyRm1lZGlhJTJGbG9nby5lMjlhZTk5Ny5qcGcmdz04JnE9NzBcIixcImJsdXJXaWR0aFwiOjgsXCJibHVySGVpZ2h0XCI6MX07Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./public/img/logo.jpg\n");

/***/ }),

/***/ "./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.jsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!":
/*!******************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.jsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D! ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),\n/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),\n/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),\n/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),\n/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),\n/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),\n/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages/module.compiled */ \"./node_modules/next/dist/server/future/route-modules/pages/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! private-next-pages/_document */ \"./pages/_document.jsx\");\n/* harmony import */ var private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! private-next-pages/_app */ \"./pages/_app.jsx\");\n/* harmony import */ var _pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages\\index.jsx */ \"./pages/index.jsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__, _pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__]);\n([private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__, _pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n// Import the app and document modules.\n\n\n// Import the userland code.\n\n// Re-export the component (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__, \"default\"));\n// Re-export methods.\nconst getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__, \"getStaticProps\");\nconst getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__, \"getStaticPaths\");\nconst getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__, \"getServerSideProps\");\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__, \"config\");\nconst reportWebVitals = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__, \"reportWebVitals\");\n// Re-export legacy methods.\nconst unstable_getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticProps\");\nconst unstable_getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticPaths\");\nconst unstable_getStaticParams = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticParams\");\nconst unstable_getServerProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getServerProps\");\nconst unstable_getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getServerSideProps\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES,\n        page: \"/index\",\n        pathname: \"/\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    components: {\n        App: private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n        Document: private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n    },\n    userland: _pages_index_jsx__WEBPACK_IMPORTED_MODULE_5__\n});\n\n//# sourceMappingURL=pages.js.map\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTJnBhZ2U9JTJGJnByZWZlcnJlZFJlZ2lvbj0mYWJzb2x1dGVQYWdlUGF0aD0uJTJGcGFnZXMlNUNpbmRleC5qc3gmYWJzb2x1dGVBcHBQYXRoPXByaXZhdGUtbmV4dC1wYWdlcyUyRl9hcHAmYWJzb2x1dGVEb2N1bWVudFBhdGg9cHJpdmF0ZS1uZXh0LXBhZ2VzJTJGX2RvY3VtZW50Jm1pZGRsZXdhcmVDb25maWdCYXNlNjQ9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQStGO0FBQ2hDO0FBQ0w7QUFDMUQ7QUFDb0Q7QUFDVjtBQUMxQztBQUMrQztBQUMvQztBQUNBLGlFQUFlLHdFQUFLLENBQUMsNkNBQVEsWUFBWSxFQUFDO0FBQzFDO0FBQ08sdUJBQXVCLHdFQUFLLENBQUMsNkNBQVE7QUFDckMsdUJBQXVCLHdFQUFLLENBQUMsNkNBQVE7QUFDckMsMkJBQTJCLHdFQUFLLENBQUMsNkNBQVE7QUFDekMsZUFBZSx3RUFBSyxDQUFDLDZDQUFRO0FBQzdCLHdCQUF3Qix3RUFBSyxDQUFDLDZDQUFRO0FBQzdDO0FBQ08sZ0NBQWdDLHdFQUFLLENBQUMsNkNBQVE7QUFDOUMsZ0NBQWdDLHdFQUFLLENBQUMsNkNBQVE7QUFDOUMsaUNBQWlDLHdFQUFLLENBQUMsNkNBQVE7QUFDL0MsZ0NBQWdDLHdFQUFLLENBQUMsNkNBQVE7QUFDOUMsb0NBQW9DLHdFQUFLLENBQUMsNkNBQVE7QUFDekQ7QUFDTyx3QkFBd0IseUdBQWdCO0FBQy9DO0FBQ0EsY0FBYyx5RUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsV0FBVztBQUNYLGdCQUFnQjtBQUNoQixLQUFLO0FBQ0wsWUFBWTtBQUNaLENBQUM7O0FBRUQsaUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Lz81ZjQ2Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBhZ2VzUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUtbW9kdWxlcy9wYWdlcy9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1raW5kXCI7XG5pbXBvcnQgeyBob2lzdCB9IGZyb20gXCJuZXh0L2Rpc3QvYnVpbGQvdGVtcGxhdGVzL2hlbHBlcnNcIjtcbi8vIEltcG9ydCB0aGUgYXBwIGFuZCBkb2N1bWVudCBtb2R1bGVzLlxuaW1wb3J0IERvY3VtZW50IGZyb20gXCJwcml2YXRlLW5leHQtcGFnZXMvX2RvY3VtZW50XCI7XG5pbXBvcnQgQXBwIGZyb20gXCJwcml2YXRlLW5leHQtcGFnZXMvX2FwcFwiO1xuLy8gSW1wb3J0IHRoZSB1c2VybGFuZCBjb2RlLlxuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIi4vcGFnZXNcXFxcaW5kZXguanN4XCI7XG4vLyBSZS1leHBvcnQgdGhlIGNvbXBvbmVudCAoc2hvdWxkIGJlIHRoZSBkZWZhdWx0IGV4cG9ydCkuXG5leHBvcnQgZGVmYXVsdCBob2lzdCh1c2VybGFuZCwgXCJkZWZhdWx0XCIpO1xuLy8gUmUtZXhwb3J0IG1ldGhvZHMuXG5leHBvcnQgY29uc3QgZ2V0U3RhdGljUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgXCJnZXRTdGF0aWNQcm9wc1wiKTtcbmV4cG9ydCBjb25zdCBnZXRTdGF0aWNQYXRocyA9IGhvaXN0KHVzZXJsYW5kLCBcImdldFN0YXRpY1BhdGhzXCIpO1xuZXhwb3J0IGNvbnN0IGdldFNlcnZlclNpZGVQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCBcImdldFNlcnZlclNpZGVQcm9wc1wiKTtcbmV4cG9ydCBjb25zdCBjb25maWcgPSBob2lzdCh1c2VybGFuZCwgXCJjb25maWdcIik7XG5leHBvcnQgY29uc3QgcmVwb3J0V2ViVml0YWxzID0gaG9pc3QodXNlcmxhbmQsIFwicmVwb3J0V2ViVml0YWxzXCIpO1xuLy8gUmUtZXhwb3J0IGxlZ2FjeSBtZXRob2RzLlxuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1Byb3BzID0gaG9pc3QodXNlcmxhbmQsIFwidW5zdGFibGVfZ2V0U3RhdGljUHJvcHNcIik7XG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U3RhdGljUGF0aHMgPSBob2lzdCh1c2VybGFuZCwgXCJ1bnN0YWJsZV9nZXRTdGF0aWNQYXRoc1wiKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTdGF0aWNQYXJhbXMgPSBob2lzdCh1c2VybGFuZCwgXCJ1bnN0YWJsZV9nZXRTdGF0aWNQYXJhbXNcIik7XG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U2VydmVyUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgXCJ1bnN0YWJsZV9nZXRTZXJ2ZXJQcm9wc1wiKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTZXJ2ZXJTaWRlUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgXCJ1bnN0YWJsZV9nZXRTZXJ2ZXJTaWRlUHJvcHNcIik7XG4vLyBDcmVhdGUgYW5kIGV4cG9ydCB0aGUgcm91dGUgbW9kdWxlIHRoYXQgd2lsbCBiZSBjb25zdW1lZC5cbmV4cG9ydCBjb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBQYWdlc1JvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5QQUdFUyxcbiAgICAgICAgcGFnZTogXCIvaW5kZXhcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL1wiLFxuICAgICAgICAvLyBUaGUgZm9sbG93aW5nIGFyZW4ndCB1c2VkIGluIHByb2R1Y3Rpb24uXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcIlwiXG4gICAgfSxcbiAgICBjb21wb25lbnRzOiB7XG4gICAgICAgIEFwcCxcbiAgICAgICAgRG9jdW1lbnRcbiAgICB9LFxuICAgIHVzZXJsYW5kXG59KTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFnZXMuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.jsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "./components/backToTop.jsx":
/*!**********************************!*\
  !*** ./components/backToTop.jsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!@mui/material */ \"__barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var _mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/icons-material/ArrowUpward */ \"@mui/icons-material/ArrowUpward\");\n/* harmony import */ var _mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1__);\n\n\n\nconst BackToTopButton = ({ threshold = 100, bottom = \"2rem\", right = \"2rem\", color = \"secondary\", size = \"small\" })=>{\n    const trigger = (0,_barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__.useScrollTrigger)({\n        disableHysteresis: true,\n        threshold: threshold\n    });\n    const handleClick = ()=>{\n        window.scrollTo({\n            top: 0,\n            behavior: \"smooth\"\n        });\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__.Zoom, {\n        in: trigger,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__.Fab, {\n            color: color,\n            size: size,\n            onClick: handleClick,\n            sx: {\n                position: \"fixed\",\n                bottom: bottom,\n                right: right\n            },\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1___default()), {}, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backToTop.jsx\",\n                lineNumber: 35,\n                columnNumber: 17\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backToTop.jsx\",\n            lineNumber: 25,\n            columnNumber: 13\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backToTop.jsx\",\n        lineNumber: 24,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BackToTopButton);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL2JhY2tUb1RvcC5qc3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUE0RDtBQUNFO0FBRTlELE1BQU1JLGtCQUFrQixDQUFDLEVBQ0lDLFlBQVksR0FBRyxFQUNmQyxTQUFTLE1BQU0sRUFDZkMsUUFBUSxNQUFNLEVBQ2RDLFFBQVEsV0FBVyxFQUNuQkMsT0FBTyxPQUFPLEVBQ2pCO0lBQ3RCLE1BQU1DLFVBQVVULCtHQUFnQkEsQ0FBQztRQUM3QlUsbUJBQW1CO1FBQ25CTixXQUFXQTtJQUNmO0lBRUEsTUFBTU8sY0FBYztRQUNoQkMsT0FBT0MsUUFBUSxDQUFDO1lBQ1pDLEtBQUs7WUFDTEMsVUFBVTtRQUNkO0lBQ0o7SUFFQSxxQkFDSSw4REFBQ2QsK0ZBQUlBO1FBQUNlLElBQUlQO2tCQUNOLDRFQUFDViw4RkFBR0E7WUFDQVEsT0FBT0E7WUFDUEMsTUFBTUE7WUFDTlMsU0FBU047WUFDVE8sSUFBSTtnQkFDQUMsVUFBVTtnQkFDVmQsUUFBUUE7Z0JBQ1JDLE9BQU9BO1lBQ1g7c0JBRUEsNEVBQUNKLHdFQUFlQTs7Ozs7Ozs7Ozs7Ozs7O0FBSWhDO0FBRUEsaUVBQWVDLGVBQWVBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vY29tcG9uZW50cy9iYWNrVG9Ub3AuanN4PzRiYTkiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRmFiLCB1c2VTY3JvbGxUcmlnZ2VyLCBab29tIH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XHJcbmltcG9ydCBBcnJvd1Vwd2FyZEljb24gZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9BcnJvd1Vwd2FyZCc7XHJcblxyXG5jb25zdCBCYWNrVG9Ub3BCdXR0b24gPSAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocmVzaG9sZCA9IDEwMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b20gPSAnMnJlbScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHQgPSAnMnJlbScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3IgPSAnc2Vjb25kYXJ5JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplID0gJ3NtYWxsJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgfSkgPT4ge1xyXG4gICAgY29uc3QgdHJpZ2dlciA9IHVzZVNjcm9sbFRyaWdnZXIoe1xyXG4gICAgICAgIGRpc2FibGVIeXN0ZXJlc2lzOiB0cnVlLFxyXG4gICAgICAgIHRocmVzaG9sZDogdGhyZXNob2xkLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoKSA9PiB7XHJcbiAgICAgICAgd2luZG93LnNjcm9sbFRvKHtcclxuICAgICAgICAgICAgdG9wOiAwLFxyXG4gICAgICAgICAgICBiZWhhdmlvcjogJ3Ntb290aCcsXHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFpvb20gaW49e3RyaWdnZXJ9PlxyXG4gICAgICAgICAgICA8RmFiXHJcbiAgICAgICAgICAgICAgICBjb2xvcj17Y29sb3J9XHJcbiAgICAgICAgICAgICAgICBzaXplPXtzaXplfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xpY2t9XHJcbiAgICAgICAgICAgICAgICBzeD17e1xyXG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvdHRvbTogYm90dG9tLFxyXG4gICAgICAgICAgICAgICAgICAgIHJpZ2h0OiByaWdodCxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxBcnJvd1Vwd2FyZEljb24gLz5cclxuICAgICAgICAgICAgPC9GYWI+XHJcbiAgICAgICAgPC9ab29tPlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJhY2tUb1RvcEJ1dHRvbjtcclxuIl0sIm5hbWVzIjpbIkZhYiIsInVzZVNjcm9sbFRyaWdnZXIiLCJab29tIiwiQXJyb3dVcHdhcmRJY29uIiwiQmFja1RvVG9wQnV0dG9uIiwidGhyZXNob2xkIiwiYm90dG9tIiwicmlnaHQiLCJjb2xvciIsInNpemUiLCJ0cmlnZ2VyIiwiZGlzYWJsZUh5c3RlcmVzaXMiLCJoYW5kbGVDbGljayIsIndpbmRvdyIsInNjcm9sbFRvIiwidG9wIiwiYmVoYXZpb3IiLCJpbiIsIm9uQ2xpY2siLCJzeCIsInBvc2l0aW9uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/backToTop.jsx\n");

/***/ }),

/***/ "./components/backTotop.jsx":
/*!**********************************!*\
  !*** ./components/backTotop.jsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!@mui/material */ \"__barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var _mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/icons-material/ArrowUpward */ \"@mui/icons-material/ArrowUpward\");\n/* harmony import */ var _mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1__);\n\n\n\nconst BackToTopButton = ({ threshold = 100, bottom = \"2rem\", right = \"2rem\", color = \"secondary\", size = \"small\" })=>{\n    const trigger = (0,_barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__.useScrollTrigger)({\n        disableHysteresis: true,\n        threshold: threshold\n    });\n    const handleClick = ()=>{\n        window.scrollTo({\n            top: 0,\n            behavior: \"smooth\"\n        });\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__.Zoom, {\n        in: trigger,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__.Fab, {\n            color: color,\n            size: size,\n            onClick: handleClick,\n            sx: {\n                position: \"fixed\",\n                bottom: bottom,\n                right: right\n            },\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1___default()), {}, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backTotop.jsx\",\n                lineNumber: 35,\n                columnNumber: 17\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backTotop.jsx\",\n            lineNumber: 25,\n            columnNumber: 13\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backTotop.jsx\",\n        lineNumber: 24,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BackToTopButton);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL2JhY2tUb3RvcC5qc3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUE0RDtBQUNFO0FBRTlELE1BQU1JLGtCQUFrQixDQUFDLEVBQ0lDLFlBQVksR0FBRyxFQUNmQyxTQUFTLE1BQU0sRUFDZkMsUUFBUSxNQUFNLEVBQ2RDLFFBQVEsV0FBVyxFQUNuQkMsT0FBTyxPQUFPLEVBQ2pCO0lBQ3RCLE1BQU1DLFVBQVVULCtHQUFnQkEsQ0FBQztRQUM3QlUsbUJBQW1CO1FBQ25CTixXQUFXQTtJQUNmO0lBRUEsTUFBTU8sY0FBYztRQUNoQkMsT0FBT0MsUUFBUSxDQUFDO1lBQ1pDLEtBQUs7WUFDTEMsVUFBVTtRQUNkO0lBQ0o7SUFFQSxxQkFDSSw4REFBQ2QsK0ZBQUlBO1FBQUNlLElBQUlQO2tCQUNOLDRFQUFDViw4RkFBR0E7WUFDQVEsT0FBT0E7WUFDUEMsTUFBTUE7WUFDTlMsU0FBU047WUFDVE8sSUFBSTtnQkFDQUMsVUFBVTtnQkFDVmQsUUFBUUE7Z0JBQ1JDLE9BQU9BO1lBQ1g7c0JBRUEsNEVBQUNKLHdFQUFlQTs7Ozs7Ozs7Ozs7Ozs7O0FBSWhDO0FBRUEsaUVBQWVDLGVBQWVBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vY29tcG9uZW50cy9iYWNrVG90b3AuanN4PzNkMDgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRmFiLCB1c2VTY3JvbGxUcmlnZ2VyLCBab29tIH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XHJcbmltcG9ydCBBcnJvd1Vwd2FyZEljb24gZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9BcnJvd1Vwd2FyZCc7XHJcblxyXG5jb25zdCBCYWNrVG9Ub3BCdXR0b24gPSAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocmVzaG9sZCA9IDEwMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b20gPSAnMnJlbScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHQgPSAnMnJlbScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3IgPSAnc2Vjb25kYXJ5JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplID0gJ3NtYWxsJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgfSkgPT4ge1xyXG4gICAgY29uc3QgdHJpZ2dlciA9IHVzZVNjcm9sbFRyaWdnZXIoe1xyXG4gICAgICAgIGRpc2FibGVIeXN0ZXJlc2lzOiB0cnVlLFxyXG4gICAgICAgIHRocmVzaG9sZDogdGhyZXNob2xkLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoKSA9PiB7XHJcbiAgICAgICAgd2luZG93LnNjcm9sbFRvKHtcclxuICAgICAgICAgICAgdG9wOiAwLFxyXG4gICAgICAgICAgICBiZWhhdmlvcjogJ3Ntb290aCcsXHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFpvb20gaW49e3RyaWdnZXJ9PlxyXG4gICAgICAgICAgICA8RmFiXHJcbiAgICAgICAgICAgICAgICBjb2xvcj17Y29sb3J9XHJcbiAgICAgICAgICAgICAgICBzaXplPXtzaXplfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xpY2t9XHJcbiAgICAgICAgICAgICAgICBzeD17e1xyXG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvdHRvbTogYm90dG9tLFxyXG4gICAgICAgICAgICAgICAgICAgIHJpZ2h0OiByaWdodCxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxBcnJvd1Vwd2FyZEljb24gLz5cclxuICAgICAgICAgICAgPC9GYWI+XHJcbiAgICAgICAgPC9ab29tPlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJhY2tUb1RvcEJ1dHRvbjtcclxuIl0sIm5hbWVzIjpbIkZhYiIsInVzZVNjcm9sbFRyaWdnZXIiLCJab29tIiwiQXJyb3dVcHdhcmRJY29uIiwiQmFja1RvVG9wQnV0dG9uIiwidGhyZXNob2xkIiwiYm90dG9tIiwicmlnaHQiLCJjb2xvciIsInNpemUiLCJ0cmlnZ2VyIiwiZGlzYWJsZUh5c3RlcmVzaXMiLCJoYW5kbGVDbGljayIsIndpbmRvdyIsInNjcm9sbFRvIiwidG9wIiwiYmVoYXZpb3IiLCJpbiIsIm9uQ2xpY2siLCJzeCIsInBvc2l0aW9uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/backTotop.jsx\n");

/***/ }),

/***/ "./components/backgroundOverlay.jsx":
/*!******************************************!*\
  !*** ./components/backgroundOverlay.jsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst BackgroundOverlay = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"fixed inset-0 pointer-events-none z-[-1]\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"absolute inset-0 bg-gradient-to-r from-blue-500 to-pink-500 opacity-75\"\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backgroundOverlay.jsx\",\n                lineNumber: 6,\n                columnNumber: 13\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"absolute inset-0 \"\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backgroundOverlay.jsx\",\n                lineNumber: 7,\n                columnNumber: 13\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backgroundOverlay.jsx\",\n        lineNumber: 5,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BackgroundOverlay);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL2JhY2tncm91bmRPdmVybGF5LmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBMEI7QUFFMUIsTUFBTUMsb0JBQW9CO0lBQ3RCLHFCQUNJLDhEQUFDQztRQUFJQyxXQUFVOzswQkFDWCw4REFBQ0Q7Z0JBQUlDLFdBQVU7Ozs7OzswQkFDZiw4REFBQ0Q7Z0JBQUlDLFdBQVU7Ozs7Ozs7Ozs7OztBQUczQjtBQUVBLGlFQUFlRixpQkFBaUJBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vY29tcG9uZW50cy9iYWNrZ3JvdW5kT3ZlcmxheS5qc3g/NTFjOSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuY29uc3QgQmFja2dyb3VuZE92ZXJsYXkgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBwb2ludGVyLWV2ZW50cy1ub25lIHotWy0xXVwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAwIHRvLXBpbmstNTAwIG9wYWNpdHktNzVcIj48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIFwiPjwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJhY2tncm91bmRPdmVybGF5O1xyXG4iXSwibmFtZXMiOlsiUmVhY3QiLCJCYWNrZ3JvdW5kT3ZlcmxheSIsImRpdiIsImNsYXNzTmFtZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/backgroundOverlay.jsx\n");

/***/ }),

/***/ "./components/breadCrumbs.jsx":
/*!************************************!*\
  !*** ./components/breadCrumbs.jsx ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _barrel_optimize_names_Breadcrumbs_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! __barrel_optimize__?names=Breadcrumbs,Typography!=!@mui/material */ \"__barrel_optimize__?names=Breadcrumbs,Typography!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var _mui_icons_material_NavigateNext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/NavigateNext */ \"@mui/icons-material/NavigateNext\");\n/* harmony import */ var _mui_icons_material_NavigateNext__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_NavigateNext__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\n\nfunction GetBreadcrumbs() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();\n    const path = router.asPath.split(\"/\").filter((x)=>x && x !== \"page\" && !x.startsWith(\"0\"));\n    function capitalizeFirstLetter(string) {\n        return string.charAt(0).toUpperCase() + string.slice(1);\n    }\n    function isListRoute(segment) {\n        const listRoutes = [\n            \"launches\",\n            \"payloads\",\n            \"cores\",\n            \"rockets\",\n            \"ships\",\n            \"launchpads\"\n        ];\n        return listRoutes.includes(segment.toLowerCase());\n    }\n    function isNonClickableListRoute(segment, index) {\n        if (!isListRoute(segment)) return false;\n        let checkRoute = `/${path.slice(0, index + 1).join(\"/\")}/page/0`;\n        return router.asPath.toLowerCase().startsWith(checkRoute.toLowerCase());\n    }\n    const breadcrumbs = path.map((segment, index)=>{\n        const isLast = index === path.length - 1;\n        let routeTo = `/${path.slice(0, index + 1).join(\"/\")}`;\n        if (isListRoute(segment) && !isLast) {\n            routeTo += \"/page/0\";\n        }\n        const isNonClickable = isNonClickableListRoute(segment, index);\n        return {\n            name: segment,\n            routeTo,\n            isLast,\n            clickable: !isNonClickable\n        };\n    });\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Breadcrumbs_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Breadcrumbs, {\n        \"aria-label\": \"breadcrumb\",\n        separator: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_icons_material_NavigateNext__WEBPACK_IMPORTED_MODULE_2___default()), {\n            fontSize: \"small\"\n        }, void 0, false, {\n            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\breadCrumbs.jsx\",\n            lineNumber: 45,\n            columnNumber: 57\n        }, void 0),\n        sx: {\n            mb: 2\n        },\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {\n                href: \"/\",\n                passHref: true,\n                children: \"Home\"\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\breadCrumbs.jsx\",\n                lineNumber: 46,\n                columnNumber: 13\n            }, this),\n            breadcrumbs.map(({ name, routeTo, isLast, clickable }, index)=>{\n                const displayText = capitalizeFirstLetter(name);\n                if (!isLast && clickable) {\n                    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        href: routeTo,\n                        passHref: true,\n                        children: displayText\n                    }, index, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\breadCrumbs.jsx\",\n                        lineNumber: 53,\n                        columnNumber: 25\n                    }, this);\n                }\n                return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Breadcrumbs_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {\n                    color: \"text.primary\",\n                    children: displayText\n                }, index, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\breadCrumbs.jsx\",\n                    lineNumber: 60,\n                    columnNumber: 21\n                }, this);\n            })\n        ]\n    }, void 0, true, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\breadCrumbs.jsx\",\n        lineNumber: 45,\n        columnNumber: 9\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GetBreadcrumbs);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL2JyZWFkQ3J1bWJzLmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQTBCO0FBQzhCO0FBQ1E7QUFDbkM7QUFDVztBQUV4QyxTQUFTTTtJQUNMLE1BQU1DLFNBQVNGLHNEQUFTQTtJQUN4QixNQUFNRyxPQUFPRCxPQUFPRSxNQUFNLENBQUNDLEtBQUssQ0FBQyxLQUFLQyxNQUFNLENBQUNDLENBQUFBLElBQUtBLEtBQUtBLE1BQU0sVUFBVSxDQUFDQSxFQUFFQyxVQUFVLENBQUM7SUFFckYsU0FBU0Msc0JBQXNCQyxNQUFNO1FBQ2pDLE9BQU9BLE9BQU9DLE1BQU0sQ0FBQyxHQUFHQyxXQUFXLEtBQUtGLE9BQU9HLEtBQUssQ0FBQztJQUN6RDtJQUVBLFNBQVNDLFlBQVlDLE9BQU87UUFDeEIsTUFBTUMsYUFBYTtZQUFDO1lBQVk7WUFBWTtZQUFTO1lBQVc7WUFBUztTQUFhO1FBQ3RGLE9BQU9BLFdBQVdDLFFBQVEsQ0FBQ0YsUUFBUUcsV0FBVztJQUNsRDtJQUVBLFNBQVNDLHdCQUF3QkosT0FBTyxFQUFFSyxLQUFLO1FBQzNDLElBQUksQ0FBQ04sWUFBWUMsVUFBVSxPQUFPO1FBQ2xDLElBQUlNLGFBQWEsQ0FBQyxDQUFDLEVBQUVsQixLQUFLVSxLQUFLLENBQUMsR0FBR08sUUFBUSxHQUFHRSxJQUFJLENBQUMsS0FBSyxPQUFPLENBQUM7UUFDaEUsT0FBT3BCLE9BQU9FLE1BQU0sQ0FBQ2MsV0FBVyxHQUFHVixVQUFVLENBQUNhLFdBQVdILFdBQVc7SUFDeEU7SUFFQSxNQUFNSyxjQUFjcEIsS0FBS3FCLEdBQUcsQ0FBQyxDQUFDVCxTQUFTSztRQUNuQyxNQUFNSyxTQUFTTCxVQUFVakIsS0FBS3VCLE1BQU0sR0FBRztRQUN2QyxJQUFJQyxVQUFVLENBQUMsQ0FBQyxFQUFFeEIsS0FBS1UsS0FBSyxDQUFDLEdBQUdPLFFBQVEsR0FBR0UsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUV0RCxJQUFJUixZQUFZQyxZQUFZLENBQUNVLFFBQVE7WUFDakNFLFdBQVc7UUFDZjtRQUVBLE1BQU1DLGlCQUFpQlQsd0JBQXdCSixTQUFTSztRQUV4RCxPQUFPO1lBQ0hTLE1BQU1kO1lBQ05ZO1lBQ0FGO1lBQ0FLLFdBQVcsQ0FBQ0Y7UUFDaEI7SUFDSjtJQUVBLHFCQUNJLDhEQUFDaEMsbUdBQVdBO1FBQUNtQyxjQUFXO1FBQWFDLHlCQUFXLDhEQUFDbEMseUVBQWdCQTtZQUFDbUMsVUFBUzs7Ozs7O1FBQVlDLElBQUk7WUFBRUMsSUFBSTtRQUFFOzswQkFDL0YsOERBQUNwQyxrREFBSUE7Z0JBQUNxQyxNQUFLO2dCQUFJQyxRQUFROzBCQUNsQjs7Ozs7O1lBRUpkLFlBQVlDLEdBQUcsQ0FBQyxDQUFDLEVBQUVLLElBQUksRUFBRUYsT0FBTyxFQUFFRixNQUFNLEVBQUVLLFNBQVMsRUFBRSxFQUFFVjtnQkFDcEQsTUFBTWtCLGNBQWM3QixzQkFBc0JvQjtnQkFDMUMsSUFBSSxDQUFDSixVQUFVSyxXQUFXO29CQUN0QixxQkFDSSw4REFBQy9CLGtEQUFJQTt3QkFBYXFDLE1BQU1UO3dCQUFTVSxRQUFRO2tDQUNwQ0M7dUJBRE1sQjs7Ozs7Z0JBSW5CO2dCQUVBLHFCQUNJLDhEQUFDdkIsa0dBQVVBO29CQUFhMEMsT0FBTTs4QkFDekJEO21CQURZbEI7Ozs7O1lBSXpCOzs7Ozs7O0FBR1o7QUFFQSxpRUFBZW5CLGNBQWNBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vY29tcG9uZW50cy9icmVhZENydW1icy5qc3g/ODMwNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEJyZWFkY3J1bWJzLCBUeXBvZ3JhcGh5IH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWxcIjtcclxuaW1wb3J0IE5hdmlnYXRlTmV4dEljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvTmF2aWdhdGVOZXh0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJztcclxuXHJcbmZ1bmN0aW9uIEdldEJyZWFkY3J1bWJzKCkge1xyXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgICBjb25zdCBwYXRoID0gcm91dGVyLmFzUGF0aC5zcGxpdChcIi9cIikuZmlsdGVyKHggPT4geCAmJiB4ICE9PSBcInBhZ2VcIiAmJiAheC5zdGFydHNXaXRoKFwiMFwiKSk7XHJcblxyXG4gICAgZnVuY3Rpb24gY2FwaXRhbGl6ZUZpcnN0TGV0dGVyKHN0cmluZykge1xyXG4gICAgICAgIHJldHVybiBzdHJpbmcuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyBzdHJpbmcuc2xpY2UoMSk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gaXNMaXN0Um91dGUoc2VnbWVudCkge1xyXG4gICAgICAgIGNvbnN0IGxpc3RSb3V0ZXMgPSBbJ2xhdW5jaGVzJywgJ3BheWxvYWRzJywgJ2NvcmVzJywgJ3JvY2tldHMnLCAnc2hpcHMnLCAnbGF1bmNocGFkcyddO1xyXG4gICAgICAgIHJldHVybiBsaXN0Um91dGVzLmluY2x1ZGVzKHNlZ21lbnQudG9Mb3dlckNhc2UoKSk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gaXNOb25DbGlja2FibGVMaXN0Um91dGUoc2VnbWVudCwgaW5kZXgpIHtcclxuICAgICAgICBpZiAoIWlzTGlzdFJvdXRlKHNlZ21lbnQpKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgbGV0IGNoZWNrUm91dGUgPSBgLyR7cGF0aC5zbGljZSgwLCBpbmRleCArIDEpLmpvaW4oJy8nKX0vcGFnZS8wYDtcclxuICAgICAgICByZXR1cm4gcm91dGVyLmFzUGF0aC50b0xvd2VyQ2FzZSgpLnN0YXJ0c1dpdGgoY2hlY2tSb3V0ZS50b0xvd2VyQ2FzZSgpKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBicmVhZGNydW1icyA9IHBhdGgubWFwKChzZWdtZW50LCBpbmRleCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGlzTGFzdCA9IGluZGV4ID09PSBwYXRoLmxlbmd0aCAtIDE7XHJcbiAgICAgICAgbGV0IHJvdXRlVG8gPSBgLyR7cGF0aC5zbGljZSgwLCBpbmRleCArIDEpLmpvaW4oJy8nKX1gO1xyXG5cclxuICAgICAgICBpZiAoaXNMaXN0Um91dGUoc2VnbWVudCkgJiYgIWlzTGFzdCkge1xyXG4gICAgICAgICAgICByb3V0ZVRvICs9IFwiL3BhZ2UvMFwiO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgaXNOb25DbGlja2FibGUgPSBpc05vbkNsaWNrYWJsZUxpc3RSb3V0ZShzZWdtZW50LCBpbmRleCk7XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIG5hbWU6IHNlZ21lbnQsXHJcbiAgICAgICAgICAgIHJvdXRlVG8sXHJcbiAgICAgICAgICAgIGlzTGFzdCxcclxuICAgICAgICAgICAgY2xpY2thYmxlOiAhaXNOb25DbGlja2FibGUsXHJcbiAgICAgICAgfTtcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEJyZWFkY3J1bWJzIGFyaWEtbGFiZWw9XCJicmVhZGNydW1iXCIgc2VwYXJhdG9yPXs8TmF2aWdhdGVOZXh0SWNvbiBmb250U2l6ZT1cInNtYWxsXCIgLz59IHN4PXt7IG1iOiAyIH19PlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL1wiIHBhc3NIcmVmPlxyXG4gICAgICAgICAgICAgICAge1wiSG9tZVwifVxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIHticmVhZGNydW1icy5tYXAoKHsgbmFtZSwgcm91dGVUbywgaXNMYXN0LCBjbGlja2FibGUgfSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGRpc3BsYXlUZXh0ID0gY2FwaXRhbGl6ZUZpcnN0TGV0dGVyKG5hbWUpO1xyXG4gICAgICAgICAgICAgICAgaWYgKCFpc0xhc3QgJiYgY2xpY2thYmxlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsga2V5PXtpbmRleH0gaHJlZj17cm91dGVUb30gcGFzc0hyZWY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGlzcGxheVRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkga2V5PXtpbmRleH0gY29sb3I9XCJ0ZXh0LnByaW1hcnlcIiA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtkaXNwbGF5VGV4dH1cclxuICAgICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICA8L0JyZWFkY3J1bWJzPlxyXG4gICAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgR2V0QnJlYWRjcnVtYnM7XHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIkJyZWFkY3J1bWJzIiwiVHlwb2dyYXBoeSIsIk5hdmlnYXRlTmV4dEljb24iLCJMaW5rIiwidXNlUm91dGVyIiwiR2V0QnJlYWRjcnVtYnMiLCJyb3V0ZXIiLCJwYXRoIiwiYXNQYXRoIiwic3BsaXQiLCJmaWx0ZXIiLCJ4Iiwic3RhcnRzV2l0aCIsImNhcGl0YWxpemVGaXJzdExldHRlciIsInN0cmluZyIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJpc0xpc3RSb3V0ZSIsInNlZ21lbnQiLCJsaXN0Um91dGVzIiwiaW5jbHVkZXMiLCJ0b0xvd2VyQ2FzZSIsImlzTm9uQ2xpY2thYmxlTGlzdFJvdXRlIiwiaW5kZXgiLCJjaGVja1JvdXRlIiwiam9pbiIsImJyZWFkY3J1bWJzIiwibWFwIiwiaXNMYXN0IiwibGVuZ3RoIiwicm91dGVUbyIsImlzTm9uQ2xpY2thYmxlIiwibmFtZSIsImNsaWNrYWJsZSIsImFyaWEtbGFiZWwiLCJzZXBhcmF0b3IiLCJmb250U2l6ZSIsInN4IiwibWIiLCJocmVmIiwicGFzc0hyZWYiLCJkaXNwbGF5VGV4dCIsImNvbG9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/breadCrumbs.jsx\n");

/***/ }),

/***/ "./components/logo.jsx":
/*!*****************************!*\
  !*** ./components/logo.jsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ \"./node_modules/next/image.js\");\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _public_img_logo_jpg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../public/img/logo.jpg */ \"./public/img/logo.jpg\");\n\n\n\n\nconst Logo = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"w-full flex justify-center\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n            href: \"/\",\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {\n                src: _public_img_logo_jpg__WEBPACK_IMPORTED_MODULE_3__[\"default\"],\n                alt: \"Logo\",\n                width: 300,\n                height: 50\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\logo.jsx\",\n                lineNumber: 9,\n                columnNumber: 17\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\logo.jsx\",\n            lineNumber: 8,\n            columnNumber: 13\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\logo.jsx\",\n        lineNumber: 7,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Logo);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL2xvZ28uanN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUErQjtBQUNGO0FBQ2U7QUFFNUMsTUFBTUcsT0FBTztJQUNULHFCQUNJLDhEQUFDQztRQUFJQyxXQUFVO2tCQUNYLDRFQUFDSixrREFBSUE7WUFBQ0ssTUFBSztzQkFDUCw0RUFBQ04sbURBQUtBO2dCQUFDTyxLQUFLTCw0REFBT0E7Z0JBQUVNLEtBQUk7Z0JBQU9DLE9BQU87Z0JBQUtDLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJcEU7QUFFQSxpRUFBZVAsSUFBSUEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2xhYjcvLi9jb21wb25lbnRzL2xvZ28uanN4PzM2MWMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnO1xyXG5pbXBvcnQgbG9nb0ltZyBmcm9tICcuLi9wdWJsaWMvaW1nL2xvZ28uanBnJ1xyXG5cclxuY29uc3QgTG9nbyA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlclwiID5cclxuICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9cIj5cclxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e2xvZ29JbWd9IGFsdD1cIkxvZ29cIiB3aWR0aD17MzAwfSBoZWlnaHQ9ezUwfSAvPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMb2dvO1xyXG4iXSwibmFtZXMiOlsiSW1hZ2UiLCJMaW5rIiwibG9nb0ltZyIsIkxvZ28iLCJkaXYiLCJjbGFzc05hbWUiLCJocmVmIiwic3JjIiwiYWx0Iiwid2lkdGgiLCJoZWlnaHQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/logo.jsx\n");

/***/ }),

/***/ "./components/menu.jsx":
/*!*****************************!*\
  !*** ./components/menu.jsx ***!
  \*****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_HiMenu_react_icons_hi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=HiMenu!=!react-icons/hi */ \"__barrel_optimize__?names=HiMenu!=!./node_modules/react-icons/hi/index.mjs\");\n/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! framer-motion */ \"framer-motion\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);\nframer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\nconst routes = [\n    {\n        path: \"/launches/page/0\",\n        label: \"Launches\"\n    },\n    {\n        path: \"/payloads/page/0\",\n        label: \"Payloads\"\n    },\n    {\n        path: \"/cores/page/0\",\n        label: \"Cores\"\n    },\n    {\n        path: \"/rockets/page/0\",\n        label: \"Rockets\"\n    },\n    {\n        path: \"/ships/page/0\",\n        label: \"Ships\"\n    },\n    {\n        path: \"/launchpads/page/0\",\n        label: \"Launchpads\"\n    }\n];\nconst Menu = ()=>{\n    const [isExpanded, setIsExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const buttonRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);\n    const [buttonPosition, setButtonPosition] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});\n    const handleLinkClick = ()=>setIsExpanded(false);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        if (buttonRef.current) {\n            const rect = buttonRef.current.getBoundingClientRect();\n            setButtonPosition({\n                top: rect.bottom + window.scrollY,\n                left: rect.left + window.scrollX\n            });\n        }\n    }, [\n        isExpanded\n    ]);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        const handleClickOutside = (event)=>{\n            if (buttonRef.current && !buttonRef.current.contains(event.target)) {\n                setIsExpanded(false);\n            }\n        };\n        document.addEventListener(\"mousedown\", handleClickOutside);\n        return ()=>{\n            document.removeEventListener(\"mousedown\", handleClickOutside);\n        };\n    }, []);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"relative\",\n        ref: buttonRef,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                className: \"text-gray-600 hover:text-gray-800 focus:outline-none\",\n                onClick: ()=>setIsExpanded(!isExpanded),\n                \"aria-label\": \"Menu\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_HiMenu_react_icons_hi__WEBPACK_IMPORTED_MODULE_4__.HiMenu, {\n                    className: \"w-6 h-6\"\n                }, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                    lineNumber: 52,\n                    columnNumber: 17\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                lineNumber: 47,\n                columnNumber: 13\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.AnimatePresence, {\n                children: isExpanded && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {\n                    initial: {\n                        opacity: 0,\n                        y: -10\n                    },\n                    animate: {\n                        opacity: 1,\n                        y: 0\n                    },\n                    exit: {\n                        opacity: 0,\n                        y: -10\n                    },\n                    transition: {\n                        duration: 0.2\n                    },\n                    style: {\n                        position: \"absolute\",\n                        top: `${buttonPosition.top}px`,\n                        left: `${buttonPosition.left}px`,\n                        zIndex: 50\n                    },\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"w-48 bg-white rounded-md shadow-md overflow-hidden\",\n                        children: routes.map((route, index)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                                href: route.path,\n                                passHref: true,\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                    className: \"block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer\",\n                                    onClick: handleLinkClick,\n                                    children: route.label\n                                }, void 0, false, {\n                                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                                    lineNumber: 71,\n                                    columnNumber: 37\n                                }, undefined)\n                            }, index, false, {\n                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                                lineNumber: 70,\n                                columnNumber: 33\n                            }, undefined))\n                    }, void 0, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                        lineNumber: 68,\n                        columnNumber: 25\n                    }, undefined)\n                }, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                    lineNumber: 56,\n                    columnNumber: 21\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                lineNumber: 54,\n                columnNumber: 13\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n        lineNumber: 46,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menu);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL21lbnUuanN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBMkQ7QUFDOUI7QUFDVztBQUNnQjtBQUV4RCxNQUFNUSxTQUFTO0lBQ1g7UUFBRUMsTUFBTTtRQUFvQkMsT0FBTztJQUFXO0lBQzlDO1FBQUVELE1BQU07UUFBb0JDLE9BQU87SUFBVztJQUM5QztRQUFFRCxNQUFNO1FBQWlCQyxPQUFPO0lBQVE7SUFDeEM7UUFBRUQsTUFBTTtRQUFtQkMsT0FBTztJQUFVO0lBQzVDO1FBQUVELE1BQU07UUFBaUJDLE9BQU87SUFBUTtJQUN4QztRQUFFRCxNQUFNO1FBQXNCQyxPQUFPO0lBQWE7Q0FDckQ7QUFFRCxNQUFNQyxPQUFPO0lBQ1QsTUFBTSxDQUFDQyxZQUFZQyxjQUFjLEdBQUdaLCtDQUFRQSxDQUFDO0lBQzdDLE1BQU1hLFlBQVlaLDZDQUFNQSxDQUFDO0lBQ3pCLE1BQU0sQ0FBQ2EsZ0JBQWdCQyxrQkFBa0IsR0FBR2YsK0NBQVFBLENBQUMsQ0FBQztJQUV0RCxNQUFNZ0Isa0JBQWtCLElBQU1KLGNBQWM7SUFFNUNWLGdEQUFTQSxDQUFDO1FBQ04sSUFBSVcsVUFBVUksT0FBTyxFQUFFO1lBQ25CLE1BQU1DLE9BQU9MLFVBQVVJLE9BQU8sQ0FBQ0UscUJBQXFCO1lBQ3BESixrQkFBa0I7Z0JBQ2RLLEtBQUtGLEtBQUtHLE1BQU0sR0FBR0MsT0FBT0MsT0FBTztnQkFDakNDLE1BQU1OLEtBQUtNLElBQUksR0FBR0YsT0FBT0csT0FBTztZQUNwQztRQUNKO0lBQ0osR0FBRztRQUFDZDtLQUFXO0lBRWZULGdEQUFTQSxDQUFDO1FBQ04sTUFBTXdCLHFCQUFxQixDQUFDQztZQUN4QixJQUFJZCxVQUFVSSxPQUFPLElBQUksQ0FBQ0osVUFBVUksT0FBTyxDQUFDVyxRQUFRLENBQUNELE1BQU1FLE1BQU0sR0FBRztnQkFDaEVqQixjQUFjO1lBQ2xCO1FBQ0o7UUFFQWtCLFNBQVNDLGdCQUFnQixDQUFDLGFBQWFMO1FBQ3ZDLE9BQU87WUFDSEksU0FBU0UsbUJBQW1CLENBQUMsYUFBYU47UUFDOUM7SUFDSixHQUFHLEVBQUU7SUFFTCxxQkFDSSw4REFBQ087UUFBSUMsV0FBVTtRQUFXQyxLQUFLdEI7OzBCQUMzQiw4REFBQ3VCO2dCQUNHRixXQUFVO2dCQUNWRyxTQUFTLElBQU16QixjQUFjLENBQUNEO2dCQUM5QjJCLGNBQVc7MEJBRVgsNEVBQUNsQyxnRkFBTUE7b0JBQUM4QixXQUFVOzs7Ozs7Ozs7OzswQkFFdEIsOERBQUM1QiwwREFBZUE7MEJBQ1hLLDRCQUNHLDhEQUFDTixpREFBTUEsQ0FBQzRCLEdBQUc7b0JBQ1BNLFNBQVM7d0JBQUVDLFNBQVM7d0JBQUdDLEdBQUcsQ0FBQztvQkFBRztvQkFDOUJDLFNBQVM7d0JBQUVGLFNBQVM7d0JBQUdDLEdBQUc7b0JBQUU7b0JBQzVCRSxNQUFNO3dCQUFFSCxTQUFTO3dCQUFHQyxHQUFHLENBQUM7b0JBQUc7b0JBQzNCRyxZQUFZO3dCQUFFQyxVQUFVO29CQUFJO29CQUM1QkMsT0FBTzt3QkFDSEMsVUFBVTt3QkFDVjNCLEtBQUssQ0FBQyxFQUFFTixlQUFlTSxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUM5QkksTUFBTSxDQUFDLEVBQUVWLGVBQWVVLElBQUksQ0FBQyxFQUFFLENBQUM7d0JBQ2hDd0IsUUFBUTtvQkFDWjs4QkFFQSw0RUFBQ2Y7d0JBQUlDLFdBQVU7a0NBQ1YzQixPQUFPMEMsR0FBRyxDQUFDLENBQUNDLE9BQU9DLHNCQUNoQiw4REFBQ2hELGtEQUFJQTtnQ0FBYWlELE1BQU1GLE1BQU0xQyxJQUFJO2dDQUFFNkMsUUFBUTswQ0FDeEMsNEVBQUNDO29DQUNHcEIsV0FBVTtvQ0FDVkcsU0FBU3JCOzhDQUVSa0MsTUFBTXpDLEtBQUs7Ozs7OzsrQkFMVDBDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWUzQztBQUVBLGlFQUFlekMsSUFBSUEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2xhYjcvLi9jb21wb25lbnRzL21lbnUuanN4PzhiNTgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuaW1wb3J0IHsgSGlNZW51IH0gZnJvbSAncmVhY3QtaWNvbnMvaGknO1xyXG5pbXBvcnQgeyBtb3Rpb24sIEFuaW1hdGVQcmVzZW5jZSB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xyXG5cclxuY29uc3Qgcm91dGVzID0gW1xyXG4gICAgeyBwYXRoOiBcIi9sYXVuY2hlcy9wYWdlLzBcIiwgbGFiZWw6IFwiTGF1bmNoZXNcIiB9LFxyXG4gICAgeyBwYXRoOiBcIi9wYXlsb2Fkcy9wYWdlLzBcIiwgbGFiZWw6IFwiUGF5bG9hZHNcIiB9LFxyXG4gICAgeyBwYXRoOiBcIi9jb3Jlcy9wYWdlLzBcIiwgbGFiZWw6IFwiQ29yZXNcIiB9LFxyXG4gICAgeyBwYXRoOiBcIi9yb2NrZXRzL3BhZ2UvMFwiLCBsYWJlbDogXCJSb2NrZXRzXCIgfSxcclxuICAgIHsgcGF0aDogXCIvc2hpcHMvcGFnZS8wXCIsIGxhYmVsOiBcIlNoaXBzXCIgfSxcclxuICAgIHsgcGF0aDogXCIvbGF1bmNocGFkcy9wYWdlLzBcIiwgbGFiZWw6IFwiTGF1bmNocGFkc1wiIH0sXHJcbl07XHJcblxyXG5jb25zdCBNZW51ID0gKCkgPT4ge1xyXG4gICAgY29uc3QgW2lzRXhwYW5kZWQsIHNldElzRXhwYW5kZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgYnV0dG9uUmVmID0gdXNlUmVmKG51bGwpO1xyXG4gICAgY29uc3QgW2J1dHRvblBvc2l0aW9uLCBzZXRCdXR0b25Qb3NpdGlvbl0gPSB1c2VTdGF0ZSh7fSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlTGlua0NsaWNrID0gKCkgPT4gc2V0SXNFeHBhbmRlZChmYWxzZSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoYnV0dG9uUmVmLmN1cnJlbnQpIHtcclxuICAgICAgICAgICAgY29uc3QgcmVjdCA9IGJ1dHRvblJlZi5jdXJyZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgICAgICBzZXRCdXR0b25Qb3NpdGlvbih7XHJcbiAgICAgICAgICAgICAgICB0b3A6IHJlY3QuYm90dG9tICsgd2luZG93LnNjcm9sbFksXHJcbiAgICAgICAgICAgICAgICBsZWZ0OiByZWN0LmxlZnQgKyB3aW5kb3cuc2Nyb2xsWCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW2lzRXhwYW5kZWRdKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGhhbmRsZUNsaWNrT3V0c2lkZSA9IChldmVudCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoYnV0dG9uUmVmLmN1cnJlbnQgJiYgIWJ1dHRvblJlZi5jdXJyZW50LmNvbnRhaW5zKGV2ZW50LnRhcmdldCkpIHtcclxuICAgICAgICAgICAgICAgIHNldElzRXhwYW5kZWQoZmFsc2UpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgaGFuZGxlQ2xpY2tPdXRzaWRlKTtcclxuICAgICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVDbGlja091dHNpZGUpO1xyXG4gICAgICAgIH07XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ncmVsYXRpdmUnIHJlZj17YnV0dG9uUmVmfT5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBob3Zlcjp0ZXh0LWdyYXktODAwIGZvY3VzOm91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0V4cGFuZGVkKCFpc0V4cGFuZGVkKX1cclxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJNZW51XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEhpTWVudSBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxBbmltYXRlUHJlc2VuY2U+XHJcbiAgICAgICAgICAgICAgICB7aXNFeHBhbmRlZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAtMTAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCwgeTogLTEwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A6IGAke2J1dHRvblBvc2l0aW9uLnRvcH1weGAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiBgJHtidXR0b25Qb3NpdGlvbi5sZWZ0fXB4YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHpJbmRleDogNTAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNDggYmctd2hpdGUgcm91bmRlZC1tZCBzaGFkb3ctbWQgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cm91dGVzLm1hcCgocm91dGUsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsga2V5PXtpbmRleH0gaHJlZj17cm91dGUucGF0aH0gcGFzc0hyZWY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktMTAwIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxpbmtDbGlja31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JvdXRlLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvQW5pbWF0ZVByZXNlbmNlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1lbnU7Il0sIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VSZWYiLCJ1c2VFZmZlY3QiLCJMaW5rIiwiSGlNZW51IiwibW90aW9uIiwiQW5pbWF0ZVByZXNlbmNlIiwicm91dGVzIiwicGF0aCIsImxhYmVsIiwiTWVudSIsImlzRXhwYW5kZWQiLCJzZXRJc0V4cGFuZGVkIiwiYnV0dG9uUmVmIiwiYnV0dG9uUG9zaXRpb24iLCJzZXRCdXR0b25Qb3NpdGlvbiIsImhhbmRsZUxpbmtDbGljayIsImN1cnJlbnQiLCJyZWN0IiwiZ2V0Qm91bmRpbmdDbGllbnRSZWN0IiwidG9wIiwiYm90dG9tIiwid2luZG93Iiwic2Nyb2xsWSIsImxlZnQiLCJzY3JvbGxYIiwiaGFuZGxlQ2xpY2tPdXRzaWRlIiwiZXZlbnQiLCJjb250YWlucyIsInRhcmdldCIsImRvY3VtZW50IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJkaXYiLCJjbGFzc05hbWUiLCJyZWYiLCJidXR0b24iLCJvbkNsaWNrIiwiYXJpYS1sYWJlbCIsImluaXRpYWwiLCJvcGFjaXR5IiwieSIsImFuaW1hdGUiLCJleGl0IiwidHJhbnNpdGlvbiIsImR1cmF0aW9uIiwic3R5bGUiLCJwb3NpdGlvbiIsInpJbmRleCIsIm1hcCIsInJvdXRlIiwiaW5kZXgiLCJocmVmIiwicGFzc0hyZWYiLCJzcGFuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/menu.jsx\n");

/***/ }),

/***/ "./pages/_app.jsx":
/*!************************!*\
  !*** ./pages/_app.jsx ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_menu_jsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/menu.jsx */ \"./components/menu.jsx\");\n/* harmony import */ var _components_logo_jsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/logo.jsx */ \"./components/logo.jsx\");\n/* harmony import */ var _components_backgroundOverlay_jsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/backgroundOverlay.jsx */ \"./components/backgroundOverlay.jsx\");\n/* harmony import */ var _components_breadCrumbs_jsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/breadCrumbs.jsx */ \"./components/breadCrumbs.jsx\");\n/* harmony import */ var _components_backTotop_jsx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/backTotop.jsx */ \"./components/backTotop.jsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_menu_jsx__WEBPACK_IMPORTED_MODULE_2__]);\n_components_menu_jsx__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"layoutStyle\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"header\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_backgroundOverlay_jsx__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {}, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                    lineNumber: 12,\n                    columnNumber: 15\n                }, this)\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 11,\n                columnNumber: 11\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_backTotop_jsx__WEBPACK_IMPORTED_MODULE_6__[\"default\"], {}, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                    lineNumber: 14,\n                    columnNumber: 17\n                }, this)\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 14,\n                columnNumber: 11\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_menu_jsx__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 15,\n                columnNumber: 11\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_logo_jsx__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 16,\n                columnNumber: 11\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_breadCrumbs_jsx__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {}, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 17,\n                columnNumber: 11\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 18,\n                columnNumber: 11\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n        lineNumber: 10,\n        columnNumber: 7\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUE4QjtBQUNXO0FBQ0E7QUFDMEI7QUFDVDtBQUNEO0FBRTFDLFNBQVNLLElBQUksRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDbEQscUJBQ0ksOERBQUNDO1FBQUlDLFdBQVU7OzBCQUNYLDhEQUFDQzswQkFDRyw0RUFBQ1IseUVBQWlCQTs7Ozs7Ozs7OzswQkFFdEIsOERBQUNTOzBCQUFLLDRFQUFDUCxpRUFBZUE7Ozs7Ozs7Ozs7MEJBQ3RCLDhEQUFDSiw0REFBSUE7Ozs7OzBCQUNMLDhEQUFDQyw0REFBSUE7Ozs7OzBCQUNMLDhEQUFDRSxtRUFBY0E7Ozs7OzBCQUNmLDhEQUFDRztnQkFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7Ozs7QUFJbEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vcGFnZXMvX2FwcC5qc3g/NGNiMyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCJAL3N0eWxlcy9nbG9iYWxzLmNzc1wiO1xuaW1wb3J0IE1lbnUgZnJvbSBcIkAvY29tcG9uZW50cy9tZW51LmpzeFwiO1xuaW1wb3J0IExvZ28gZnJvbSBcIkAvY29tcG9uZW50cy9sb2dvLmpzeFwiO1xuaW1wb3J0IEJhY2tncm91bmRPdmVybGF5IGZyb20gXCJAL2NvbXBvbmVudHMvYmFja2dyb3VuZE92ZXJsYXkuanN4XCI7XG5pbXBvcnQgR2V0QnJlYWRjcnVtYnMgZnJvbSBcIkAvY29tcG9uZW50cy9icmVhZENydW1icy5qc3hcIjtcbmltcG9ydCBCYWNrVG9Ub3BCdXR0b24gZnJvbSBcIkAvY29tcG9uZW50cy9iYWNrVG90b3AuanN4XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcbiAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdsYXlvdXRTdHlsZSc+XG4gICAgICAgICAgPGhlYWRlcj5cbiAgICAgICAgICAgICAgPEJhY2tncm91bmRPdmVybGF5Lz5cbiAgICAgICAgICA8L2hlYWRlcj5cbiAgICAgICAgICA8bWFpbj48QmFja1RvVG9wQnV0dG9uLz48L21haW4+XG4gICAgICAgICAgPE1lbnUvPlxuICAgICAgICAgIDxMb2dvLz5cbiAgICAgICAgICA8R2V0QnJlYWRjcnVtYnMvPlxuICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cblxuICAgICAgPC9kaXY+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiTWVudSIsIkxvZ28iLCJCYWNrZ3JvdW5kT3ZlcmxheSIsIkdldEJyZWFkY3J1bWJzIiwiQmFja1RvVG9wQnV0dG9uIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwiZGl2IiwiY2xhc3NOYW1lIiwiaGVhZGVyIiwibWFpbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.jsx\n");

/***/ }),

/***/ "./pages/_document.jsx":
/*!*****************************!*\
  !*** ./pages/_document.jsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Document)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/document */ \"./node_modules/next/document.js\");\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Document() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {\n        lang: \"en\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {}, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_document.jsx\",\n                lineNumber: 6,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}, void 0, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_document.jsx\",\n                        lineNumber: 8,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {}, void 0, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_document.jsx\",\n                        lineNumber: 9,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_document.jsx\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_document.jsx\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fZG9jdW1lbnQuanN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUE2RDtBQUU5QyxTQUFTSTtJQUN0QixxQkFDRSw4REFBQ0osK0NBQUlBO1FBQUNLLE1BQUs7OzBCQUNULDhEQUFDSiwrQ0FBSUE7Ozs7OzBCQUNMLDhEQUFDSzs7a0NBQ0MsOERBQUNKLCtDQUFJQTs7Ozs7a0NBQ0wsOERBQUNDLHFEQUFVQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJbkIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vcGFnZXMvX2RvY3VtZW50LmpzeD9mODZlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEh0bWwsIEhlYWQsIE1haW4sIE5leHRTY3JpcHQgfSBmcm9tIFwibmV4dC9kb2N1bWVudFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEb2N1bWVudCgpIHtcbiAgcmV0dXJuIChcbiAgICA8SHRtbCBsYW5nPVwiZW5cIj5cbiAgICAgIDxIZWFkIC8+XG4gICAgICA8Ym9keT5cbiAgICAgICAgPE1haW4gLz5cbiAgICAgICAgPE5leHRTY3JpcHQgLz5cbiAgICAgIDwvYm9keT5cbiAgICA8L0h0bWw+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiSHRtbCIsIkhlYWQiLCJNYWluIiwiTmV4dFNjcmlwdCIsIkRvY3VtZW50IiwibGFuZyIsImJvZHkiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_document.jsx\n");

/***/ }),

/***/ "./pages/index.jsx":
/*!*************************!*\
  !*** ./pages/index.jsx ***!
  \*************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! framer-motion */ \"framer-motion\");\n/* harmony import */ var _barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! __barrel_optimize__?names=Box,Button,Card,CardContent,Grid,Typography!=!@mui/material */ \"__barrel_optimize__?names=Box,Button,Card,CardContent,Grid,Typography!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var _components_backToTop_jsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/backToTop.jsx */ \"./components/backToTop.jsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__, axios__WEBPACK_IMPORTED_MODULE_4__]);\n([framer_motion__WEBPACK_IMPORTED_MODULE_3__, axios__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\nfunction Home({ companyInfo, histories }) {\n    const [isExpanded, setIsExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);\n    const handleExpand = ()=>{\n        setIsExpanded(!isExpanded);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n            className: \"flex min-h-screen flex-col items-center justify-center p-10 bg-gray-100 relative overflow-hidden\",\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {\n                    initial: {\n                        opacity: 0\n                    },\n                    animate: {\n                        opacity: 1\n                    },\n                    transition: {\n                        duration: 1.5\n                    },\n                    className: \"w-full max-w-4xl bg-white/90 backdrop-blur-sm rounded-lg shadow-md p-6 relative\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {\n                            variant: \"h4\",\n                            gutterBottom: true,\n                            className: \"text-2xl font-bold text-center text-gray-800\",\n                            children: \"Welcome to SpaceX Explorer\"\n                        }, void 0, false, {\n                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                            lineNumber: 25,\n                            columnNumber: 13\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"w-full flex justify-center\",\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Button, {\n                                variant: \"contained\",\n                                color: \"primary\",\n                                onClick: handleExpand,\n                                className: \"mt-4 mb-2 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transform transition hover:scale-105 duration-300 ease-in-out\",\n                                children: \"View Company Info and History\"\n                            }, void 0, false, {\n                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                lineNumber: 29,\n                                columnNumber: 15\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                            lineNumber: 28,\n                            columnNumber: 13\n                        }, this),\n                        isExpanded && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Card, {\n                            className: \"mt-4 bg-gray-50 border border-gray-200 rounded-lg\",\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.CardContent, {\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {\n                                        variant: \"h6\",\n                                        className: \"font-semibold text-lg\",\n                                        children: \"Company Info\"\n                                    }, void 0, false, {\n                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                        lineNumber: 41,\n                                        columnNumber: 21\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {\n                                        className: \"text-gray-700\",\n                                        children: companyInfo.summary\n                                    }, void 0, false, {\n                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                        lineNumber: 42,\n                                        columnNumber: 21\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {\n                                        children: [\n                                            \"Founded: \",\n                                            companyInfo.founded\n                                        ]\n                                    }, void 0, true, {\n                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                        lineNumber: 43,\n                                        columnNumber: 21\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {\n                                        children: [\n                                            \"Founder: \",\n                                            companyInfo.founder\n                                        ]\n                                    }, void 0, true, {\n                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                        lineNumber: 44,\n                                        columnNumber: 21\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {\n                                        children: [\n                                            \"CEO: \",\n                                            companyInfo.ceo\n                                        ]\n                                    }, void 0, true, {\n                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                        lineNumber: 45,\n                                        columnNumber: 21\n                                    }, this),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {\n                                        variant: \"h6\",\n                                        className: \"mt-4 font-semibold text-lg\",\n                                        children: \"History\"\n                                    }, void 0, false, {\n                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                        lineNumber: 46,\n                                        columnNumber: 21\n                                    }, this),\n                                    histories.map((history)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {\n                                            whileHover: {\n                                                scale: 1.03\n                                            },\n                                            className: \"my-2 p-4 bg-white rounded-lg shadow\",\n                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.CardContent, {\n                                                children: [\n                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {\n                                                        children: [\n                                                            \"Event Date: \",\n                                                            history.event_date_utc\n                                                        ]\n                                                    }, void 0, true, {\n                                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                                        lineNumber: 54,\n                                                        columnNumber: 29\n                                                    }, this),\n                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {\n                                                        children: [\n                                                            \"Title: \",\n                                                            history.title\n                                                        ]\n                                                    }, void 0, true, {\n                                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                                        lineNumber: 55,\n                                                        columnNumber: 29\n                                                    }, this),\n                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {\n                                                        children: [\n                                                            \"Details: \",\n                                                            history.details\n                                                        ]\n                                                    }, void 0, true, {\n                                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                                        lineNumber: 56,\n                                                        columnNumber: 29\n                                                    }, this),\n                                                    history.links && history.links.article && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"a\", {\n                                                        href: history.links.article,\n                                                        target: \"_blank\",\n                                                        rel: \"noopener noreferrer\",\n                                                        className: \"text-blue-500 hover:text-blue-800 transition duration-300\",\n                                                        children: \"Read More\"\n                                                    }, void 0, false, {\n                                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                                        lineNumber: 58,\n                                                        columnNumber: 33\n                                                    }, this)\n                                                ]\n                                            }, void 0, true, {\n                                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                                lineNumber: 53,\n                                                columnNumber: 27\n                                            }, this)\n                                        }, history.id, false, {\n                                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                            lineNumber: 48,\n                                            columnNumber: 25\n                                        }, this))\n                                ]\n                            }, void 0, true, {\n                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                lineNumber: 40,\n                                columnNumber: 19\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                            lineNumber: 39,\n                            columnNumber: 17\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {\n                            mt: \"8\",\n                            className: \"grid grid-cols-1 md:grid-cols-2 gap-4\",\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {\n                                    variant: \"h5\",\n                                    gutterBottom: true,\n                                    className: \"col-span-2 text-xl font-semibold text-gray-800\",\n                                    children: \"Explore Listings\"\n                                }, void 0, false, {\n                                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                    lineNumber: 75,\n                                    columnNumber: 15\n                                }, this),\n                                [\n                                    \"launches\",\n                                    \"payloads\",\n                                    \"cores\",\n                                    \"rockets\",\n                                    \"ships\",\n                                    \"launchpads\"\n                                ].map((category)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {\n                                        item: true,\n                                        xs: 12,\n                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                            href: `/${category}/page/0`,\n                                            passHref: true,\n                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Button_Card_CardContent_Grid_Typography_mui_material__WEBPACK_IMPORTED_MODULE_6__.Button, {\n                                                className: \"w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transform transition hover:scale-105 duration-300 ease-in-out\",\n                                                children: `${category.charAt(0).toUpperCase() + category.slice(1)} Listing`\n                                            }, void 0, false, {\n                                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                                lineNumber: 81,\n                                                columnNumber: 23\n                                            }, this)\n                                        }, void 0, false, {\n                                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                            lineNumber: 80,\n                                            columnNumber: 21\n                                        }, this)\n                                    }, category, false, {\n                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                                        lineNumber: 79,\n                                        columnNumber: 19\n                                    }, this))\n                            ]\n                        }, void 0, true, {\n                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                            lineNumber: 74,\n                            columnNumber: 13\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                    lineNumber: 19,\n                    columnNumber: 11\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_backToTop_jsx__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {}, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n                    lineNumber: 91,\n                    columnNumber: 11\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\index.jsx\",\n            lineNumber: 17,\n            columnNumber: 9\n        }, this)\n    }, void 0, false);\n}\nasync function getStaticProps() {\n    try {\n        const { data: historyData } = await axios__WEBPACK_IMPORTED_MODULE_4__[\"default\"].get(\"https://api.spacexdata.com/v4/history\");\n        const sortedHistoryData = historyData.sort((a, b)=>new Date(b.event_date_utc) - new Date(a.event_date_utc));\n        const recentHistories = sortedHistoryData.slice(0, 5);\n        const { data: companyInfo } = await axios__WEBPACK_IMPORTED_MODULE_4__[\"default\"].get(\"https://api.spacexdata.com/v4/company\");\n        return {\n            props: {\n                companyInfo,\n                histories: recentHistories\n            },\n            revalidate: 86400\n        };\n    } catch (error) {\n        console.error(error);\n        return {\n            props: {\n                companyInfo: {},\n                histories: []\n            }\n        };\n    }\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC5qc3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUE2QjtBQUNFO0FBQ007QUFDMkM7QUFDdEQ7QUFDZ0M7QUFFM0MsU0FBU1csS0FBSyxFQUFDQyxXQUFXLEVBQUVDLFNBQVMsRUFBQztJQUNuRCxNQUFNLENBQUNDLFlBQVlDLGNBQWMsR0FBR2QsK0NBQVFBLENBQUM7SUFFN0MsTUFBTWUsZUFBZTtRQUNuQkQsY0FBYyxDQUFDRDtJQUNqQjtJQUVBLHFCQUNJO2tCQUNFLDRFQUFDRztZQUNHQyxXQUFVOzs4QkFDWiw4REFBQ2hCLGlEQUFNQSxDQUFDaUIsR0FBRztvQkFDUEMsU0FBUzt3QkFBQ0MsU0FBUztvQkFBQztvQkFDcEJDLFNBQVM7d0JBQUNELFNBQVM7b0JBQUM7b0JBQ3BCRSxZQUFZO3dCQUFDQyxVQUFVO29CQUFHO29CQUMxQk4sV0FBVTs7c0NBRVosOERBQUNWLHVIQUFVQTs0QkFBQ2lCLFNBQVE7NEJBQUtDLFlBQVk7NEJBQUNSLFdBQVU7c0NBQStDOzs7Ozs7c0NBRy9GLDhEQUFDQzs0QkFBSUQsV0FBVTtzQ0FDYiw0RUFBQ2QsbUhBQU1BO2dDQUNIcUIsU0FBUTtnQ0FDUkUsT0FBTTtnQ0FDTkMsU0FBU1o7Z0NBQ1RFLFdBQVU7MENBQ2I7Ozs7Ozs7Ozs7O3dCQUlGSiw0QkFDRyw4REFBQ1QsaUhBQUlBOzRCQUFDYSxXQUFVO3NDQUNkLDRFQUFDWix3SEFBV0E7O2tEQUNWLDhEQUFDRSx1SEFBVUE7d0NBQUNpQixTQUFRO3dDQUFLUCxXQUFVO2tEQUF3Qjs7Ozs7O2tEQUMzRCw4REFBQ1YsdUhBQVVBO3dDQUFDVSxXQUFVO2tEQUFpQk4sWUFBWWlCLE9BQU87Ozs7OztrREFDMUQsOERBQUNyQix1SEFBVUE7OzRDQUFDOzRDQUFVSSxZQUFZa0IsT0FBTzs7Ozs7OztrREFDekMsOERBQUN0Qix1SEFBVUE7OzRDQUFDOzRDQUFVSSxZQUFZbUIsT0FBTzs7Ozs7OztrREFDekMsOERBQUN2Qix1SEFBVUE7OzRDQUFDOzRDQUFNSSxZQUFZb0IsR0FBRzs7Ozs7OztrREFDakMsOERBQUN4Qix1SEFBVUE7d0NBQUNpQixTQUFRO3dDQUFLUCxXQUFVO2tEQUE2Qjs7Ozs7O29DQUMvREwsVUFBVW9CLEdBQUcsQ0FBQyxDQUFDQyx3QkFDWiw4REFBQ2hDLGlEQUFNQSxDQUFDaUIsR0FBRzs0Q0FFUGdCLFlBQVk7Z0RBQUNDLE9BQU87NENBQUk7NENBQ3hCbEIsV0FBVTtzREFFWiw0RUFBQ1osd0hBQVdBOztrRUFDViw4REFBQ0UsdUhBQVVBOzs0REFBQzs0REFBYTBCLFFBQVFHLGNBQWM7Ozs7Ozs7a0VBQy9DLDhEQUFDN0IsdUhBQVVBOzs0REFBQzs0REFBUTBCLFFBQVFJLEtBQUs7Ozs7Ozs7a0VBQ2pDLDhEQUFDOUIsdUhBQVVBOzs0REFBQzs0REFBVTBCLFFBQVFLLE9BQU87Ozs7Ozs7b0RBQ3BDTCxRQUFRTSxLQUFLLElBQUlOLFFBQVFNLEtBQUssQ0FBQ0MsT0FBTyxrQkFDbkMsOERBQUNDO3dEQUNHQyxNQUFNVCxRQUFRTSxLQUFLLENBQUNDLE9BQU87d0RBQzNCRyxRQUFPO3dEQUNQQyxLQUFJO3dEQUNKM0IsV0FBVTtrRUFDYjs7Ozs7Ozs7Ozs7OzJDQWRBZ0IsUUFBUVksRUFBRTs7Ozs7Ozs7Ozs7Ozs7OztzQ0F5Qi9CLDhEQUFDM0MsZ0hBQUdBOzRCQUFDNEMsSUFBRzs0QkFBSTdCLFdBQVU7OzhDQUNwQiw4REFBQ1YsdUhBQVVBO29DQUFDaUIsU0FBUTtvQ0FBS0MsWUFBWTtvQ0FBQ1IsV0FBVTs4Q0FBaUQ7Ozs7OztnQ0FHaEc7b0NBQUM7b0NBQVk7b0NBQVk7b0NBQVM7b0NBQVc7b0NBQVM7aUNBQWEsQ0FBQ2UsR0FBRyxDQUFDZSxDQUFBQSx5QkFDckUsOERBQUN6QyxpSEFBSUE7d0NBQUMwQyxJQUFJO3dDQUFDQyxJQUFJO2tEQUNiLDRFQUFDbEQsa0RBQUlBOzRDQUFDMkMsTUFBTSxDQUFDLENBQUMsRUFBRUssU0FBUyxPQUFPLENBQUM7NENBQUVHLFFBQVE7c0RBQ3pDLDRFQUFDL0MsbUhBQU1BO2dEQUNIYyxXQUFVOzBEQUVYLENBQUMsRUFBRThCLFNBQVNJLE1BQU0sQ0FBQyxHQUFHQyxXQUFXLEtBQUtMLFNBQVNNLEtBQUssQ0FBQyxHQUFHLFFBQVEsQ0FBQzs7Ozs7Ozs7Ozs7dUNBTGhETjs7Ozs7Ozs7Ozs7Ozs7Ozs7OEJBWWhDLDhEQUFDdEMsaUVBQWVBOzs7Ozs7Ozs7Ozs7QUFJMUI7QUFFTyxlQUFlNkM7SUFDcEIsSUFBSTtRQUNGLE1BQU0sRUFBQ0MsTUFBTUMsV0FBVyxFQUFDLEdBQUcsTUFBTWhELGlEQUFTLENBQUM7UUFDNUMsTUFBTWtELG9CQUFvQkYsWUFBWUcsSUFBSSxDQUFDLENBQUNsQixHQUFHbUIsSUFBTSxJQUFJQyxLQUFLRCxFQUFFeEIsY0FBYyxJQUFJLElBQUl5QixLQUFLcEIsRUFBRUwsY0FBYztRQUMzRyxNQUFNMEIsa0JBQWtCSixrQkFBa0JMLEtBQUssQ0FBQyxHQUFHO1FBRW5ELE1BQU0sRUFBQ0UsTUFBTTVDLFdBQVcsRUFBQyxHQUFHLE1BQU1ILGlEQUFTLENBQUM7UUFFNUMsT0FBTztZQUNMdUQsT0FBTztnQkFDTHBEO2dCQUNBQyxXQUFXa0Q7WUFDYjtZQUNBRSxZQUFZO1FBQ2Q7SUFDRixFQUFFLE9BQU9DLE9BQU87UUFDZEMsUUFBUUQsS0FBSyxDQUFDQTtRQUNkLE9BQU87WUFDTEYsT0FBTztnQkFDTHBELGFBQWEsQ0FBQztnQkFDZEMsV0FBVyxFQUFFO1lBQ2Y7UUFDRjtJQUNGO0FBQ0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vcGFnZXMvaW5kZXguanN4PzdmZmQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcbmltcG9ydCB7dXNlU3RhdGV9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHttb3Rpb259IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHtCb3gsIEJ1dHRvbiwgQ2FyZCwgQ2FyZENvbnRlbnQsIEdyaWQsIFR5cG9ncmFwaHksfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xuaW1wb3J0IEJhY2tUb1RvcEJ1dHRvbiBmcm9tIFwiLi4vY29tcG9uZW50cy9iYWNrVG9Ub3AuanN4XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoe2NvbXBhbnlJbmZvLCBoaXN0b3JpZXN9KSB7XG4gIGNvbnN0IFtpc0V4cGFuZGVkLCBzZXRJc0V4cGFuZGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBoYW5kbGVFeHBhbmQgPSAoKSA9PiB7XG4gICAgc2V0SXNFeHBhbmRlZCghaXNFeHBhbmRlZCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICAgIDw+XG4gICAgICAgIDxtYWluXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0xMCBiZy1ncmF5LTEwMCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICBpbml0aWFsPXt7b3BhY2l0eTogMH19XG4gICAgICAgICAgICAgIGFuaW1hdGU9e3tvcGFjaXR5OiAxfX1cbiAgICAgICAgICAgICAgdHJhbnNpdGlvbj17e2R1cmF0aW9uOiAxLjV9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctNHhsIGJnLXdoaXRlLzkwIGJhY2tkcm9wLWJsdXItc20gcm91bmRlZC1sZyBzaGFkb3ctbWQgcC02IHJlbGF0aXZlXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDRcIiBndXR0ZXJCb3R0b20gY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyIHRleHQtZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgV2VsY29tZSB0byBTcGFjZVggRXhwbG9yZXJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXG4gICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnlcIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwYW5kfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtNCBtYi0yIGJnLWJsdWUtNTAwIGhvdmVyOmJnLWJsdWUtNzAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHB5LTIgcHgtNCByb3VuZGVkIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpzaGFkb3ctb3V0bGluZSB0cmFuc2Zvcm0gdHJhbnNpdGlvbiBob3ZlcjpzY2FsZS0xMDUgZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIFZpZXcgQ29tcGFueSBJbmZvIGFuZCBIaXN0b3J5XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7aXNFeHBhbmRlZCAmJiAoXG4gICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwibXQtNCBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgPENhcmRDb250ZW50PlxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDZcIiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtbGdcIj5Db21wYW55IEluZm88L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNsYXNzTmFtZT1cInRleHQtZ3JheS03MDBcIj57Y29tcGFueUluZm8uc3VtbWFyeX08L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5PkZvdW5kZWQ6IHtjb21wYW55SW5mby5mb3VuZGVkfTwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHk+Rm91bmRlcjoge2NvbXBhbnlJbmZvLmZvdW5kZXJ9PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeT5DRU86IHtjb21wYW55SW5mby5jZW99PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDZcIiBjbGFzc05hbWU9XCJtdC00IGZvbnQtc2VtaWJvbGQgdGV4dC1sZ1wiPkhpc3Rvcnk8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgICAgIHtoaXN0b3JpZXMubWFwKChoaXN0b3J5KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aGlzdG9yeS5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aGlsZUhvdmVyPXt7c2NhbGU6IDEuMDN9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm15LTIgcC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93XCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRDb250ZW50PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5PkV2ZW50IERhdGU6IHtoaXN0b3J5LmV2ZW50X2RhdGVfdXRjfTwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeT5UaXRsZToge2hpc3RvcnkudGl0bGV9PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5PkRldGFpbHM6IHtoaXN0b3J5LmRldGFpbHN9PC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtoaXN0b3J5LmxpbmtzICYmIGhpc3RvcnkubGlua3MuYXJ0aWNsZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXtoaXN0b3J5LmxpbmtzLmFydGljbGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwIGhvdmVyOnRleHQtYmx1ZS04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0zMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVhZCBNb3JlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgPEJveCBtdD1cIjhcIiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNVwiIGd1dHRlckJvdHRvbSBjbGFzc05hbWU9XCJjb2wtc3Bhbi0yIHRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XG4gICAgICAgICAgICAgICAgRXhwbG9yZSBMaXN0aW5nc1xuICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgIHtbJ2xhdW5jaGVzJywgJ3BheWxvYWRzJywgJ2NvcmVzJywgJ3JvY2tldHMnLCAnc2hpcHMnLCAnbGF1bmNocGFkcyddLm1hcChjYXRlZ29yeSA9PiAoXG4gICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0ga2V5PXtjYXRlZ29yeX0+XG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9e2AvJHtjYXRlZ29yeX0vcGFnZS8wYH0gcGFzc0hyZWY+XG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctYmx1ZS01MDAgaG92ZXI6YmctYmx1ZS03MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgcHktMiBweC00IHJvdW5kZWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnNoYWRvdy1vdXRsaW5lIHRyYW5zZm9ybSB0cmFuc2l0aW9uIGhvdmVyOnNjYWxlLTEwNSBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXRcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtgJHtjYXRlZ29yeS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIGNhdGVnb3J5LnNsaWNlKDEpfSBMaXN0aW5nYH1cbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgPC9HcmlkPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICA8QmFja1RvVG9wQnV0dG9uLz5cbiAgICAgICAgPC9tYWluPlxuICAgICAgPC8+XG4gICk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdGF0aWNQcm9wcygpIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB7ZGF0YTogaGlzdG9yeURhdGF9ID0gYXdhaXQgYXhpb3MuZ2V0KFwiaHR0cHM6Ly9hcGkuc3BhY2V4ZGF0YS5jb20vdjQvaGlzdG9yeVwiKTtcbiAgICBjb25zdCBzb3J0ZWRIaXN0b3J5RGF0YSA9IGhpc3RvcnlEYXRhLnNvcnQoKGEsIGIpID0+IG5ldyBEYXRlKGIuZXZlbnRfZGF0ZV91dGMpIC0gbmV3IERhdGUoYS5ldmVudF9kYXRlX3V0YykpO1xuICAgIGNvbnN0IHJlY2VudEhpc3RvcmllcyA9IHNvcnRlZEhpc3RvcnlEYXRhLnNsaWNlKDAsIDUpO1xuXG4gICAgY29uc3Qge2RhdGE6IGNvbXBhbnlJbmZvfSA9IGF3YWl0IGF4aW9zLmdldChcImh0dHBzOi8vYXBpLnNwYWNleGRhdGEuY29tL3Y0L2NvbXBhbnlcIik7XG5cbiAgICByZXR1cm4ge1xuICAgICAgcHJvcHM6IHtcbiAgICAgICAgY29tcGFueUluZm8sXG4gICAgICAgIGhpc3RvcmllczogcmVjZW50SGlzdG9yaWVzXG4gICAgICB9LFxuICAgICAgcmV2YWxpZGF0ZTogODY0MDBcbiAgICB9O1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgIHJldHVybiB7XG4gICAgICBwcm9wczoge1xuICAgICAgICBjb21wYW55SW5mbzoge30sXG4gICAgICAgIGhpc3RvcmllczogW11cbiAgICAgIH1cbiAgICB9O1xuICB9XG59Il0sIm5hbWVzIjpbIkxpbmsiLCJ1c2VTdGF0ZSIsIm1vdGlvbiIsIkJveCIsIkJ1dHRvbiIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkdyaWQiLCJUeXBvZ3JhcGh5IiwiYXhpb3MiLCJCYWNrVG9Ub3BCdXR0b24iLCJIb21lIiwiY29tcGFueUluZm8iLCJoaXN0b3JpZXMiLCJpc0V4cGFuZGVkIiwic2V0SXNFeHBhbmRlZCIsImhhbmRsZUV4cGFuZCIsIm1haW4iLCJjbGFzc05hbWUiLCJkaXYiLCJpbml0aWFsIiwib3BhY2l0eSIsImFuaW1hdGUiLCJ0cmFuc2l0aW9uIiwiZHVyYXRpb24iLCJ2YXJpYW50IiwiZ3V0dGVyQm90dG9tIiwiY29sb3IiLCJvbkNsaWNrIiwic3VtbWFyeSIsImZvdW5kZWQiLCJmb3VuZGVyIiwiY2VvIiwibWFwIiwiaGlzdG9yeSIsIndoaWxlSG92ZXIiLCJzY2FsZSIsImV2ZW50X2RhdGVfdXRjIiwidGl0bGUiLCJkZXRhaWxzIiwibGlua3MiLCJhcnRpY2xlIiwiYSIsImhyZWYiLCJ0YXJnZXQiLCJyZWwiLCJpZCIsIm10IiwiY2F0ZWdvcnkiLCJpdGVtIiwieHMiLCJwYXNzSHJlZiIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJnZXRTdGF0aWNQcm9wcyIsImRhdGEiLCJoaXN0b3J5RGF0YSIsImdldCIsInNvcnRlZEhpc3RvcnlEYXRhIiwic29ydCIsImIiLCJEYXRlIiwicmVjZW50SGlzdG9yaWVzIiwicHJvcHMiLCJyZXZhbGlkYXRlIiwiZXJyb3IiLCJjb25zb2xlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/index.jsx\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@mui/base/utils":
/*!**********************************!*\
  !*** external "@mui/base/utils" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/base/utils");

/***/ }),

/***/ "@mui/icons-material/ArrowUpward":
/*!**************************************************!*\
  !*** external "@mui/icons-material/ArrowUpward" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ArrowUpward");

/***/ }),

/***/ "@mui/icons-material/NavigateNext":
/*!***************************************************!*\
  !*** external "@mui/icons-material/NavigateNext" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/NavigateNext");

/***/ }),

/***/ "@mui/system":
/*!******************************!*\
  !*** external "@mui/system" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system");

/***/ }),

/***/ "@mui/system/colorManipulator":
/*!***********************************************!*\
  !*** external "@mui/system/colorManipulator" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/colorManipulator");

/***/ }),

/***/ "@mui/system/createStyled":
/*!*******************************************!*\
  !*** external "@mui/system/createStyled" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/createStyled");

/***/ }),

/***/ "@mui/system/createTheme":
/*!******************************************!*\
  !*** external "@mui/system/createTheme" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/createTheme");

/***/ }),

/***/ "@mui/system/styleFunctionSx":
/*!**********************************************!*\
  !*** external "@mui/system/styleFunctionSx" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/styleFunctionSx");

/***/ }),

/***/ "@mui/system/useThemeProps":
/*!********************************************!*\
  !*** external "@mui/system/useThemeProps" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/useThemeProps");

/***/ }),

/***/ "@mui/utils":
/*!*****************************!*\
  !*** external "@mui/utils" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils");

/***/ }),

/***/ "@mui/utils/capitalize":
/*!****************************************!*\
  !*** external "@mui/utils/capitalize" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/capitalize");

/***/ }),

/***/ "@mui/utils/chainPropTypes":
/*!********************************************!*\
  !*** external "@mui/utils/chainPropTypes" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/chainPropTypes");

/***/ }),

/***/ "@mui/utils/composeClasses":
/*!********************************************!*\
  !*** external "@mui/utils/composeClasses" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/composeClasses");

/***/ }),

/***/ "@mui/utils/deepmerge":
/*!***************************************!*\
  !*** external "@mui/utils/deepmerge" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/deepmerge");

/***/ }),

/***/ "@mui/utils/elementAcceptingRef":
/*!*************************************************!*\
  !*** external "@mui/utils/elementAcceptingRef" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/elementAcceptingRef");

/***/ }),

/***/ "@mui/utils/elementTypeAcceptingRef":
/*!*****************************************************!*\
  !*** external "@mui/utils/elementTypeAcceptingRef" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/elementTypeAcceptingRef");

/***/ }),

/***/ "@mui/utils/formatMuiErrorMessage":
/*!***************************************************!*\
  !*** external "@mui/utils/formatMuiErrorMessage" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/formatMuiErrorMessage");

/***/ }),

/***/ "@mui/utils/generateUtilityClass":
/*!**************************************************!*\
  !*** external "@mui/utils/generateUtilityClass" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/generateUtilityClass");

/***/ }),

/***/ "@mui/utils/generateUtilityClasses":
/*!****************************************************!*\
  !*** external "@mui/utils/generateUtilityClasses" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/generateUtilityClasses");

/***/ }),

/***/ "@mui/utils/integerPropType":
/*!*********************************************!*\
  !*** external "@mui/utils/integerPropType" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/integerPropType");

/***/ }),

/***/ "@mui/utils/refType":
/*!*************************************!*\
  !*** external "@mui/utils/refType" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/refType");

/***/ }),

/***/ "@mui/utils/requirePropFactory":
/*!************************************************!*\
  !*** external "@mui/utils/requirePropFactory" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/requirePropFactory");

/***/ }),

/***/ "@mui/utils/resolveProps":
/*!******************************************!*\
  !*** external "@mui/utils/resolveProps" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/resolveProps");

/***/ }),

/***/ "@mui/utils/useEventCallback":
/*!**********************************************!*\
  !*** external "@mui/utils/useEventCallback" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useEventCallback");

/***/ }),

/***/ "@mui/utils/useForkRef":
/*!****************************************!*\
  !*** external "@mui/utils/useForkRef" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useForkRef");

/***/ }),

/***/ "@mui/utils/useIsFocusVisible":
/*!***********************************************!*\
  !*** external "@mui/utils/useIsFocusVisible" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useIsFocusVisible");

/***/ }),

/***/ "@mui/utils/useTimeout":
/*!****************************************!*\
  !*** external "@mui/utils/useTimeout" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useTimeout");

/***/ }),

/***/ "clsx":
/*!***********************!*\
  !*** external "clsx" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("clsx");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-is":
/*!***************************!*\
  !*** external "react-is" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-is");

/***/ }),

/***/ "react-transition-group":
/*!*****************************************!*\
  !*** external "react-transition-group" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ "framer-motion":
/*!********************************!*\
  !*** external "framer-motion" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = import("framer-motion");;

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/react-icons","vendor-chunks/@mui","vendor-chunks/@babel"], () => (__webpack_exec__("./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.jsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();