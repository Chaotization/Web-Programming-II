/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/rockets/[id]";
exports.ids = ["pages/rockets/[id]"];
exports.modules = {

/***/ "__barrel_optimize__?names=Breadcrumbs,Typography!=!./node_modules/@mui/material/index.js":
/*!************************************************************************************************!*\
  !*** __barrel_optimize__?names=Breadcrumbs,Typography!=!./node_modules/@mui/material/index.js ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Breadcrumbs: () => (/* reexport default from dynamic */ _Breadcrumbs__WEBPACK_IMPORTED_MODULE_0___default.a),\n/* harmony export */   Typography: () => (/* reexport default from dynamic */ _Typography__WEBPACK_IMPORTED_MODULE_1___default.a)\n/* harmony export */ });\n/* harmony import */ var _Breadcrumbs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Breadcrumbs */ \"./node_modules/@mui/material/node/Breadcrumbs/index.js\");\n/* harmony import */ var _Breadcrumbs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Breadcrumbs__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Typography */ \"./node_modules/@mui/material/node/Typography/index.js\");\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Typography__WEBPACK_IMPORTED_MODULE_1__);\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1CcmVhZGNydW1icyxUeXBvZ3JhcGh5IT0hLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQ3NEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbGFiNy8uL25vZGVfbW9kdWxlcy9AbXVpL21hdGVyaWFsL2luZGV4LmpzP2IyM2QiXSwic291cmNlc0NvbnRlbnQiOlsiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEJyZWFkY3J1bWJzIH0gZnJvbSBcIi4vQnJlYWRjcnVtYnNcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBUeXBvZ3JhcGh5IH0gZnJvbSBcIi4vVHlwb2dyYXBoeVwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Breadcrumbs,Typography!=!./node_modules/@mui/material/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Button,Card,CardContent,Typography!=!./node_modules/@mui/material/index.js":
/*!************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Card,CardContent,Typography!=!./node_modules/@mui/material/index.js ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Button: () => (/* reexport default from dynamic */ _Button__WEBPACK_IMPORTED_MODULE_0___default.a),\n/* harmony export */   Card: () => (/* reexport default from dynamic */ _Card__WEBPACK_IMPORTED_MODULE_1___default.a),\n/* harmony export */   CardContent: () => (/* reexport default from dynamic */ _CardContent__WEBPACK_IMPORTED_MODULE_2___default.a),\n/* harmony export */   Typography: () => (/* reexport default from dynamic */ _Typography__WEBPACK_IMPORTED_MODULE_3___default.a)\n/* harmony export */ });\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ \"./node_modules/@mui/material/node/Button/index.js\");\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Button__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Card */ \"./node_modules/@mui/material/node/Card/index.js\");\n/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Card__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _CardContent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CardContent */ \"./node_modules/@mui/material/node/CardContent/index.js\");\n/* harmony import */ var _CardContent__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_CardContent__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Typography */ \"./node_modules/@mui/material/node/Typography/index.js\");\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Typography__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1CdXR0b24sQ2FyZCxDYXJkQ29udGVudCxUeXBvZ3JhcGh5IT0hLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQzRDO0FBQ0o7QUFDYyIsInNvdXJjZXMiOlsid2VicGFjazovL2xhYjcvLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcz9hZTA4Il0sInNvdXJjZXNDb250ZW50IjpbIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBCdXR0b24gfSBmcm9tIFwiLi9CdXR0b25cIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBDYXJkIH0gZnJvbSBcIi4vQ2FyZFwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIENhcmRDb250ZW50IH0gZnJvbSBcIi4vQ2FyZENvbnRlbnRcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBUeXBvZ3JhcGh5IH0gZnJvbSBcIi4vVHlwb2dyYXBoeVwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Button,Card,CardContent,Typography!=!./node_modules/@mui/material/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Collapse,IconButton,Typography!=!./node_modules/@mui/material/index.js":
/*!********************************************************************************************************!*\
  !*** __barrel_optimize__?names=Collapse,IconButton,Typography!=!./node_modules/@mui/material/index.js ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Collapse: () => (/* reexport default from dynamic */ _Collapse__WEBPACK_IMPORTED_MODULE_0___default.a),\n/* harmony export */   IconButton: () => (/* reexport default from dynamic */ _IconButton__WEBPACK_IMPORTED_MODULE_1___default.a),\n/* harmony export */   Typography: () => (/* reexport default from dynamic */ _Typography__WEBPACK_IMPORTED_MODULE_2___default.a)\n/* harmony export */ });\n/* harmony import */ var _Collapse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Collapse */ \"./node_modules/@mui/material/node/Collapse/index.js\");\n/* harmony import */ var _Collapse__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Collapse__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _IconButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./IconButton */ \"./node_modules/@mui/material/node/IconButton/index.js\");\n/* harmony import */ var _IconButton__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_IconButton__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Typography */ \"./node_modules/@mui/material/node/Typography/index.js\");\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Typography__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1Db2xsYXBzZSxJY29uQnV0dG9uLFR5cG9ncmFwaHkhPSEuL25vZGVfbW9kdWxlcy9AbXVpL21hdGVyaWFsL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFDZ0Q7QUFDSSIsInNvdXJjZXMiOlsid2VicGFjazovL2xhYjcvLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcz9hMjE3Il0sInNvdXJjZXNDb250ZW50IjpbIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBDb2xsYXBzZSB9IGZyb20gXCIuL0NvbGxhcHNlXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgSWNvbkJ1dHRvbiB9IGZyb20gXCIuL0ljb25CdXR0b25cIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBUeXBvZ3JhcGh5IH0gZnJvbSBcIi4vVHlwb2dyYXBoeVwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Collapse,IconButton,Typography!=!./node_modules/@mui/material/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=ExpandLess,ExpandMore!=!./node_modules/@mui/icons-material/esm/index.js":
/*!*********************************************************************************************************!*\
  !*** __barrel_optimize__?names=ExpandLess,ExpandMore!=!./node_modules/@mui/icons-material/esm/index.js ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ExpandLess: () => (/* reexport safe */ _ExpandLess__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   ExpandMore: () => (/* reexport safe */ _ExpandMore__WEBPACK_IMPORTED_MODULE_1__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _ExpandLess__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ExpandLess */ \"./node_modules/@mui/icons-material/esm/ExpandLess.js\");\n/* harmony import */ var _ExpandMore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ExpandMore */ \"./node_modules/@mui/icons-material/esm/ExpandMore.js\");\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1FeHBhbmRMZXNzLEV4cGFuZE1vcmUhPSEuL25vZGVfbW9kdWxlcy9AbXVpL2ljb25zLW1hdGVyaWFsL2VzbS9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUNvRCIsInNvdXJjZXMiOlsid2VicGFjazovL2xhYjcvLi9ub2RlX21vZHVsZXMvQG11aS9pY29ucy1tYXRlcmlhbC9lc20vaW5kZXguanM/MGM1YSJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgRXhwYW5kTGVzcyB9IGZyb20gXCIuL0V4cGFuZExlc3NcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBFeHBhbmRNb3JlIH0gZnJvbSBcIi4vRXhwYW5kTW9yZVwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=ExpandLess,ExpandMore!=!./node_modules/@mui/icons-material/esm/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!./node_modules/@mui/material/index.js":
/*!***************************************************************************************************!*\
  !*** __barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!./node_modules/@mui/material/index.js ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Fab: () => (/* reexport default from dynamic */ _Fab__WEBPACK_IMPORTED_MODULE_0___default.a),\n/* harmony export */   Zoom: () => (/* reexport safe */ _Zoom__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   useScrollTrigger: () => (/* reexport safe */ _useScrollTrigger__WEBPACK_IMPORTED_MODULE_2__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Fab__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Fab */ \"./node_modules/@mui/material/node/Fab/index.js\");\n/* harmony import */ var _Fab__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Fab__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Zoom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Zoom */ \"./node_modules/@mui/material/node/Zoom/index.js\");\n/* harmony import */ var _useScrollTrigger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useScrollTrigger */ \"./node_modules/@mui/material/node/useScrollTrigger/index.js\");\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1GYWIsWm9vbSx1c2VTY3JvbGxUcmlnZ2VyIT0hLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUNzQztBQUNFIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbGFiNy8uL25vZGVfbW9kdWxlcy9AbXVpL21hdGVyaWFsL2luZGV4LmpzP2JiZDQiXSwic291cmNlc0NvbnRlbnQiOlsiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEZhYiB9IGZyb20gXCIuL0ZhYlwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIFpvb20gfSBmcm9tIFwiLi9ab29tXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgdXNlU2Nyb2xsVHJpZ2dlciB9IGZyb20gXCIuL3VzZVNjcm9sbFRyaWdnZXJcIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!./node_modules/@mui/material/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=HiMenu!=!./node_modules/react-icons/hi/index.mjs":
/*!**********************************************************************************!*\
  !*** __barrel_optimize__?names=HiMenu!=!./node_modules/react-icons/hi/index.mjs ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var E_CS_554_hw_hw7_node_modules_react_icons_hi_index_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/react-icons/hi/index.mjs */ "./node_modules/react-icons/hi/index.mjs");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in E_CS_554_hw_hw7_node_modules_react_icons_hi_index_mjs__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => E_CS_554_hw_hw7_node_modules_react_icons_hi_index_mjs__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "./public/img/No_image.jpg":
/*!*********************************!*\
  !*** ./public/img/No_image.jpg ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({\"src\":\"/_next/static/media/No_image.fd92472a.jpg\",\"height\":547,\"width\":547,\"blurDataURL\":\"/_next/image?url=%2F_next%2Fstatic%2Fmedia%2FNo_image.fd92472a.jpg&w=8&q=70\",\"blurWidth\":8,\"blurHeight\":8});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wdWJsaWMvaW1nL05vX2ltYWdlLmpwZyIsIm1hcHBpbmdzIjoiOzs7O0FBQUEsaUVBQWUsQ0FBQyxvTUFBb00iLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vcHVibGljL2ltZy9Ob19pbWFnZS5qcGc/YWYwZCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCB7XCJzcmNcIjpcIi9fbmV4dC9zdGF0aWMvbWVkaWEvTm9faW1hZ2UuZmQ5MjQ3MmEuanBnXCIsXCJoZWlnaHRcIjo1NDcsXCJ3aWR0aFwiOjU0NyxcImJsdXJEYXRhVVJMXCI6XCIvX25leHQvaW1hZ2U/dXJsPSUyRl9uZXh0JTJGc3RhdGljJTJGbWVkaWElMkZOb19pbWFnZS5mZDkyNDcyYS5qcGcmdz04JnE9NzBcIixcImJsdXJXaWR0aFwiOjgsXCJibHVySGVpZ2h0XCI6OH07Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./public/img/No_image.jpg\n");

/***/ }),

/***/ "./public/img/logo.jpg":
/*!*****************************!*\
  !*** ./public/img/logo.jpg ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({\"src\":\"/_next/static/media/logo.e29ae997.jpg\",\"height\":160,\"width\":1280,\"blurDataURL\":\"/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Flogo.e29ae997.jpg&w=8&q=70\",\"blurWidth\":8,\"blurHeight\":1});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wdWJsaWMvaW1nL2xvZ28uanBnIiwibWFwcGluZ3MiOiI7Ozs7QUFBQSxpRUFBZSxDQUFDLDZMQUE2TCIsInNvdXJjZXMiOlsid2VicGFjazovL2xhYjcvLi9wdWJsaWMvaW1nL2xvZ28uanBnPzM5NDIiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL21lZGlhL2xvZ28uZTI5YWU5OTcuanBnXCIsXCJoZWlnaHRcIjoxNjAsXCJ3aWR0aFwiOjEyODAsXCJibHVyRGF0YVVSTFwiOlwiL19uZXh0L2ltYWdlP3VybD0lMkZfbmV4dCUyRnN0YXRpYyUyRm1lZGlhJTJGbG9nby5lMjlhZTk5Ny5qcGcmdz04JnE9NzBcIixcImJsdXJXaWR0aFwiOjgsXCJibHVySGVpZ2h0XCI6MX07Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./public/img/logo.jpg\n");

/***/ }),

/***/ "./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Frockets%2F%5Bid%5D&preferredRegion=&absolutePagePath=.%2Fpages%5Crockets%5C%5Bid%5D.jsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Frockets%2F%5Bid%5D&preferredRegion=&absolutePagePath=.%2Fpages%5Crockets%5C%5Bid%5D.jsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D! ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),\n/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),\n/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),\n/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),\n/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),\n/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),\n/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages/module.compiled */ \"./node_modules/next/dist/server/future/route-modules/pages/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! private-next-pages/_document */ \"./pages/_document.jsx\");\n/* harmony import */ var private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! private-next-pages/_app */ \"./pages/_app.jsx\");\n/* harmony import */ var _pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages\\rockets\\[id].jsx */ \"./pages/rockets/[id].jsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__, _pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__]);\n([private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__, _pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n// Import the app and document modules.\n\n\n// Import the userland code.\n\n// Re-export the component (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__, \"default\"));\n// Re-export methods.\nconst getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__, \"getStaticProps\");\nconst getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__, \"getStaticPaths\");\nconst getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__, \"getServerSideProps\");\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__, \"config\");\nconst reportWebVitals = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__, \"reportWebVitals\");\n// Re-export legacy methods.\nconst unstable_getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticProps\");\nconst unstable_getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticPaths\");\nconst unstable_getStaticParams = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticParams\");\nconst unstable_getServerProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getServerProps\");\nconst unstable_getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getServerSideProps\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES,\n        page: \"/rockets/[id]\",\n        pathname: \"/rockets/[id]\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    components: {\n        App: private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n        Document: private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n    },\n    userland: _pages_rockets_id_jsx__WEBPACK_IMPORTED_MODULE_5__\n});\n\n//# sourceMappingURL=pages.js.map\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTJnBhZ2U9JTJGcm9ja2V0cyUyRiU1QmlkJTVEJnByZWZlcnJlZFJlZ2lvbj0mYWJzb2x1dGVQYWdlUGF0aD0uJTJGcGFnZXMlNUNyb2NrZXRzJTVDJTVCaWQlNUQuanN4JmFic29sdXRlQXBwUGF0aD1wcml2YXRlLW5leHQtcGFnZXMlMkZfYXBwJmFic29sdXRlRG9jdW1lbnRQYXRoPXByaXZhdGUtbmV4dC1wYWdlcyUyRl9kb2N1bWVudCZtaWRkbGV3YXJlQ29uZmlnQmFzZTY0PWUzMCUzRCEiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUErRjtBQUNoQztBQUNMO0FBQzFEO0FBQ29EO0FBQ1Y7QUFDMUM7QUFDdUQ7QUFDdkQ7QUFDQSxpRUFBZSx3RUFBSyxDQUFDLGtEQUFRLFlBQVksRUFBQztBQUMxQztBQUNPLHVCQUF1Qix3RUFBSyxDQUFDLGtEQUFRO0FBQ3JDLHVCQUF1Qix3RUFBSyxDQUFDLGtEQUFRO0FBQ3JDLDJCQUEyQix3RUFBSyxDQUFDLGtEQUFRO0FBQ3pDLGVBQWUsd0VBQUssQ0FBQyxrREFBUTtBQUM3Qix3QkFBd0Isd0VBQUssQ0FBQyxrREFBUTtBQUM3QztBQUNPLGdDQUFnQyx3RUFBSyxDQUFDLGtEQUFRO0FBQzlDLGdDQUFnQyx3RUFBSyxDQUFDLGtEQUFRO0FBQzlDLGlDQUFpQyx3RUFBSyxDQUFDLGtEQUFRO0FBQy9DLGdDQUFnQyx3RUFBSyxDQUFDLGtEQUFRO0FBQzlDLG9DQUFvQyx3RUFBSyxDQUFDLGtEQUFRO0FBQ3pEO0FBQ08sd0JBQXdCLHlHQUFnQjtBQUMvQztBQUNBLGNBQWMseUVBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLFdBQVc7QUFDWCxnQkFBZ0I7QUFDaEIsS0FBSztBQUNMLFlBQVk7QUFDWixDQUFDOztBQUVELGlDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbGFiNy8/MDUzMSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQYWdlc1JvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLW1vZHVsZXMvcGFnZXMvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgaG9pc3QgfSBmcm9tIFwibmV4dC9kaXN0L2J1aWxkL3RlbXBsYXRlcy9oZWxwZXJzXCI7XG4vLyBJbXBvcnQgdGhlIGFwcCBhbmQgZG9jdW1lbnQgbW9kdWxlcy5cbmltcG9ydCBEb2N1bWVudCBmcm9tIFwicHJpdmF0ZS1uZXh0LXBhZ2VzL19kb2N1bWVudFwiO1xuaW1wb3J0IEFwcCBmcm9tIFwicHJpdmF0ZS1uZXh0LXBhZ2VzL19hcHBcIjtcbi8vIEltcG9ydCB0aGUgdXNlcmxhbmQgY29kZS5cbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCIuL3BhZ2VzXFxcXHJvY2tldHNcXFxcW2lkXS5qc3hcIjtcbi8vIFJlLWV4cG9ydCB0aGUgY29tcG9uZW50IChzaG91bGQgYmUgdGhlIGRlZmF1bHQgZXhwb3J0KS5cbmV4cG9ydCBkZWZhdWx0IGhvaXN0KHVzZXJsYW5kLCBcImRlZmF1bHRcIik7XG4vLyBSZS1leHBvcnQgbWV0aG9kcy5cbmV4cG9ydCBjb25zdCBnZXRTdGF0aWNQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCBcImdldFN0YXRpY1Byb3BzXCIpO1xuZXhwb3J0IGNvbnN0IGdldFN0YXRpY1BhdGhzID0gaG9pc3QodXNlcmxhbmQsIFwiZ2V0U3RhdGljUGF0aHNcIik7XG5leHBvcnQgY29uc3QgZ2V0U2VydmVyU2lkZVByb3BzID0gaG9pc3QodXNlcmxhbmQsIFwiZ2V0U2VydmVyU2lkZVByb3BzXCIpO1xuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IGhvaXN0KHVzZXJsYW5kLCBcImNvbmZpZ1wiKTtcbmV4cG9ydCBjb25zdCByZXBvcnRXZWJWaXRhbHMgPSBob2lzdCh1c2VybGFuZCwgXCJyZXBvcnRXZWJWaXRhbHNcIik7XG4vLyBSZS1leHBvcnQgbGVnYWN5IG1ldGhvZHMuXG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U3RhdGljUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgXCJ1bnN0YWJsZV9nZXRTdGF0aWNQcm9wc1wiKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTdGF0aWNQYXRocyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFN0YXRpY1BhdGhzXCIpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1BhcmFtcyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFN0YXRpY1BhcmFtc1wiKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTZXJ2ZXJQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFNlcnZlclByb3BzXCIpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFNlcnZlclNpZGVQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFNlcnZlclNpZGVQcm9wc1wiKTtcbi8vIENyZWF0ZSBhbmQgZXhwb3J0IHRoZSByb3V0ZSBtb2R1bGUgdGhhdCB3aWxsIGJlIGNvbnN1bWVkLlxuZXhwb3J0IGNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IFBhZ2VzUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLlBBR0VTLFxuICAgICAgICBwYWdlOiBcIi9yb2NrZXRzL1tpZF1cIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL3JvY2tldHMvW2lkXVwiLFxuICAgICAgICAvLyBUaGUgZm9sbG93aW5nIGFyZW4ndCB1c2VkIGluIHByb2R1Y3Rpb24uXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcIlwiXG4gICAgfSxcbiAgICBjb21wb25lbnRzOiB7XG4gICAgICAgIEFwcCxcbiAgICAgICAgRG9jdW1lbnRcbiAgICB9LFxuICAgIHVzZXJsYW5kXG59KTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFnZXMuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Frockets%2F%5Bid%5D&preferredRegion=&absolutePagePath=.%2Fpages%5Crockets%5C%5Bid%5D.jsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "./components/backTotop.jsx":
/*!**********************************!*\
  !*** ./components/backTotop.jsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!@mui/material */ \"__barrel_optimize__?names=Fab,Zoom,useScrollTrigger!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var _mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/icons-material/ArrowUpward */ \"@mui/icons-material/ArrowUpward\");\n/* harmony import */ var _mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1__);\n\n\n\nconst BackToTopButton = ({ threshold = 100, bottom = \"2rem\", right = \"2rem\", color = \"secondary\", size = \"small\" })=>{\n    const trigger = (0,_barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__.useScrollTrigger)({\n        disableHysteresis: true,\n        threshold: threshold\n    });\n    const handleClick = ()=>{\n        window.scrollTo({\n            top: 0,\n            behavior: \"smooth\"\n        });\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__.Zoom, {\n        in: trigger,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Fab_Zoom_useScrollTrigger_mui_material__WEBPACK_IMPORTED_MODULE_2__.Fab, {\n            color: color,\n            size: size,\n            onClick: handleClick,\n            sx: {\n                position: \"fixed\",\n                bottom: bottom,\n                right: right\n            },\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_icons_material_ArrowUpward__WEBPACK_IMPORTED_MODULE_1___default()), {}, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backTotop.jsx\",\n                lineNumber: 35,\n                columnNumber: 17\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backTotop.jsx\",\n            lineNumber: 25,\n            columnNumber: 13\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backTotop.jsx\",\n        lineNumber: 24,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BackToTopButton);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL2JhY2tUb3RvcC5qc3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUE0RDtBQUNFO0FBRTlELE1BQU1JLGtCQUFrQixDQUFDLEVBQ0lDLFlBQVksR0FBRyxFQUNmQyxTQUFTLE1BQU0sRUFDZkMsUUFBUSxNQUFNLEVBQ2RDLFFBQVEsV0FBVyxFQUNuQkMsT0FBTyxPQUFPLEVBQ2pCO0lBQ3RCLE1BQU1DLFVBQVVULCtHQUFnQkEsQ0FBQztRQUM3QlUsbUJBQW1CO1FBQ25CTixXQUFXQTtJQUNmO0lBRUEsTUFBTU8sY0FBYztRQUNoQkMsT0FBT0MsUUFBUSxDQUFDO1lBQ1pDLEtBQUs7WUFDTEMsVUFBVTtRQUNkO0lBQ0o7SUFFQSxxQkFDSSw4REFBQ2QsK0ZBQUlBO1FBQUNlLElBQUlQO2tCQUNOLDRFQUFDViw4RkFBR0E7WUFDQVEsT0FBT0E7WUFDUEMsTUFBTUE7WUFDTlMsU0FBU047WUFDVE8sSUFBSTtnQkFDQUMsVUFBVTtnQkFDVmQsUUFBUUE7Z0JBQ1JDLE9BQU9BO1lBQ1g7c0JBRUEsNEVBQUNKLHdFQUFlQTs7Ozs7Ozs7Ozs7Ozs7O0FBSWhDO0FBRUEsaUVBQWVDLGVBQWVBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vY29tcG9uZW50cy9iYWNrVG90b3AuanN4PzNkMDgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRmFiLCB1c2VTY3JvbGxUcmlnZ2VyLCBab29tIH0gZnJvbSAnQG11aS9tYXRlcmlhbCc7XHJcbmltcG9ydCBBcnJvd1Vwd2FyZEljb24gZnJvbSAnQG11aS9pY29ucy1tYXRlcmlhbC9BcnJvd1Vwd2FyZCc7XHJcblxyXG5jb25zdCBCYWNrVG9Ub3BCdXR0b24gPSAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocmVzaG9sZCA9IDEwMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b20gPSAnMnJlbScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHQgPSAnMnJlbScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3IgPSAnc2Vjb25kYXJ5JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplID0gJ3NtYWxsJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgfSkgPT4ge1xyXG4gICAgY29uc3QgdHJpZ2dlciA9IHVzZVNjcm9sbFRyaWdnZXIoe1xyXG4gICAgICAgIGRpc2FibGVIeXN0ZXJlc2lzOiB0cnVlLFxyXG4gICAgICAgIHRocmVzaG9sZDogdGhyZXNob2xkLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoKSA9PiB7XHJcbiAgICAgICAgd2luZG93LnNjcm9sbFRvKHtcclxuICAgICAgICAgICAgdG9wOiAwLFxyXG4gICAgICAgICAgICBiZWhhdmlvcjogJ3Ntb290aCcsXHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFpvb20gaW49e3RyaWdnZXJ9PlxyXG4gICAgICAgICAgICA8RmFiXHJcbiAgICAgICAgICAgICAgICBjb2xvcj17Y29sb3J9XHJcbiAgICAgICAgICAgICAgICBzaXplPXtzaXplfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xpY2t9XHJcbiAgICAgICAgICAgICAgICBzeD17e1xyXG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvdHRvbTogYm90dG9tLFxyXG4gICAgICAgICAgICAgICAgICAgIHJpZ2h0OiByaWdodCxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxBcnJvd1Vwd2FyZEljb24gLz5cclxuICAgICAgICAgICAgPC9GYWI+XHJcbiAgICAgICAgPC9ab29tPlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJhY2tUb1RvcEJ1dHRvbjtcclxuIl0sIm5hbWVzIjpbIkZhYiIsInVzZVNjcm9sbFRyaWdnZXIiLCJab29tIiwiQXJyb3dVcHdhcmRJY29uIiwiQmFja1RvVG9wQnV0dG9uIiwidGhyZXNob2xkIiwiYm90dG9tIiwicmlnaHQiLCJjb2xvciIsInNpemUiLCJ0cmlnZ2VyIiwiZGlzYWJsZUh5c3RlcmVzaXMiLCJoYW5kbGVDbGljayIsIndpbmRvdyIsInNjcm9sbFRvIiwidG9wIiwiYmVoYXZpb3IiLCJpbiIsIm9uQ2xpY2siLCJzeCIsInBvc2l0aW9uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/backTotop.jsx\n");

/***/ }),

/***/ "./components/backgroundOverlay.jsx":
/*!******************************************!*\
  !*** ./components/backgroundOverlay.jsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst BackgroundOverlay = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"fixed inset-0 pointer-events-none z-[-1]\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"absolute inset-0 bg-gradient-to-r from-blue-500 to-pink-500 opacity-75\"\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backgroundOverlay.jsx\",\n                lineNumber: 6,\n                columnNumber: 13\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"absolute inset-0 bg-noise\"\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backgroundOverlay.jsx\",\n                lineNumber: 7,\n                columnNumber: 13\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\backgroundOverlay.jsx\",\n        lineNumber: 5,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BackgroundOverlay);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL2JhY2tncm91bmRPdmVybGF5LmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBMEI7QUFFMUIsTUFBTUMsb0JBQW9CO0lBQ3RCLHFCQUNJLDhEQUFDQztRQUFJQyxXQUFVOzswQkFDWCw4REFBQ0Q7Z0JBQUlDLFdBQVU7Ozs7OzswQkFDZiw4REFBQ0Q7Z0JBQUlDLFdBQVU7Ozs7Ozs7Ozs7OztBQUczQjtBQUVBLGlFQUFlRixpQkFBaUJBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vY29tcG9uZW50cy9iYWNrZ3JvdW5kT3ZlcmxheS5qc3g/NTFjOSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuY29uc3QgQmFja2dyb3VuZE92ZXJsYXkgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBwb2ludGVyLWV2ZW50cy1ub25lIHotWy0xXVwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAwIHRvLXBpbmstNTAwIG9wYWNpdHktNzVcIj48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLW5vaXNlXCI+PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQmFja2dyb3VuZE92ZXJsYXk7XHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIkJhY2tncm91bmRPdmVybGF5IiwiZGl2IiwiY2xhc3NOYW1lIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/backgroundOverlay.jsx\n");

/***/ }),

/***/ "./components/breadCrumbs.jsx":
/*!************************************!*\
  !*** ./components/breadCrumbs.jsx ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _barrel_optimize_names_Breadcrumbs_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! __barrel_optimize__?names=Breadcrumbs,Typography!=!@mui/material */ \"__barrel_optimize__?names=Breadcrumbs,Typography!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var _mui_icons_material_NavigateNext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/NavigateNext */ \"@mui/icons-material/NavigateNext\");\n/* harmony import */ var _mui_icons_material_NavigateNext__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_NavigateNext__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\n\nfunction GetBreadcrumbs() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();\n    const path = router.asPath.split(\"/\").filter((x)=>x && x !== \"page\" && !x.startsWith(\"0\"));\n    function capitalizeFirstLetter(string) {\n        return string.charAt(0).toUpperCase() + string.slice(1);\n    }\n    function isListRoute(segment) {\n        const listRoutes = [\n            \"launches\",\n            \"payloads\",\n            \"cores\",\n            \"rockets\",\n            \"ships\",\n            \"launchpads\"\n        ];\n        return listRoutes.includes(segment.toLowerCase());\n    }\n    function isNonClickableListRoute(segment, index) {\n        if (!isListRoute(segment)) return false;\n        let checkRoute = `/${path.slice(0, index + 1).join(\"/\")}/page/0`;\n        return router.asPath.toLowerCase().startsWith(checkRoute.toLowerCase());\n    }\n    const breadcrumbs = path.map((segment, index)=>{\n        const isLast = index === path.length - 1;\n        let routeTo = `/${path.slice(0, index + 1).join(\"/\")}`;\n        if (isListRoute(segment) && !isLast) {\n            routeTo += \"/page/0\";\n        }\n        const isNonClickable = isNonClickableListRoute(segment, index);\n        return {\n            name: segment,\n            routeTo,\n            isLast,\n            clickable: !isNonClickable\n        };\n    });\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Breadcrumbs_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Breadcrumbs, {\n        \"aria-label\": \"breadcrumb\",\n        separator: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_icons_material_NavigateNext__WEBPACK_IMPORTED_MODULE_2___default()), {\n            fontSize: \"small\"\n        }, void 0, false, {\n            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\breadCrumbs.jsx\",\n            lineNumber: 45,\n            columnNumber: 57\n        }, void 0),\n        sx: {\n            mb: 2\n        },\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {\n                href: \"/\",\n                passHref: true,\n                children: \"Home\"\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\breadCrumbs.jsx\",\n                lineNumber: 46,\n                columnNumber: 13\n            }, this),\n            breadcrumbs.map(({ name, routeTo, isLast, clickable }, index)=>{\n                const displayText = capitalizeFirstLetter(name);\n                if (!isLast && clickable) {\n                    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        href: routeTo,\n                        passHref: true,\n                        children: displayText\n                    }, index, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\breadCrumbs.jsx\",\n                        lineNumber: 53,\n                        columnNumber: 25\n                    }, this);\n                }\n                return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Breadcrumbs_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {\n                    color: \"text.primary\",\n                    children: displayText\n                }, index, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\breadCrumbs.jsx\",\n                    lineNumber: 60,\n                    columnNumber: 21\n                }, this);\n            })\n        ]\n    }, void 0, true, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\breadCrumbs.jsx\",\n        lineNumber: 45,\n        columnNumber: 9\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GetBreadcrumbs);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL2JyZWFkQ3J1bWJzLmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQTBCO0FBQzhCO0FBQ1E7QUFDbkM7QUFDVztBQUV4QyxTQUFTTTtJQUNMLE1BQU1DLFNBQVNGLHNEQUFTQTtJQUN4QixNQUFNRyxPQUFPRCxPQUFPRSxNQUFNLENBQUNDLEtBQUssQ0FBQyxLQUFLQyxNQUFNLENBQUNDLENBQUFBLElBQUtBLEtBQUtBLE1BQU0sVUFBVSxDQUFDQSxFQUFFQyxVQUFVLENBQUM7SUFFckYsU0FBU0Msc0JBQXNCQyxNQUFNO1FBQ2pDLE9BQU9BLE9BQU9DLE1BQU0sQ0FBQyxHQUFHQyxXQUFXLEtBQUtGLE9BQU9HLEtBQUssQ0FBQztJQUN6RDtJQUVBLFNBQVNDLFlBQVlDLE9BQU87UUFDeEIsTUFBTUMsYUFBYTtZQUFDO1lBQVk7WUFBWTtZQUFTO1lBQVc7WUFBUztTQUFhO1FBQ3RGLE9BQU9BLFdBQVdDLFFBQVEsQ0FBQ0YsUUFBUUcsV0FBVztJQUNsRDtJQUVBLFNBQVNDLHdCQUF3QkosT0FBTyxFQUFFSyxLQUFLO1FBQzNDLElBQUksQ0FBQ04sWUFBWUMsVUFBVSxPQUFPO1FBQ2xDLElBQUlNLGFBQWEsQ0FBQyxDQUFDLEVBQUVsQixLQUFLVSxLQUFLLENBQUMsR0FBR08sUUFBUSxHQUFHRSxJQUFJLENBQUMsS0FBSyxPQUFPLENBQUM7UUFDaEUsT0FBT3BCLE9BQU9FLE1BQU0sQ0FBQ2MsV0FBVyxHQUFHVixVQUFVLENBQUNhLFdBQVdILFdBQVc7SUFDeEU7SUFFQSxNQUFNSyxjQUFjcEIsS0FBS3FCLEdBQUcsQ0FBQyxDQUFDVCxTQUFTSztRQUNuQyxNQUFNSyxTQUFTTCxVQUFVakIsS0FBS3VCLE1BQU0sR0FBRztRQUN2QyxJQUFJQyxVQUFVLENBQUMsQ0FBQyxFQUFFeEIsS0FBS1UsS0FBSyxDQUFDLEdBQUdPLFFBQVEsR0FBR0UsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUV0RCxJQUFJUixZQUFZQyxZQUFZLENBQUNVLFFBQVE7WUFDakNFLFdBQVc7UUFDZjtRQUVBLE1BQU1DLGlCQUFpQlQsd0JBQXdCSixTQUFTSztRQUV4RCxPQUFPO1lBQ0hTLE1BQU1kO1lBQ05ZO1lBQ0FGO1lBQ0FLLFdBQVcsQ0FBQ0Y7UUFDaEI7SUFDSjtJQUVBLHFCQUNJLDhEQUFDaEMsbUdBQVdBO1FBQUNtQyxjQUFXO1FBQWFDLHlCQUFXLDhEQUFDbEMseUVBQWdCQTtZQUFDbUMsVUFBUzs7Ozs7O1FBQVlDLElBQUk7WUFBRUMsSUFBSTtRQUFFOzswQkFDL0YsOERBQUNwQyxrREFBSUE7Z0JBQUNxQyxNQUFLO2dCQUFJQyxRQUFROzBCQUNsQjs7Ozs7O1lBRUpkLFlBQVlDLEdBQUcsQ0FBQyxDQUFDLEVBQUVLLElBQUksRUFBRUYsT0FBTyxFQUFFRixNQUFNLEVBQUVLLFNBQVMsRUFBRSxFQUFFVjtnQkFDcEQsTUFBTWtCLGNBQWM3QixzQkFBc0JvQjtnQkFDMUMsSUFBSSxDQUFDSixVQUFVSyxXQUFXO29CQUN0QixxQkFDSSw4REFBQy9CLGtEQUFJQTt3QkFBYXFDLE1BQU1UO3dCQUFTVSxRQUFRO2tDQUNwQ0M7dUJBRE1sQjs7Ozs7Z0JBSW5CO2dCQUVBLHFCQUNJLDhEQUFDdkIsa0dBQVVBO29CQUFhMEMsT0FBTTs4QkFDekJEO21CQURZbEI7Ozs7O1lBSXpCOzs7Ozs7O0FBR1o7QUFFQSxpRUFBZW5CLGNBQWNBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vY29tcG9uZW50cy9icmVhZENydW1icy5qc3g/ODMwNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEJyZWFkY3J1bWJzLCBUeXBvZ3JhcGh5IH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWxcIjtcclxuaW1wb3J0IE5hdmlnYXRlTmV4dEljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvTmF2aWdhdGVOZXh0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJztcclxuXHJcbmZ1bmN0aW9uIEdldEJyZWFkY3J1bWJzKCkge1xyXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgICBjb25zdCBwYXRoID0gcm91dGVyLmFzUGF0aC5zcGxpdChcIi9cIikuZmlsdGVyKHggPT4geCAmJiB4ICE9PSBcInBhZ2VcIiAmJiAheC5zdGFydHNXaXRoKFwiMFwiKSk7XHJcblxyXG4gICAgZnVuY3Rpb24gY2FwaXRhbGl6ZUZpcnN0TGV0dGVyKHN0cmluZykge1xyXG4gICAgICAgIHJldHVybiBzdHJpbmcuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyBzdHJpbmcuc2xpY2UoMSk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gaXNMaXN0Um91dGUoc2VnbWVudCkge1xyXG4gICAgICAgIGNvbnN0IGxpc3RSb3V0ZXMgPSBbJ2xhdW5jaGVzJywgJ3BheWxvYWRzJywgJ2NvcmVzJywgJ3JvY2tldHMnLCAnc2hpcHMnLCAnbGF1bmNocGFkcyddO1xyXG4gICAgICAgIHJldHVybiBsaXN0Um91dGVzLmluY2x1ZGVzKHNlZ21lbnQudG9Mb3dlckNhc2UoKSk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gaXNOb25DbGlja2FibGVMaXN0Um91dGUoc2VnbWVudCwgaW5kZXgpIHtcclxuICAgICAgICBpZiAoIWlzTGlzdFJvdXRlKHNlZ21lbnQpKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgbGV0IGNoZWNrUm91dGUgPSBgLyR7cGF0aC5zbGljZSgwLCBpbmRleCArIDEpLmpvaW4oJy8nKX0vcGFnZS8wYDtcclxuICAgICAgICByZXR1cm4gcm91dGVyLmFzUGF0aC50b0xvd2VyQ2FzZSgpLnN0YXJ0c1dpdGgoY2hlY2tSb3V0ZS50b0xvd2VyQ2FzZSgpKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBicmVhZGNydW1icyA9IHBhdGgubWFwKChzZWdtZW50LCBpbmRleCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGlzTGFzdCA9IGluZGV4ID09PSBwYXRoLmxlbmd0aCAtIDE7XHJcbiAgICAgICAgbGV0IHJvdXRlVG8gPSBgLyR7cGF0aC5zbGljZSgwLCBpbmRleCArIDEpLmpvaW4oJy8nKX1gO1xyXG5cclxuICAgICAgICBpZiAoaXNMaXN0Um91dGUoc2VnbWVudCkgJiYgIWlzTGFzdCkge1xyXG4gICAgICAgICAgICByb3V0ZVRvICs9IFwiL3BhZ2UvMFwiO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgaXNOb25DbGlja2FibGUgPSBpc05vbkNsaWNrYWJsZUxpc3RSb3V0ZShzZWdtZW50LCBpbmRleCk7XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIG5hbWU6IHNlZ21lbnQsXHJcbiAgICAgICAgICAgIHJvdXRlVG8sXHJcbiAgICAgICAgICAgIGlzTGFzdCxcclxuICAgICAgICAgICAgY2xpY2thYmxlOiAhaXNOb25DbGlja2FibGUsXHJcbiAgICAgICAgfTtcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEJyZWFkY3J1bWJzIGFyaWEtbGFiZWw9XCJicmVhZGNydW1iXCIgc2VwYXJhdG9yPXs8TmF2aWdhdGVOZXh0SWNvbiBmb250U2l6ZT1cInNtYWxsXCIgLz59IHN4PXt7IG1iOiAyIH19PlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL1wiIHBhc3NIcmVmPlxyXG4gICAgICAgICAgICAgICAge1wiSG9tZVwifVxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIHticmVhZGNydW1icy5tYXAoKHsgbmFtZSwgcm91dGVUbywgaXNMYXN0LCBjbGlja2FibGUgfSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGRpc3BsYXlUZXh0ID0gY2FwaXRhbGl6ZUZpcnN0TGV0dGVyKG5hbWUpO1xyXG4gICAgICAgICAgICAgICAgaWYgKCFpc0xhc3QgJiYgY2xpY2thYmxlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsga2V5PXtpbmRleH0gaHJlZj17cm91dGVUb30gcGFzc0hyZWY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGlzcGxheVRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkga2V5PXtpbmRleH0gY29sb3I9XCJ0ZXh0LnByaW1hcnlcIiA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtkaXNwbGF5VGV4dH1cclxuICAgICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICA8L0JyZWFkY3J1bWJzPlxyXG4gICAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgR2V0QnJlYWRjcnVtYnM7XHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIkJyZWFkY3J1bWJzIiwiVHlwb2dyYXBoeSIsIk5hdmlnYXRlTmV4dEljb24iLCJMaW5rIiwidXNlUm91dGVyIiwiR2V0QnJlYWRjcnVtYnMiLCJyb3V0ZXIiLCJwYXRoIiwiYXNQYXRoIiwic3BsaXQiLCJmaWx0ZXIiLCJ4Iiwic3RhcnRzV2l0aCIsImNhcGl0YWxpemVGaXJzdExldHRlciIsInN0cmluZyIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJpc0xpc3RSb3V0ZSIsInNlZ21lbnQiLCJsaXN0Um91dGVzIiwiaW5jbHVkZXMiLCJ0b0xvd2VyQ2FzZSIsImlzTm9uQ2xpY2thYmxlTGlzdFJvdXRlIiwiaW5kZXgiLCJjaGVja1JvdXRlIiwiam9pbiIsImJyZWFkY3J1bWJzIiwibWFwIiwiaXNMYXN0IiwibGVuZ3RoIiwicm91dGVUbyIsImlzTm9uQ2xpY2thYmxlIiwibmFtZSIsImNsaWNrYWJsZSIsImFyaWEtbGFiZWwiLCJzZXBhcmF0b3IiLCJmb250U2l6ZSIsInN4IiwibWIiLCJocmVmIiwicGFzc0hyZWYiLCJkaXNwbGF5VGV4dCIsImNvbG9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/breadCrumbs.jsx\n");

/***/ }),

/***/ "./components/logo.jsx":
/*!*****************************!*\
  !*** ./components/logo.jsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ \"./node_modules/next/image.js\");\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _public_img_logo_jpg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../public/img/logo.jpg */ \"./public/img/logo.jpg\");\n\n\n\n\nconst Logo = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"w-full flex justify-center\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n            href: \"/\",\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {\n                src: _public_img_logo_jpg__WEBPACK_IMPORTED_MODULE_3__[\"default\"],\n                alt: \"Logo\",\n                width: 300,\n                height: 50\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\logo.jsx\",\n                lineNumber: 9,\n                columnNumber: 17\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\logo.jsx\",\n            lineNumber: 8,\n            columnNumber: 13\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\logo.jsx\",\n        lineNumber: 7,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Logo);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL2xvZ28uanN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUErQjtBQUNGO0FBQ2U7QUFFNUMsTUFBTUcsT0FBTztJQUNULHFCQUNJLDhEQUFDQztRQUFJQyxXQUFVO2tCQUNYLDRFQUFDSixrREFBSUE7WUFBQ0ssTUFBSztzQkFDUCw0RUFBQ04sbURBQUtBO2dCQUFDTyxLQUFLTCw0REFBT0E7Z0JBQUVNLEtBQUk7Z0JBQU9DLE9BQU87Z0JBQUtDLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJcEU7QUFFQSxpRUFBZVAsSUFBSUEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2xhYjcvLi9jb21wb25lbnRzL2xvZ28uanN4PzM2MWMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnO1xyXG5pbXBvcnQgbG9nb0ltZyBmcm9tICcuLi9wdWJsaWMvaW1nL2xvZ28uanBnJ1xyXG5cclxuY29uc3QgTG9nbyA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlclwiID5cclxuICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9cIj5cclxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e2xvZ29JbWd9IGFsdD1cIkxvZ29cIiB3aWR0aD17MzAwfSBoZWlnaHQ9ezUwfSAvPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMb2dvO1xyXG4iXSwibmFtZXMiOlsiSW1hZ2UiLCJMaW5rIiwibG9nb0ltZyIsIkxvZ28iLCJkaXYiLCJjbGFzc05hbWUiLCJocmVmIiwic3JjIiwiYWx0Iiwid2lkdGgiLCJoZWlnaHQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/logo.jsx\n");

/***/ }),

/***/ "./components/menu.jsx":
/*!*****************************!*\
  !*** ./components/menu.jsx ***!
  \*****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_HiMenu_react_icons_hi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=HiMenu!=!react-icons/hi */ \"__barrel_optimize__?names=HiMenu!=!./node_modules/react-icons/hi/index.mjs\");\n/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! framer-motion */ \"framer-motion\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);\nframer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\nconst routes = [\n    {\n        path: \"/launches/page/0\",\n        label: \"Launches\"\n    },\n    {\n        path: \"/payloads/page/0\",\n        label: \"Payloads\"\n    },\n    {\n        path: \"/cores/page/0\",\n        label: \"Cores\"\n    },\n    {\n        path: \"/rockets/page/0\",\n        label: \"Rockets\"\n    },\n    {\n        path: \"/ships/page/0\",\n        label: \"Ships\"\n    },\n    {\n        path: \"/launchpads/page/0\",\n        label: \"Launchpads\"\n    }\n];\nconst Menu = ()=>{\n    const [isExpanded, setIsExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const buttonRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);\n    const [buttonPosition, setButtonPosition] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});\n    const handleLinkClick = ()=>setIsExpanded(false);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        if (buttonRef.current) {\n            const rect = buttonRef.current.getBoundingClientRect();\n            setButtonPosition({\n                top: rect.bottom + window.scrollY,\n                left: rect.left + window.scrollX\n            });\n        }\n    }, [\n        isExpanded\n    ]);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        const handleClickOutside = (event)=>{\n            if (buttonRef.current && !buttonRef.current.contains(event.target)) {\n                setIsExpanded(false);\n            }\n        };\n        document.addEventListener(\"mousedown\", handleClickOutside);\n        return ()=>{\n            document.removeEventListener(\"mousedown\", handleClickOutside);\n        };\n    }, []);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"relative\",\n        ref: buttonRef,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                className: \"text-gray-600 hover:text-gray-800 focus:outline-none\",\n                onClick: ()=>setIsExpanded(!isExpanded),\n                \"aria-label\": \"Menu\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_HiMenu_react_icons_hi__WEBPACK_IMPORTED_MODULE_4__.HiMenu, {\n                    className: \"w-6 h-6\"\n                }, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                    lineNumber: 52,\n                    columnNumber: 17\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                lineNumber: 47,\n                columnNumber: 13\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.AnimatePresence, {\n                children: isExpanded && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {\n                    initial: {\n                        opacity: 0,\n                        y: -10\n                    },\n                    animate: {\n                        opacity: 1,\n                        y: 0\n                    },\n                    exit: {\n                        opacity: 0,\n                        y: -10\n                    },\n                    transition: {\n                        duration: 0.2\n                    },\n                    style: {\n                        position: \"absolute\",\n                        top: `${buttonPosition.top}px`,\n                        left: `${buttonPosition.left}px`,\n                        zIndex: 50\n                    },\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"w-48 bg-white rounded-md shadow-md overflow-hidden\",\n                        children: routes.map((route, index)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                                href: route.path,\n                                passHref: true,\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                    className: \"block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer\",\n                                    onClick: handleLinkClick,\n                                    children: route.label\n                                }, void 0, false, {\n                                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                                    lineNumber: 71,\n                                    columnNumber: 37\n                                }, undefined)\n                            }, index, false, {\n                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                                lineNumber: 70,\n                                columnNumber: 33\n                            }, undefined))\n                    }, void 0, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                        lineNumber: 68,\n                        columnNumber: 25\n                    }, undefined)\n                }, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                    lineNumber: 56,\n                    columnNumber: 21\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n                lineNumber: 54,\n                columnNumber: 13\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\menu.jsx\",\n        lineNumber: 46,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menu);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL21lbnUuanN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBMkQ7QUFDOUI7QUFDVztBQUNnQjtBQUV4RCxNQUFNUSxTQUFTO0lBQ1g7UUFBRUMsTUFBTTtRQUFvQkMsT0FBTztJQUFXO0lBQzlDO1FBQUVELE1BQU07UUFBb0JDLE9BQU87SUFBVztJQUM5QztRQUFFRCxNQUFNO1FBQWlCQyxPQUFPO0lBQVE7SUFDeEM7UUFBRUQsTUFBTTtRQUFtQkMsT0FBTztJQUFVO0lBQzVDO1FBQUVELE1BQU07UUFBaUJDLE9BQU87SUFBUTtJQUN4QztRQUFFRCxNQUFNO1FBQXNCQyxPQUFPO0lBQWE7Q0FDckQ7QUFFRCxNQUFNQyxPQUFPO0lBQ1QsTUFBTSxDQUFDQyxZQUFZQyxjQUFjLEdBQUdaLCtDQUFRQSxDQUFDO0lBQzdDLE1BQU1hLFlBQVlaLDZDQUFNQSxDQUFDO0lBQ3pCLE1BQU0sQ0FBQ2EsZ0JBQWdCQyxrQkFBa0IsR0FBR2YsK0NBQVFBLENBQUMsQ0FBQztJQUV0RCxNQUFNZ0Isa0JBQWtCLElBQU1KLGNBQWM7SUFFNUNWLGdEQUFTQSxDQUFDO1FBQ04sSUFBSVcsVUFBVUksT0FBTyxFQUFFO1lBQ25CLE1BQU1DLE9BQU9MLFVBQVVJLE9BQU8sQ0FBQ0UscUJBQXFCO1lBQ3BESixrQkFBa0I7Z0JBQ2RLLEtBQUtGLEtBQUtHLE1BQU0sR0FBR0MsT0FBT0MsT0FBTztnQkFDakNDLE1BQU1OLEtBQUtNLElBQUksR0FBR0YsT0FBT0csT0FBTztZQUNwQztRQUNKO0lBQ0osR0FBRztRQUFDZDtLQUFXO0lBRWZULGdEQUFTQSxDQUFDO1FBQ04sTUFBTXdCLHFCQUFxQixDQUFDQztZQUN4QixJQUFJZCxVQUFVSSxPQUFPLElBQUksQ0FBQ0osVUFBVUksT0FBTyxDQUFDVyxRQUFRLENBQUNELE1BQU1FLE1BQU0sR0FBRztnQkFDaEVqQixjQUFjO1lBQ2xCO1FBQ0o7UUFFQWtCLFNBQVNDLGdCQUFnQixDQUFDLGFBQWFMO1FBQ3ZDLE9BQU87WUFDSEksU0FBU0UsbUJBQW1CLENBQUMsYUFBYU47UUFDOUM7SUFDSixHQUFHLEVBQUU7SUFFTCxxQkFDSSw4REFBQ087UUFBSUMsV0FBVTtRQUFXQyxLQUFLdEI7OzBCQUMzQiw4REFBQ3VCO2dCQUNHRixXQUFVO2dCQUNWRyxTQUFTLElBQU16QixjQUFjLENBQUNEO2dCQUM5QjJCLGNBQVc7MEJBRVgsNEVBQUNsQyxnRkFBTUE7b0JBQUM4QixXQUFVOzs7Ozs7Ozs7OzswQkFFdEIsOERBQUM1QiwwREFBZUE7MEJBQ1hLLDRCQUNHLDhEQUFDTixpREFBTUEsQ0FBQzRCLEdBQUc7b0JBQ1BNLFNBQVM7d0JBQUVDLFNBQVM7d0JBQUdDLEdBQUcsQ0FBQztvQkFBRztvQkFDOUJDLFNBQVM7d0JBQUVGLFNBQVM7d0JBQUdDLEdBQUc7b0JBQUU7b0JBQzVCRSxNQUFNO3dCQUFFSCxTQUFTO3dCQUFHQyxHQUFHLENBQUM7b0JBQUc7b0JBQzNCRyxZQUFZO3dCQUFFQyxVQUFVO29CQUFJO29CQUM1QkMsT0FBTzt3QkFDSEMsVUFBVTt3QkFDVjNCLEtBQUssQ0FBQyxFQUFFTixlQUFlTSxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUM5QkksTUFBTSxDQUFDLEVBQUVWLGVBQWVVLElBQUksQ0FBQyxFQUFFLENBQUM7d0JBQ2hDd0IsUUFBUTtvQkFDWjs4QkFFQSw0RUFBQ2Y7d0JBQUlDLFdBQVU7a0NBQ1YzQixPQUFPMEMsR0FBRyxDQUFDLENBQUNDLE9BQU9DLHNCQUNoQiw4REFBQ2hELGtEQUFJQTtnQ0FBYWlELE1BQU1GLE1BQU0xQyxJQUFJO2dDQUFFNkMsUUFBUTswQ0FDeEMsNEVBQUNDO29DQUNHcEIsV0FBVTtvQ0FDVkcsU0FBU3JCOzhDQUVSa0MsTUFBTXpDLEtBQUs7Ozs7OzsrQkFMVDBDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWUzQztBQUVBLGlFQUFlekMsSUFBSUEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2xhYjcvLi9jb21wb25lbnRzL21lbnUuanN4PzhiNTgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuaW1wb3J0IHsgSGlNZW51IH0gZnJvbSAncmVhY3QtaWNvbnMvaGknO1xyXG5pbXBvcnQgeyBtb3Rpb24sIEFuaW1hdGVQcmVzZW5jZSB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xyXG5cclxuY29uc3Qgcm91dGVzID0gW1xyXG4gICAgeyBwYXRoOiBcIi9sYXVuY2hlcy9wYWdlLzBcIiwgbGFiZWw6IFwiTGF1bmNoZXNcIiB9LFxyXG4gICAgeyBwYXRoOiBcIi9wYXlsb2Fkcy9wYWdlLzBcIiwgbGFiZWw6IFwiUGF5bG9hZHNcIiB9LFxyXG4gICAgeyBwYXRoOiBcIi9jb3Jlcy9wYWdlLzBcIiwgbGFiZWw6IFwiQ29yZXNcIiB9LFxyXG4gICAgeyBwYXRoOiBcIi9yb2NrZXRzL3BhZ2UvMFwiLCBsYWJlbDogXCJSb2NrZXRzXCIgfSxcclxuICAgIHsgcGF0aDogXCIvc2hpcHMvcGFnZS8wXCIsIGxhYmVsOiBcIlNoaXBzXCIgfSxcclxuICAgIHsgcGF0aDogXCIvbGF1bmNocGFkcy9wYWdlLzBcIiwgbGFiZWw6IFwiTGF1bmNocGFkc1wiIH0sXHJcbl07XHJcblxyXG5jb25zdCBNZW51ID0gKCkgPT4ge1xyXG4gICAgY29uc3QgW2lzRXhwYW5kZWQsIHNldElzRXhwYW5kZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgYnV0dG9uUmVmID0gdXNlUmVmKG51bGwpO1xyXG4gICAgY29uc3QgW2J1dHRvblBvc2l0aW9uLCBzZXRCdXR0b25Qb3NpdGlvbl0gPSB1c2VTdGF0ZSh7fSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlTGlua0NsaWNrID0gKCkgPT4gc2V0SXNFeHBhbmRlZChmYWxzZSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoYnV0dG9uUmVmLmN1cnJlbnQpIHtcclxuICAgICAgICAgICAgY29uc3QgcmVjdCA9IGJ1dHRvblJlZi5jdXJyZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgICAgICBzZXRCdXR0b25Qb3NpdGlvbih7XHJcbiAgICAgICAgICAgICAgICB0b3A6IHJlY3QuYm90dG9tICsgd2luZG93LnNjcm9sbFksXHJcbiAgICAgICAgICAgICAgICBsZWZ0OiByZWN0LmxlZnQgKyB3aW5kb3cuc2Nyb2xsWCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW2lzRXhwYW5kZWRdKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGhhbmRsZUNsaWNrT3V0c2lkZSA9IChldmVudCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoYnV0dG9uUmVmLmN1cnJlbnQgJiYgIWJ1dHRvblJlZi5jdXJyZW50LmNvbnRhaW5zKGV2ZW50LnRhcmdldCkpIHtcclxuICAgICAgICAgICAgICAgIHNldElzRXhwYW5kZWQoZmFsc2UpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgaGFuZGxlQ2xpY2tPdXRzaWRlKTtcclxuICAgICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVDbGlja091dHNpZGUpO1xyXG4gICAgICAgIH07XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ncmVsYXRpdmUnIHJlZj17YnV0dG9uUmVmfT5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBob3Zlcjp0ZXh0LWdyYXktODAwIGZvY3VzOm91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0V4cGFuZGVkKCFpc0V4cGFuZGVkKX1cclxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJNZW51XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEhpTWVudSBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxBbmltYXRlUHJlc2VuY2U+XHJcbiAgICAgICAgICAgICAgICB7aXNFeHBhbmRlZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAtMTAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCwgeTogLTEwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A6IGAke2J1dHRvblBvc2l0aW9uLnRvcH1weGAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiBgJHtidXR0b25Qb3NpdGlvbi5sZWZ0fXB4YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHpJbmRleDogNTAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNDggYmctd2hpdGUgcm91bmRlZC1tZCBzaGFkb3ctbWQgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cm91dGVzLm1hcCgocm91dGUsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsga2V5PXtpbmRleH0gaHJlZj17cm91dGUucGF0aH0gcGFzc0hyZWY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktMTAwIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxpbmtDbGlja31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JvdXRlLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvQW5pbWF0ZVByZXNlbmNlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1lbnU7Il0sIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VSZWYiLCJ1c2VFZmZlY3QiLCJMaW5rIiwiSGlNZW51IiwibW90aW9uIiwiQW5pbWF0ZVByZXNlbmNlIiwicm91dGVzIiwicGF0aCIsImxhYmVsIiwiTWVudSIsImlzRXhwYW5kZWQiLCJzZXRJc0V4cGFuZGVkIiwiYnV0dG9uUmVmIiwiYnV0dG9uUG9zaXRpb24iLCJzZXRCdXR0b25Qb3NpdGlvbiIsImhhbmRsZUxpbmtDbGljayIsImN1cnJlbnQiLCJyZWN0IiwiZ2V0Qm91bmRpbmdDbGllbnRSZWN0IiwidG9wIiwiYm90dG9tIiwid2luZG93Iiwic2Nyb2xsWSIsImxlZnQiLCJzY3JvbGxYIiwiaGFuZGxlQ2xpY2tPdXRzaWRlIiwiZXZlbnQiLCJjb250YWlucyIsInRhcmdldCIsImRvY3VtZW50IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJkaXYiLCJjbGFzc05hbWUiLCJyZWYiLCJidXR0b24iLCJvbkNsaWNrIiwiYXJpYS1sYWJlbCIsImluaXRpYWwiLCJvcGFjaXR5IiwieSIsImFuaW1hdGUiLCJleGl0IiwidHJhbnNpdGlvbiIsImR1cmF0aW9uIiwic3R5bGUiLCJwb3NpdGlvbiIsInpJbmRleCIsIm1hcCIsInJvdXRlIiwiaW5kZXgiLCJocmVmIiwicGFzc0hyZWYiLCJzcGFuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/menu.jsx\n");

/***/ }),

/***/ "./components/renderObject.jsx":
/*!*************************************!*\
  !*** ./components/renderObject.jsx ***!
  \*************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! framer-motion */ \"framer-motion\");\n/* harmony import */ var _barrel_optimize_names_Collapse_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Collapse,IconButton,Typography!=!@mui/material */ \"__barrel_optimize__?names=Collapse,IconButton,Typography!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var _barrel_optimize_names_ExpandLess_ExpandMore_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=ExpandLess,ExpandMore!=!@mui/icons-material */ \"__barrel_optimize__?names=ExpandLess,ExpandMore!=!./node_modules/@mui/icons-material/esm/index.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);\nframer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\nfunction RenderObject({ obj, toggleExpandKey, expandedKeys }) {\n    const singularList = {\n        \"launch\": \"launches\",\n        \"launchpad\": \"launchpads\",\n        \"core\": \"cores\",\n        \"payload\": \"payloads\",\n        \"rocket\": \"rockets\",\n        \"ship\": \"ships\"\n    };\n    const pluralList = [\n        \"launches\",\n        \"launchpads\",\n        \"cores\",\n        \"payloads\",\n        \"rockets\",\n        \"ships\"\n    ];\n    const renderValue = (value, key)=>{\n        if (value === null) {\n            return \"null\";\n        }\n        const isExpandable = typeof value === \"object\" && value !== null && Object.keys(value).length > 0;\n        const isEmptyObject = typeof value === \"object\" && value !== null && Object.keys(value).length === 0;\n        if (isEmptyObject) {\n            return \"[]\";\n        } else if (isExpandable) {\n            if (pluralList.includes(key)) {\n                return value.map((item, index)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"ol\", {\n                        children: key === \"cores\" ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"li\", {\n                            children: Object.entries(item).map(([propKey, propValue])=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"li\", {\n                                    children: propKey === \"core\" ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                                        href: `/${key}/${propValue}`,\n                                        style: {\n                                            color: \"blue\"\n                                        },\n                                        onClick: ()=>console.log(\"Link clicked:\", propValue),\n                                        children: [\n                                            propKey,\n                                            \": \",\n                                            propValue\n                                        ]\n                                    }, void 0, true, {\n                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                                        lineNumber: 36,\n                                        columnNumber: 45\n                                    }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                        children: [\n                                            propKey,\n                                            \": \",\n                                            propValue\n                                        ]\n                                    }, void 0, true, {\n                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                                        lineNumber: 41,\n                                        columnNumber: 45\n                                    }, this)\n                                }, propKey, false, {\n                                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                                    lineNumber: 34,\n                                    columnNumber: 37\n                                }, this))\n                        }, void 0, false, {\n                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                            lineNumber: 32,\n                            columnNumber: 29\n                        }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"li\", {\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                                href: `/${key}/${item}`,\n                                style: {\n                                    color: \"blue\"\n                                },\n                                onClick: ()=>console.log(\"Link clicked:\", item),\n                                children: item\n                            }, void 0, false, {\n                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                                lineNumber: 48,\n                                columnNumber: 33\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                            lineNumber: 47,\n                            columnNumber: 29\n                        }, this)\n                    }, index, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                        lineNumber: 30,\n                        columnNumber: 21\n                    }, this));\n            } else {\n                return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"ul\", {\n                    style: {\n                        listStyleType: \"none\",\n                        padding: 0\n                    },\n                    children: Object.entries(value).map(([nestedKey, nestedValue])=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"li\", {\n                            children: renderNestedValue(nestedValue, nestedKey, toggleExpandKey, expandedKeys)\n                        }, nestedKey, false, {\n                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                            lineNumber: 60,\n                            columnNumber: 29\n                        }, this))\n                }, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                    lineNumber: 58,\n                    columnNumber: 21\n                }, this);\n            }\n        } else {\n            if (Object.keys(singularList).includes(key)) {\n                return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                    href: `/${singularList[key]}/${value}`,\n                    style: {\n                        color: \"blue\"\n                    },\n                    onClick: ()=>console.log(\"Link clicked:\", value),\n                    children: value\n                }, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                    lineNumber: 70,\n                    columnNumber: 21\n                }, this);\n            } else {\n                return value.toString();\n            }\n        }\n    };\n    const renderNestedValue = (value, key, toggleExpandKey, expandedKeys)=>{\n        const isExpandable = typeof value === \"object\" && value !== null && Object.keys(value).length > 0;\n        const newPath = key;\n        if (isExpandable) {\n            return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Collapse_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {\n                        variant: \"body2\",\n                        component: \"div\",\n                        sx: {\n                            display: \"flex\",\n                            alignItems: \"center\"\n                        },\n                        children: [\n                            key,\n                            \":\",\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Collapse_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                size: \"small\",\n                                onClick: ()=>toggleExpandKey(newPath),\n                                children: expandedKeys[newPath] ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_ExpandLess_ExpandMore_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.ExpandLess, {}, void 0, false, {\n                                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                                    lineNumber: 91,\n                                    columnNumber: 54\n                                }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_ExpandLess_ExpandMore_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.ExpandMore, {}, void 0, false, {\n                                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                                    lineNumber: 91,\n                                    columnNumber: 75\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                                lineNumber: 90,\n                                columnNumber: 25\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                        lineNumber: 88,\n                        columnNumber: 21\n                    }, this),\n                    expandedKeys[newPath] && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Collapse_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Collapse, {\n                        in: expandedKeys[newPath],\n                        timeout: \"auto\",\n                        unmountOnExit: true,\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"ul\", {\n                            children: renderValue(value, key)\n                        }, void 0, false, {\n                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                            lineNumber: 96,\n                            columnNumber: 29\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                        lineNumber: 95,\n                        columnNumber: 25\n                    }, this)\n                ]\n            }, void 0, true);\n        } else {\n            return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Collapse_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {\n                variant: \"body2\",\n                component: \"div\",\n                sx: {\n                    display: \"flex\",\n                    alignItems: \"center\"\n                },\n                children: [\n                    key,\n                    \": \",\n                    renderValue(value, key)\n                ]\n            }, void 0, true, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                lineNumber: 103,\n                columnNumber: 17\n            }, this);\n        }\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"ul\", {\n        className: \"list-none p-0\",\n        children: Object.entries(obj).map(([key, value])=>{\n            const newPath = key;\n            const isExpandable = typeof value === \"object\" && value !== null && Object.keys(value).length > 0;\n            let displayValue = renderValue(value, key);\n            return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"li\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Collapse_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {\n                        variant: \"body2\",\n                        component: \"div\",\n                        className: \"flex items-center\",\n                        children: [\n                            key,\n                            \":\",\n                            isExpandable ? null : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"ul\", {\n                                children: displayValue\n                            }, void 0, false, {\n                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                                lineNumber: 122,\n                                columnNumber: 52\n                            }, this),\n                            isExpandable && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Collapse_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                size: \"small\",\n                                onClick: ()=>toggleExpandKey(newPath),\n                                children: expandedKeys[newPath] ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_ExpandLess_ExpandMore_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.ExpandLess, {}, void 0, false, {\n                                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                                    lineNumber: 125,\n                                    columnNumber: 62\n                                }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_ExpandLess_ExpandMore_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.ExpandMore, {}, void 0, false, {\n                                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                                    lineNumber: 125,\n                                    columnNumber: 83\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                                lineNumber: 124,\n                                columnNumber: 33\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                        lineNumber: 120,\n                        columnNumber: 25\n                    }, this),\n                    isExpandable && expandedKeys[newPath] && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {\n                        initial: {\n                            opacity: 0,\n                            y: 20\n                        },\n                        animate: {\n                            opacity: 1,\n                            y: 0\n                        },\n                        transition: {\n                            duration: 0.3\n                        },\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"ul\", {\n                            children: displayValue\n                        }, void 0, false, {\n                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                            lineNumber: 135,\n                            columnNumber: 33\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                        lineNumber: 130,\n                        columnNumber: 29\n                    }, this)\n                ]\n            }, newPath, true, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n                lineNumber: 119,\n                columnNumber: 21\n            }, this);\n        })\n    }, void 0, false, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\components\\\\renderObject.jsx\",\n        lineNumber: 111,\n        columnNumber: 9\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RenderObject);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL3JlbmRlck9iamVjdC5qc3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQ3VDO0FBQ3dCO0FBQ2tDO0FBQ3BFO0FBQzdCLFNBQVNTLGFBQWEsRUFBRUMsR0FBRyxFQUFFQyxlQUFlLEVBQUVDLFlBQVksRUFBRTtJQUN4RCxNQUFNQyxlQUFlO1FBQ2pCLFVBQVU7UUFDVixhQUFhO1FBQ2IsUUFBUTtRQUNSLFdBQVc7UUFDWCxVQUFVO1FBQ1YsUUFBUTtJQUNaO0lBQ0EsTUFBTUMsYUFBYTtRQUFDO1FBQVk7UUFBYztRQUFTO1FBQVk7UUFBVztLQUFRO0lBRXRGLE1BQU1DLGNBQWMsQ0FBQ0MsT0FBT0M7UUFDeEIsSUFBSUQsVUFBVSxNQUFNO1lBQ2hCLE9BQU87UUFDWDtRQUVBLE1BQU1FLGVBQWUsT0FBT0YsVUFBVSxZQUFZQSxVQUFVLFFBQVFHLE9BQU9DLElBQUksQ0FBQ0osT0FBT0ssTUFBTSxHQUFHO1FBQ2hHLE1BQU1DLGdCQUFnQixPQUFPTixVQUFVLFlBQVlBLFVBQVUsUUFBUUcsT0FBT0MsSUFBSSxDQUFDSixPQUFPSyxNQUFNLEtBQUs7UUFFbkcsSUFBSUMsZUFBZTtZQUNmLE9BQU87UUFDWCxPQUFPLElBQUlKLGNBQWM7WUFDckIsSUFBSUosV0FBV1MsUUFBUSxDQUFDTixNQUFNO2dCQUMxQixPQUFPRCxNQUFNUSxHQUFHLENBQUMsQ0FBQ0MsTUFBTUMsc0JBQ3BCLDhEQUFDQztrQ0FDSVYsUUFBUSx3QkFDTCw4REFBQ1c7c0NBQ0lULE9BQU9VLE9BQU8sQ0FBQ0osTUFBTUQsR0FBRyxDQUFDLENBQUMsQ0FBQ00sU0FBU0MsVUFBVSxpQkFDM0MsOERBQUNIOzhDQUNJRSxZQUFZLHVCQUNULDhEQUFDdEIsa0RBQUlBO3dDQUFDd0IsTUFBTSxDQUFDLENBQUMsRUFBRWYsSUFBSSxDQUFDLEVBQUVjLFVBQVUsQ0FBQzt3Q0FBRUUsT0FBTzs0Q0FBQ0MsT0FBTzt3Q0FBTTt3Q0FDbkRDLFNBQVMsSUFBTUMsUUFBUUMsR0FBRyxDQUFDLGlCQUFpQk47OzRDQUM3Q0Q7NENBQVE7NENBQUdDOzs7Ozs7NkRBR2hCLDhEQUFDTzs7NENBQU1SOzRDQUFROzRDQUFHQzs7Ozs7OzttQ0FQakJEOzs7Ozs7Ozs7aURBYWpCLDhEQUFDRjtzQ0FDRyw0RUFBQ3BCLGtEQUFJQTtnQ0FBQ3dCLE1BQU0sQ0FBQyxDQUFDLEVBQUVmLElBQUksQ0FBQyxFQUFFUSxLQUFLLENBQUM7Z0NBQUVRLE9BQU87b0NBQUNDLE9BQU87Z0NBQU07Z0NBQzlDQyxTQUFTLElBQU1DLFFBQVFDLEdBQUcsQ0FBQyxpQkFBaUJaOzBDQUM3Q0E7Ozs7Ozs7Ozs7O3VCQXBCUkM7Ozs7O1lBMEJqQixPQUFPO2dCQUNILHFCQUNJLDhEQUFDYTtvQkFBR04sT0FBTzt3QkFBRU8sZUFBZTt3QkFBUUMsU0FBUztvQkFBRTs4QkFDMUN0QixPQUFPVSxPQUFPLENBQUNiLE9BQU9RLEdBQUcsQ0FBQyxDQUFDLENBQUNrQixXQUFXQyxZQUFZLGlCQUNoRCw4REFBQ2Y7c0NBQ0lnQixrQkFBa0JELGFBQWFELFdBQVcvQixpQkFBaUJDOzJCQUR2RDhCOzs7Ozs7Ozs7O1lBTXpCO1FBQ0osT0FBTztZQUNILElBQUl2QixPQUFPQyxJQUFJLENBQUNQLGNBQWNVLFFBQVEsQ0FBQ04sTUFBTTtnQkFDekMscUJBQ0ksOERBQUNULGtEQUFJQTtvQkFBQ3dCLE1BQU0sQ0FBQyxDQUFDLEVBQUVuQixZQUFZLENBQUNJLElBQUksQ0FBQyxDQUFDLEVBQUVELE1BQU0sQ0FBQztvQkFBRWlCLE9BQU87d0JBQUNDLE9BQU87b0JBQU07b0JBQzdEQyxTQUFTLElBQU1DLFFBQVFDLEdBQUcsQ0FBQyxpQkFBaUJyQjs4QkFDN0NBOzs7Ozs7WUFHYixPQUFPO2dCQUNILE9BQU9BLE1BQU02QixRQUFRO1lBQ3pCO1FBQ0o7SUFDSjtJQUVBLE1BQU1ELG9CQUFvQixDQUFDNUIsT0FBT0MsS0FBS04saUJBQWlCQztRQUNwRCxNQUFNTSxlQUFlLE9BQU9GLFVBQVUsWUFBWUEsVUFBVSxRQUFRRyxPQUFPQyxJQUFJLENBQUNKLE9BQU9LLE1BQU0sR0FBRztRQUNoRyxNQUFNeUIsVUFBVTdCO1FBRWhCLElBQUlDLGNBQWM7WUFDZCxxQkFDSTs7a0NBQ0ksOERBQUNmLDBHQUFVQTt3QkFBQzRDLFNBQVE7d0JBQVFDLFdBQVU7d0JBQU1DLElBQUk7NEJBQUVDLFNBQVM7NEJBQVFDLFlBQVk7d0JBQVM7OzRCQUNuRmxDOzRCQUFJOzBDQUNMLDhEQUFDZiwwR0FBVUE7Z0NBQUNrRCxNQUFLO2dDQUFRakIsU0FBUyxJQUFNeEIsZ0JBQWdCbUM7MENBQ25EbEMsWUFBWSxDQUFDa0MsUUFBUSxpQkFBRyw4REFBQ3pDLHVHQUFjQTs7Ozt5REFBTSw4REFBQ0UsdUdBQWNBOzs7Ozs7Ozs7Ozs7Ozs7O29CQUdwRUssWUFBWSxDQUFDa0MsUUFBUSxrQkFDbEIsOERBQUM3Qyx3R0FBUUE7d0JBQUNvRCxJQUFJekMsWUFBWSxDQUFDa0MsUUFBUTt3QkFBRVEsU0FBUTt3QkFBT0MsYUFBYTtrQ0FDN0QsNEVBQUNoQjtzQ0FBSXhCLFlBQVlDLE9BQU9DOzs7Ozs7Ozs7Ozs7O1FBSzVDLE9BQU87WUFDSCxxQkFDSSw4REFBQ2QsMEdBQVVBO2dCQUFDNEMsU0FBUTtnQkFBUUMsV0FBVTtnQkFBTUMsSUFBSTtvQkFBRUMsU0FBUztvQkFBUUMsWUFBWTtnQkFBUzs7b0JBQ25GbEM7b0JBQUk7b0JBQUdGLFlBQVlDLE9BQU9DOzs7Ozs7O1FBR3ZDO0lBQ0o7SUFFQSxxQkFDSSw4REFBQ3NCO1FBQUdpQixXQUFVO2tCQUNUckMsT0FBT1UsT0FBTyxDQUFDbkIsS0FBS2MsR0FBRyxDQUFDLENBQUMsQ0FBQ1AsS0FBS0QsTUFBTTtZQUNsQyxNQUFNOEIsVUFBVTdCO1lBQ2hCLE1BQU1DLGVBQWUsT0FBT0YsVUFBVSxZQUFZQSxVQUFVLFFBQVFHLE9BQU9DLElBQUksQ0FBQ0osT0FBT0ssTUFBTSxHQUFHO1lBRWhHLElBQUlvQyxlQUFlMUMsWUFBWUMsT0FBT0M7WUFFdEMscUJBQ0ksOERBQUNXOztrQ0FDRyw4REFBQ3pCLDBHQUFVQTt3QkFBQzRDLFNBQVE7d0JBQVFDLFdBQVU7d0JBQU1RLFdBQVU7OzRCQUNqRHZDOzRCQUFJOzRCQUNKQyxlQUFlLHFCQUFPLDhEQUFDcUI7MENBQUlrQjs7Ozs7OzRCQUMzQnZDLDhCQUNHLDhEQUFDaEIsMEdBQVVBO2dDQUFDa0QsTUFBSztnQ0FBUWpCLFNBQVMsSUFBTXhCLGdCQUFnQm1DOzBDQUNuRGxDLFlBQVksQ0FBQ2tDLFFBQVEsaUJBQUcsOERBQUN6Qyx1R0FBY0E7Ozs7eURBQU0sOERBQUNFLHVHQUFjQTs7Ozs7Ozs7Ozs7Ozs7OztvQkFJeEVXLGdCQUFnQk4sWUFBWSxDQUFDa0MsUUFBUSxrQkFDbEMsOERBQUM5QyxpREFBTUEsQ0FBQzBELEdBQUc7d0JBQ1BDLFNBQVM7NEJBQUVDLFNBQVM7NEJBQUdDLEdBQUc7d0JBQUc7d0JBQzdCQyxTQUFTOzRCQUFFRixTQUFTOzRCQUFHQyxHQUFHO3dCQUFFO3dCQUM1QkUsWUFBWTs0QkFBRUMsVUFBVTt3QkFBSTtrQ0FFNUIsNEVBQUN6QjtzQ0FBSWtCOzs7Ozs7Ozs7Ozs7ZUFoQlJYOzs7OztRQXFCakI7Ozs7OztBQUdaO0FBRUEsaUVBQWVyQyxZQUFZQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbGFiNy8uL2NvbXBvbmVudHMvcmVuZGVyT2JqZWN0LmpzeD85MDI5Il0sInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tIFwiZnJhbWVyLW1vdGlvblwiO1xyXG5pbXBvcnQge0NvbGxhcHNlLCBJY29uQnV0dG9uLCBUeXBvZ3JhcGh5fSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgeyBFeHBhbmRMZXNzIGFzIEV4cGFuZExlc3NJY29uLCBFeHBhbmRNb3JlIGFzIEV4cGFuZE1vcmVJY29uIH0gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWxcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5mdW5jdGlvbiBSZW5kZXJPYmplY3QoeyBvYmosIHRvZ2dsZUV4cGFuZEtleSwgZXhwYW5kZWRLZXlzIH0pIHtcclxuICAgIGNvbnN0IHNpbmd1bGFyTGlzdCA9IHtcclxuICAgICAgICAnbGF1bmNoJzogJ2xhdW5jaGVzJyxcclxuICAgICAgICAnbGF1bmNocGFkJzogJ2xhdW5jaHBhZHMnLFxyXG4gICAgICAgICdjb3JlJzogJ2NvcmVzJyxcclxuICAgICAgICAncGF5bG9hZCc6ICdwYXlsb2FkcycsXHJcbiAgICAgICAgJ3JvY2tldCc6ICdyb2NrZXRzJyxcclxuICAgICAgICAnc2hpcCc6ICdzaGlwcydcclxuICAgIH07XHJcbiAgICBjb25zdCBwbHVyYWxMaXN0ID0gWydsYXVuY2hlcycsICdsYXVuY2hwYWRzJywgJ2NvcmVzJywgJ3BheWxvYWRzJywgJ3JvY2tldHMnLCAnc2hpcHMnXTtcclxuXHJcbiAgICBjb25zdCByZW5kZXJWYWx1ZSA9ICh2YWx1ZSwga2V5KSA9PiB7XHJcbiAgICAgICAgaWYgKHZhbHVlID09PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHJldHVybiAnbnVsbCc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBpc0V4cGFuZGFibGUgPSB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICE9PSBudWxsICYmIE9iamVjdC5rZXlzKHZhbHVlKS5sZW5ndGggPiAwO1xyXG4gICAgICAgIGNvbnN0IGlzRW1wdHlPYmplY3QgPSB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICE9PSBudWxsICYmIE9iamVjdC5rZXlzKHZhbHVlKS5sZW5ndGggPT09IDA7XHJcblxyXG4gICAgICAgIGlmIChpc0VtcHR5T2JqZWN0KSB7XHJcbiAgICAgICAgICAgIHJldHVybiAnW10nO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoaXNFeHBhbmRhYmxlKSB7XHJcbiAgICAgICAgICAgIGlmIChwbHVyYWxMaXN0LmluY2x1ZGVzKGtleSkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPG9sIGtleT17aW5kZXh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7a2V5ID09PSAnY29yZXMnID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhpdGVtKS5tYXAoKFtwcm9wS2V5LCBwcm9wVmFsdWVdKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e3Byb3BLZXl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Byb3BLZXkgPT09ICdjb3JlJyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPXtgLyR7a2V5fS8ke3Byb3BWYWx1ZX1gfSBzdHlsZT17e2NvbG9yOiAnYmx1ZSd9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvbnNvbGUubG9nKCdMaW5rIGNsaWNrZWQ6JywgcHJvcFZhbHVlKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9wS2V5fToge3Byb3BWYWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntwcm9wS2V5fToge3Byb3BWYWx1ZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPXtgLyR7a2V5fS8ke2l0ZW19YH0gc3R5bGU9e3tjb2xvcjogJ2JsdWUnfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjb25zb2xlLmxvZygnTGluayBjbGlja2VkOicsIGl0ZW0pfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L29sPlxyXG4gICAgICAgICAgICAgICAgKSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDx1bCBzdHlsZT17eyBsaXN0U3R5bGVUeXBlOiBcIm5vbmVcIiwgcGFkZGluZzogMCB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKHZhbHVlKS5tYXAoKFtuZXN0ZWRLZXksIG5lc3RlZFZhbHVlXSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17bmVzdGVkS2V5fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVuZGVyTmVzdGVkVmFsdWUobmVzdGVkVmFsdWUsIG5lc3RlZEtleSwgdG9nZ2xlRXhwYW5kS2V5LCBleHBhbmRlZEtleXMpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAoT2JqZWN0LmtleXMoc2luZ3VsYXJMaXN0KS5pbmNsdWRlcyhrZXkpKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9e2AvJHtzaW5ndWxhckxpc3Rba2V5XX0vJHt2YWx1ZX1gfSBzdHlsZT17e2NvbG9yOiAnYmx1ZSd9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvbnNvbGUubG9nKCdMaW5rIGNsaWNrZWQ6JywgdmFsdWUpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3ZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWUudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcmVuZGVyTmVzdGVkVmFsdWUgPSAodmFsdWUsIGtleSwgdG9nZ2xlRXhwYW5kS2V5LCBleHBhbmRlZEtleXMpID0+IHtcclxuICAgICAgICBjb25zdCBpc0V4cGFuZGFibGUgPSB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICE9PSBudWxsICYmIE9iamVjdC5rZXlzKHZhbHVlKS5sZW5ndGggPiAwO1xyXG4gICAgICAgIGNvbnN0IG5ld1BhdGggPSBrZXk7XHJcblxyXG4gICAgICAgIGlmIChpc0V4cGFuZGFibGUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29tcG9uZW50PVwiZGl2XCIgc3g9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2tleX06XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIHNpemU9XCJzbWFsbFwiIG9uQ2xpY2s9eygpID0+IHRvZ2dsZUV4cGFuZEtleShuZXdQYXRoKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXhwYW5kZWRLZXlzW25ld1BhdGhdID8gPEV4cGFuZExlc3NJY29uIC8+IDogPEV4cGFuZE1vcmVJY29uIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgIHtleHBhbmRlZEtleXNbbmV3UGF0aF0gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q29sbGFwc2UgaW49e2V4cGFuZGVkS2V5c1tuZXdQYXRoXX0gdGltZW91dD1cImF1dG9cIiB1bm1vdW50T25FeGl0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsPntyZW5kZXJWYWx1ZSh2YWx1ZSwga2V5KX08L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NvbGxhcHNlPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29tcG9uZW50PVwiZGl2XCIgc3g9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICB7a2V5fToge3JlbmRlclZhbHVlKHZhbHVlLCBrZXkpfVxyXG4gICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8dWwgY2xhc3NOYW1lPVwibGlzdC1ub25lIHAtMFwiPlxyXG4gICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMob2JqKS5tYXAoKFtrZXksIHZhbHVlXSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgbmV3UGF0aCA9IGtleTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGlzRXhwYW5kYWJsZSA9IHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgIT09IG51bGwgJiYgT2JqZWN0LmtleXModmFsdWUpLmxlbmd0aCA+IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IGRpc3BsYXlWYWx1ZSA9IHJlbmRlclZhbHVlKHZhbHVlLCBrZXkpO1xyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17bmV3UGF0aH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MlwiIGNvbXBvbmVudD1cImRpdlwiIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7a2V5fTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0V4cGFuZGFibGUgPyBudWxsIDogPHVsPntkaXNwbGF5VmFsdWV9PC91bD59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNFeHBhbmRhYmxlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbiBzaXplPVwic21hbGxcIiBvbkNsaWNrPXsoKSA9PiB0b2dnbGVFeHBhbmRLZXkobmV3UGF0aCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXhwYW5kZWRLZXlzW25ld1BhdGhdID8gPEV4cGFuZExlc3NJY29uIC8+IDogPEV4cGFuZE1vcmVJY29uIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2lzRXhwYW5kYWJsZSAmJiBleHBhbmRlZEtleXNbbmV3UGF0aF0gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC4zIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsPntkaXNwbGF5VmFsdWV9PC91bD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgPC91bD5cclxuICAgICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlbmRlck9iamVjdDsiXSwibmFtZXMiOlsibW90aW9uIiwiQ29sbGFwc2UiLCJJY29uQnV0dG9uIiwiVHlwb2dyYXBoeSIsIkV4cGFuZExlc3MiLCJFeHBhbmRMZXNzSWNvbiIsIkV4cGFuZE1vcmUiLCJFeHBhbmRNb3JlSWNvbiIsIkxpbmsiLCJSZW5kZXJPYmplY3QiLCJvYmoiLCJ0b2dnbGVFeHBhbmRLZXkiLCJleHBhbmRlZEtleXMiLCJzaW5ndWxhckxpc3QiLCJwbHVyYWxMaXN0IiwicmVuZGVyVmFsdWUiLCJ2YWx1ZSIsImtleSIsImlzRXhwYW5kYWJsZSIsIk9iamVjdCIsImtleXMiLCJsZW5ndGgiLCJpc0VtcHR5T2JqZWN0IiwiaW5jbHVkZXMiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJvbCIsImxpIiwiZW50cmllcyIsInByb3BLZXkiLCJwcm9wVmFsdWUiLCJocmVmIiwic3R5bGUiLCJjb2xvciIsIm9uQ2xpY2siLCJjb25zb2xlIiwibG9nIiwic3BhbiIsInVsIiwibGlzdFN0eWxlVHlwZSIsInBhZGRpbmciLCJuZXN0ZWRLZXkiLCJuZXN0ZWRWYWx1ZSIsInJlbmRlck5lc3RlZFZhbHVlIiwidG9TdHJpbmciLCJuZXdQYXRoIiwidmFyaWFudCIsImNvbXBvbmVudCIsInN4IiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJzaXplIiwiaW4iLCJ0aW1lb3V0IiwidW5tb3VudE9uRXhpdCIsImNsYXNzTmFtZSIsImRpc3BsYXlWYWx1ZSIsImRpdiIsImluaXRpYWwiLCJvcGFjaXR5IiwieSIsImFuaW1hdGUiLCJ0cmFuc2l0aW9uIiwiZHVyYXRpb24iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/renderObject.jsx\n");

/***/ }),

/***/ "./pages/_app.jsx":
/*!************************!*\
  !*** ./pages/_app.jsx ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_menu_jsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/menu.jsx */ \"./components/menu.jsx\");\n/* harmony import */ var _components_logo_jsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/logo.jsx */ \"./components/logo.jsx\");\n/* harmony import */ var _components_backgroundOverlay_jsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/backgroundOverlay.jsx */ \"./components/backgroundOverlay.jsx\");\n/* harmony import */ var _components_breadCrumbs_jsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/breadCrumbs.jsx */ \"./components/breadCrumbs.jsx\");\n/* harmony import */ var _components_backTotop_jsx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/backTotop.jsx */ \"./components/backTotop.jsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_menu_jsx__WEBPACK_IMPORTED_MODULE_2__]);\n_components_menu_jsx__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"layoutStyle\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"header\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_backgroundOverlay_jsx__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {}, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                    lineNumber: 12,\n                    columnNumber: 15\n                }, this)\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 11,\n                columnNumber: 11\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_backTotop_jsx__WEBPACK_IMPORTED_MODULE_6__[\"default\"], {}, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                    lineNumber: 14,\n                    columnNumber: 17\n                }, this)\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 14,\n                columnNumber: 11\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_menu_jsx__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 15,\n                columnNumber: 11\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_logo_jsx__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 16,\n                columnNumber: 11\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_breadCrumbs_jsx__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {}, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 17,\n                columnNumber: 11\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n                lineNumber: 18,\n                columnNumber: 11\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_app.jsx\",\n        lineNumber: 10,\n        columnNumber: 7\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUE4QjtBQUNXO0FBQ0E7QUFDMEI7QUFDVDtBQUNEO0FBRTFDLFNBQVNLLElBQUksRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDbEQscUJBQ0ksOERBQUNDO1FBQUlDLFdBQVU7OzBCQUNYLDhEQUFDQzswQkFDRyw0RUFBQ1IseUVBQWlCQTs7Ozs7Ozs7OzswQkFFdEIsOERBQUNTOzBCQUFLLDRFQUFDUCxpRUFBZUE7Ozs7Ozs7Ozs7MEJBQ3RCLDhEQUFDSiw0REFBSUE7Ozs7OzBCQUNMLDhEQUFDQyw0REFBSUE7Ozs7OzBCQUNMLDhEQUFDRSxtRUFBY0E7Ozs7OzBCQUNmLDhEQUFDRztnQkFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7Ozs7QUFJbEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vcGFnZXMvX2FwcC5qc3g/NGNiMyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCJAL3N0eWxlcy9nbG9iYWxzLmNzc1wiO1xuaW1wb3J0IE1lbnUgZnJvbSBcIkAvY29tcG9uZW50cy9tZW51LmpzeFwiO1xuaW1wb3J0IExvZ28gZnJvbSBcIkAvY29tcG9uZW50cy9sb2dvLmpzeFwiO1xuaW1wb3J0IEJhY2tncm91bmRPdmVybGF5IGZyb20gXCJAL2NvbXBvbmVudHMvYmFja2dyb3VuZE92ZXJsYXkuanN4XCI7XG5pbXBvcnQgR2V0QnJlYWRjcnVtYnMgZnJvbSBcIkAvY29tcG9uZW50cy9icmVhZENydW1icy5qc3hcIjtcbmltcG9ydCBCYWNrVG9Ub3BCdXR0b24gZnJvbSBcIkAvY29tcG9uZW50cy9iYWNrVG90b3AuanN4XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcbiAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdsYXlvdXRTdHlsZSc+XG4gICAgICAgICAgPGhlYWRlcj5cbiAgICAgICAgICAgICAgPEJhY2tncm91bmRPdmVybGF5Lz5cbiAgICAgICAgICA8L2hlYWRlcj5cbiAgICAgICAgICA8bWFpbj48QmFja1RvVG9wQnV0dG9uLz48L21haW4+XG4gICAgICAgICAgPE1lbnUvPlxuICAgICAgICAgIDxMb2dvLz5cbiAgICAgICAgICA8R2V0QnJlYWRjcnVtYnMvPlxuICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cblxuICAgICAgPC9kaXY+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiTWVudSIsIkxvZ28iLCJCYWNrZ3JvdW5kT3ZlcmxheSIsIkdldEJyZWFkY3J1bWJzIiwiQmFja1RvVG9wQnV0dG9uIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwiZGl2IiwiY2xhc3NOYW1lIiwiaGVhZGVyIiwibWFpbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.jsx\n");

/***/ }),

/***/ "./pages/_document.jsx":
/*!*****************************!*\
  !*** ./pages/_document.jsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Document)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/document */ \"./node_modules/next/document.js\");\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Document() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {\n        lang: \"en\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {}, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_document.jsx\",\n                lineNumber: 6,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}, void 0, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_document.jsx\",\n                        lineNumber: 8,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {}, void 0, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_document.jsx\",\n                        lineNumber: 9,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_document.jsx\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\_document.jsx\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fZG9jdW1lbnQuanN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUE2RDtBQUU5QyxTQUFTSTtJQUN0QixxQkFDRSw4REFBQ0osK0NBQUlBO1FBQUNLLE1BQUs7OzBCQUNULDhEQUFDSiwrQ0FBSUE7Ozs7OzBCQUNMLDhEQUFDSzs7a0NBQ0MsOERBQUNKLCtDQUFJQTs7Ozs7a0NBQ0wsOERBQUNDLHFEQUFVQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJbkIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYWI3Ly4vcGFnZXMvX2RvY3VtZW50LmpzeD9mODZlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEh0bWwsIEhlYWQsIE1haW4sIE5leHRTY3JpcHQgfSBmcm9tIFwibmV4dC9kb2N1bWVudFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEb2N1bWVudCgpIHtcbiAgcmV0dXJuIChcbiAgICA8SHRtbCBsYW5nPVwiZW5cIj5cbiAgICAgIDxIZWFkIC8+XG4gICAgICA8Ym9keT5cbiAgICAgICAgPE1haW4gLz5cbiAgICAgICAgPE5leHRTY3JpcHQgLz5cbiAgICAgIDwvYm9keT5cbiAgICA8L0h0bWw+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiSHRtbCIsIkhlYWQiLCJNYWluIiwiTmV4dFNjcmlwdCIsIkRvY3VtZW50IiwibGFuZyIsImJvZHkiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_document.jsx\n");

/***/ }),

/***/ "./pages/rockets/[id].jsx":
/*!********************************!*\
  !*** ./pages/rockets/[id].jsx ***!
  \********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ launch),\n/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ \"./node_modules/next/image.js\");\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _public_img_No_image_jpg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/public/img/No_image.jpg */ \"./public/img/No_image.jpg\");\n/* harmony import */ var _barrel_optimize_names_Button_Card_CardContent_Typography_mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Card,CardContent,Typography!=!@mui/material */ \"__barrel_optimize__?names=Button,Card,CardContent,Typography!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var _components_renderObject_jsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/renderObject.jsx */ \"./components/renderObject.jsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);\n/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! framer-motion */ \"framer-motion\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__, _components_renderObject_jsx__WEBPACK_IMPORTED_MODULE_5__, framer_motion__WEBPACK_IMPORTED_MODULE_7__]);\n([axios__WEBPACK_IMPORTED_MODULE_1__, _components_renderObject_jsx__WEBPACK_IMPORTED_MODULE_5__, framer_motion__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\n\nfunction launch({ data }) {\n    const [expandedKeys, setExpandedKeys] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});\n    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);\n    const toggleExpandKey = (path)=>{\n        setExpandedKeys((prev)=>({\n                ...prev,\n                [path]: !prev[path]\n            }));\n    };\n    const openInNewTab = (url)=>{\n        window.open(url, \"_blank\", \"noopener,noreferrer\");\n    };\n    if (loading) {\n        return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Card_CardContent_Typography_mui_material__WEBPACK_IMPORTED_MODULE_8__.Typography, {\n            variant: \"h4\",\n            align: \"center\",\n            children: \"Loading...\"\n        }, void 0, false, {\n            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n            lineNumber: 25,\n            columnNumber: 16\n        }, this);\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"title\", {\n                    children: data.name\n                }, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                    lineNumber: 31,\n                    columnNumber: 17\n                }, this)\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                lineNumber: 30,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n                className: \"flex flex-col items-center justify-center min-h-screen p-10 bg-gray-100\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"max-w-4xl w-full bg-white rounded-lg shadow-lg overflow-hidden\",\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Card_CardContent_Typography_mui_material__WEBPACK_IMPORTED_MODULE_8__.Card, {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Card_CardContent_Typography_mui_material__WEBPACK_IMPORTED_MODULE_8__.CardContent, {\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(framer_motion__WEBPACK_IMPORTED_MODULE_7__.motion.div, {\n                                initial: {\n                                    opacity: 0,\n                                    y: 20\n                                },\n                                animate: {\n                                    opacity: 1,\n                                    y: 0\n                                },\n                                transition: {\n                                    duration: 0.5\n                                },\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                    className: \"grid grid-cols-1 md:grid-cols-2 gap-5\",\n                                    children: [\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                            className: \"relative h-80 md:h-auto flex items-center justify-center\",\n                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {\n                                                src: data.flickr_images ? data.flickr_images[0] : _public_img_No_image_jpg__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n                                                layout: \"fill\",\n                                                objectFit: \"contain\",\n                                                alt: data.name,\n                                                className: \"rounded-t-lg\"\n                                            }, void 0, false, {\n                                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                                                lineNumber: 44,\n                                                columnNumber: 41\n                                            }, this)\n                                        }, void 0, false, {\n                                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                                            lineNumber: 43,\n                                            columnNumber: 37\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                            className: \"flex flex-col justify-between\",\n                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                                children: [\n                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Card_CardContent_Typography_mui_material__WEBPACK_IMPORTED_MODULE_8__.Typography, {\n                                                        gutterBottom: true,\n                                                        variant: \"h5\",\n                                                        component: \"div\",\n                                                        children: data.name\n                                                    }, void 0, false, {\n                                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                                                        lineNumber: 54,\n                                                        columnNumber: 45\n                                                    }, this),\n                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_renderObject_jsx__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {\n                                                        obj: data,\n                                                        toggleExpandKey: toggleExpandKey,\n                                                        expandedKeys: expandedKeys\n                                                    }, void 0, false, {\n                                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                                                        lineNumber: 57,\n                                                        columnNumber: 45\n                                                    }, this),\n                                                    data.wikipedia && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                                        className: \"flex justify-center\",\n                                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Card_CardContent_Typography_mui_material__WEBPACK_IMPORTED_MODULE_8__.Button, {\n                                                            variant: \"contained\",\n                                                            onClick: ()=>openInNewTab(data.wikipedia),\n                                                            className: \"mt-4\",\n                                                            children: \"Read Wikipedia\"\n                                                        }, void 0, false, {\n                                                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                                                            lineNumber: 61,\n                                                            columnNumber: 53\n                                                        }, this)\n                                                    }, void 0, false, {\n                                                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                                                        lineNumber: 60,\n                                                        columnNumber: 49\n                                                    }, this)\n                                                ]\n                                            }, void 0, true, {\n                                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                                                lineNumber: 53,\n                                                columnNumber: 41\n                                            }, this)\n                                        }, void 0, false, {\n                                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                                            lineNumber: 52,\n                                            columnNumber: 37\n                                        }, this)\n                                    ]\n                                }, void 0, true, {\n                                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                                    lineNumber: 42,\n                                    columnNumber: 33\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                                lineNumber: 37,\n                                columnNumber: 29\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                            lineNumber: 36,\n                            columnNumber: 25\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                        lineNumber: 35,\n                        columnNumber: 21\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                    lineNumber: 34,\n                    columnNumber: 17\n                }, this)\n            }, void 0, false, {\n                fileName: \"E:\\\\CS\\\\554\\\\hw\\\\hw7\\\\pages\\\\rockets\\\\[id].jsx\",\n                lineNumber: 33,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true);\n}\nasync function getStaticProps({ params }) {\n    const data = await getRocketById(params.id);\n    return {\n        props: {\n            data\n        },\n        revalidate: 86400\n    };\n}\nasync function getRocketById(id) {\n    const { data } = await axios__WEBPACK_IMPORTED_MODULE_1__[\"default\"].get(\"https://api.spacexdata.com/v4/rockets/\" + id);\n    return data;\n}\nasync function getRockets() {\n    const { data } = await axios__WEBPACK_IMPORTED_MODULE_1__[\"default\"].get(\"https://api.spacexdata.com/v4/rockets\");\n    return data;\n}\nasync function getStaticPaths() {\n    const data = await getRockets();\n    const paths = data.map((rocket)=>{\n        return {\n            params: {\n                id: rocket.id.toString()\n            }\n        };\n    });\n    return {\n        paths: paths,\n        fallback: false\n    };\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9yb2NrZXRzL1tpZF0uanN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQTBCO0FBQ0s7QUFDRjtBQUNnQjtBQUN1QjtBQUNYO0FBQzFCO0FBQ007QUFFdEIsU0FBU1csT0FBTyxFQUFDQyxJQUFJLEVBQUM7SUFDakMsTUFBTSxDQUFDQyxjQUFjQyxnQkFBZ0IsR0FBR0wsK0NBQVFBLENBQUMsQ0FBQztJQUNsRCxNQUFNLENBQUNNLFNBQVNDLFdBQVcsR0FBR1AsK0NBQVFBLENBQUM7SUFDdkMsTUFBTVEsa0JBQWtCLENBQUNDO1FBQ3JCSixnQkFBZ0JLLENBQUFBLE9BQVM7Z0JBQ3JCLEdBQUdBLElBQUk7Z0JBQ1AsQ0FBQ0QsS0FBSyxFQUFFLENBQUNDLElBQUksQ0FBQ0QsS0FBSztZQUN2QjtJQUNKO0lBRUEsTUFBTUUsZUFBZSxDQUFDQztRQUNsQkMsT0FBT0MsSUFBSSxDQUFDRixLQUFLLFVBQVU7SUFDL0I7SUFFQSxJQUFJTixTQUFTO1FBQ1QscUJBQU8sOERBQUNSLDhHQUFVQTtZQUFDaUIsU0FBUTtZQUFLQyxPQUFNO3NCQUFTOzs7Ozs7SUFDbkQ7SUFFQSxxQkFDSTs7MEJBQ0ksOERBQUN2QixrREFBSUE7MEJBQ0QsNEVBQUN3Qjs4QkFBT2QsS0FBS2UsSUFBSTs7Ozs7Ozs7Ozs7MEJBRXJCLDhEQUFDQztnQkFBS0MsV0FBVTswQkFDWiw0RUFBQ0M7b0JBQUlELFdBQVU7OEJBQ1gsNEVBQUN4Qix3R0FBSUE7a0NBQ0QsNEVBQUNDLCtHQUFXQTtzQ0FDUiw0RUFBQ0ksaURBQU1BLENBQUNvQixHQUFHO2dDQUNQQyxTQUFTO29DQUFDQyxTQUFTO29DQUFHQyxHQUFHO2dDQUFFO2dDQUMzQkMsU0FBUztvQ0FBQ0YsU0FBUztvQ0FBR0MsR0FBRztnQ0FBQztnQ0FDMUJFLFlBQVk7b0NBQUNDLFVBQVU7Z0NBQUc7MENBRTFCLDRFQUFDTjtvQ0FBSUQsV0FBVTs7c0RBQ1gsOERBQUNDOzRDQUFJRCxXQUFVO3NEQUNYLDRFQUFDNUIsbURBQUtBO2dEQUNGb0MsS0FBS3pCLEtBQUswQixhQUFhLEdBQUcxQixLQUFLMEIsYUFBYSxDQUFDLEVBQUUsR0FBR25DLGdFQUFLQTtnREFDdkRvQyxRQUFPO2dEQUNQQyxXQUFVO2dEQUNWQyxLQUFLN0IsS0FBS2UsSUFBSTtnREFDZEUsV0FBVTs7Ozs7Ozs7Ozs7c0RBR2xCLDhEQUFDQzs0Q0FBSUQsV0FBVTtzREFDWCw0RUFBQ0M7O2tFQUNHLDhEQUFDdkIsOEdBQVVBO3dEQUFDbUMsWUFBWTt3REFBQ2xCLFNBQVE7d0RBQUttQixXQUFVO2tFQUMzQy9CLEtBQUtlLElBQUk7Ozs7OztrRUFFZCw4REFBQ25CLG9FQUFZQTt3REFBQ29DLEtBQUtoQzt3REFBTUssaUJBQWlCQTt3REFDNUJKLGNBQWNBOzs7Ozs7b0RBQzNCRCxLQUFLaUMsU0FBUyxrQkFDWCw4REFBQ2Y7d0RBQUlELFdBQVU7a0VBQ1gsNEVBQUN6QiwwR0FBTUE7NERBQ0hvQixTQUFROzREQUNSc0IsU0FBUyxJQUFNMUIsYUFBYVIsS0FBS2lDLFNBQVM7NERBQzFDaEIsV0FBVTtzRUFDYjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWVyRDtBQUdPLGVBQWVrQixlQUFlLEVBQ0lDLE1BQU0sRUFDVDtJQUNsQyxNQUFNcEMsT0FBTyxNQUFNcUMsY0FBY0QsT0FBT0UsRUFBRTtJQUMxQyxPQUFPO1FBQ0hDLE9BQU87WUFBQ3ZDO1FBQUk7UUFDWndDLFlBQVk7SUFDaEI7QUFDSjtBQUVBLGVBQWVILGNBQWNDLEVBQUU7SUFDM0IsTUFBTSxFQUFDdEMsSUFBSSxFQUFDLEdBQUcsTUFBTVosaURBQVMsQ0FBQywyQ0FBMkNrRDtJQUMxRSxPQUFPdEM7QUFDWDtBQUVBLGVBQWUwQztJQUNYLE1BQU0sRUFBQzFDLElBQUksRUFBQyxHQUFHLE1BQU1aLGlEQUFTLENBQUM7SUFDL0IsT0FBT1k7QUFDWDtBQUVPLGVBQWUyQztJQUNsQixNQUFNM0MsT0FBTyxNQUFNMEM7SUFDbkIsTUFBTUUsUUFBUTVDLEtBQUs2QyxHQUFHLENBQUMsQ0FBQ0M7UUFDcEIsT0FBTztZQUNIVixRQUFRO2dCQUFDRSxJQUFJUSxPQUFPUixFQUFFLENBQUNTLFFBQVE7WUFBRTtRQUNyQztJQUNKO0lBRUEsT0FBTztRQUNISCxPQUFPQTtRQUNQSSxVQUFVO0lBQ2Q7QUFDSiIsInNvdXJjZXMiOlsid2VicGFjazovL2xhYjcvLi9wYWdlcy9yb2NrZXRzL1tpZF0uanN4Pzg5MTYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XHJcbmltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCc7XHJcbmltcG9ydCBub0ltZyBmcm9tICdAL3B1YmxpYy9pbWcvTm9faW1hZ2UuanBnJ1xyXG5pbXBvcnQge0J1dHRvbiwgQ2FyZCwgQ2FyZENvbnRlbnQsIFR5cG9ncmFwaHl9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCBSZW5kZXJPYmplY3QgZnJvbSBcIkAvY29tcG9uZW50cy9yZW5kZXJPYmplY3QuanN4XCI7XHJcbmltcG9ydCB7dXNlU3RhdGV9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge21vdGlvbn0gZnJvbSBcImZyYW1lci1tb3Rpb25cIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGxhdW5jaCh7ZGF0YX0pIHtcclxuICAgIGNvbnN0IFtleHBhbmRlZEtleXMsIHNldEV4cGFuZGVkS2V5c10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCB0b2dnbGVFeHBhbmRLZXkgPSAocGF0aCkgPT4ge1xyXG4gICAgICAgIHNldEV4cGFuZGVkS2V5cyhwcmV2ID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgIFtwYXRoXTogIXByZXZbcGF0aF0sXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBvcGVuSW5OZXdUYWIgPSAodXJsKSA9PiB7XHJcbiAgICAgICAgd2luZG93Lm9wZW4odXJsLCAnX2JsYW5rJywgJ25vb3BlbmVyLG5vcmVmZXJyZXInKTtcclxuICAgIH07XHJcblxyXG4gICAgaWYgKGxvYWRpbmcpIHtcclxuICAgICAgICByZXR1cm4gPFR5cG9ncmFwaHkgdmFyaWFudD1cImg0XCIgYWxpZ249XCJjZW50ZXJcIj5Mb2FkaW5nLi4uPC9UeXBvZ3JhcGh5PjtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxIZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRpdGxlPntkYXRhLm5hbWV9PC90aXRsZT5cclxuICAgICAgICAgICAgPC9IZWFkPlxyXG4gICAgICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1zY3JlZW4gcC0xMCBiZy1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy00eGwgdy1mdWxsIGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LWxnIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bW90aW9uLmRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluaXRpYWw9e3tvcGFjaXR5OiAwLCB5OiAyMH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5pbWF0ZT17e29wYWNpdHk6IDEsIHk6IDB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3tkdXJhdGlvbjogMC41fX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLTgwIG1kOmgtYXV0byBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtkYXRhLmZsaWNrcl9pbWFnZXMgPyBkYXRhLmZsaWNrcl9pbWFnZXNbMF0gOiBub0ltZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXlvdXQ9XCJmaWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmplY3RGaXQ9XCJjb250YWluXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2RhdGEubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgZ3V0dGVyQm90dG9tIHZhcmlhbnQ9XCJoNVwiIGNvbXBvbmVudD1cImRpdlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGF0YS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmVuZGVyT2JqZWN0IG9iaj17ZGF0YX0gdG9nZ2xlRXhwYW5kS2V5PXt0b2dnbGVFeHBhbmRLZXl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBhbmRlZEtleXM9e2V4cGFuZGVkS2V5c30vPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkYXRhLndpa2lwZWRpYSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5Jbk5ld1RhYihkYXRhLndpa2lwZWRpYSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVhZCBXaWtpcGVkaWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmRDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L21haW4+XHJcbiAgICAgICAgPC8+XHJcbiAgICApO1xyXG59XHJcblxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN0YXRpY1Byb3BzKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pIHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRSb2NrZXRCeUlkKHBhcmFtcy5pZCk7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIHByb3BzOiB7ZGF0YX0sXHJcbiAgICAgICAgcmV2YWxpZGF0ZTogODY0MDBcclxuICAgIH07XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldFJvY2tldEJ5SWQoaWQpIHtcclxuICAgIGNvbnN0IHtkYXRhfSA9IGF3YWl0IGF4aW9zLmdldCgnaHR0cHM6Ly9hcGkuc3BhY2V4ZGF0YS5jb20vdjQvcm9ja2V0cy8nICsgaWQpO1xyXG4gICAgcmV0dXJuIGRhdGE7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldFJvY2tldHMoKSB7XHJcbiAgICBjb25zdCB7ZGF0YX0gPSBhd2FpdCBheGlvcy5nZXQoJ2h0dHBzOi8vYXBpLnNwYWNleGRhdGEuY29tL3Y0L3JvY2tldHMnKTtcclxuICAgIHJldHVybiBkYXRhO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3RhdGljUGF0aHMoKSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2V0Um9ja2V0cygpO1xyXG4gICAgY29uc3QgcGF0aHMgPSBkYXRhLm1hcCgocm9ja2V0KSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgcGFyYW1zOiB7aWQ6IHJvY2tldC5pZC50b1N0cmluZygpfVxyXG4gICAgICAgIH07XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIHBhdGhzOiBwYXRocyxcclxuICAgICAgICBmYWxsYmFjazogZmFsc2VcclxuICAgIH07XHJcbn0iXSwibmFtZXMiOlsiYXhpb3MiLCJJbWFnZSIsIkhlYWQiLCJub0ltZyIsIkJ1dHRvbiIsIkNhcmQiLCJDYXJkQ29udGVudCIsIlR5cG9ncmFwaHkiLCJSZW5kZXJPYmplY3QiLCJ1c2VTdGF0ZSIsIm1vdGlvbiIsImxhdW5jaCIsImRhdGEiLCJleHBhbmRlZEtleXMiLCJzZXRFeHBhbmRlZEtleXMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInRvZ2dsZUV4cGFuZEtleSIsInBhdGgiLCJwcmV2Iiwib3BlbkluTmV3VGFiIiwidXJsIiwid2luZG93Iiwib3BlbiIsInZhcmlhbnQiLCJhbGlnbiIsInRpdGxlIiwibmFtZSIsIm1haW4iLCJjbGFzc05hbWUiLCJkaXYiLCJpbml0aWFsIiwib3BhY2l0eSIsInkiLCJhbmltYXRlIiwidHJhbnNpdGlvbiIsImR1cmF0aW9uIiwic3JjIiwiZmxpY2tyX2ltYWdlcyIsImxheW91dCIsIm9iamVjdEZpdCIsImFsdCIsImd1dHRlckJvdHRvbSIsImNvbXBvbmVudCIsIm9iaiIsIndpa2lwZWRpYSIsIm9uQ2xpY2siLCJnZXRTdGF0aWNQcm9wcyIsInBhcmFtcyIsImdldFJvY2tldEJ5SWQiLCJpZCIsInByb3BzIiwicmV2YWxpZGF0ZSIsImdldCIsImdldFJvY2tldHMiLCJnZXRTdGF0aWNQYXRocyIsInBhdGhzIiwibWFwIiwicm9ja2V0IiwidG9TdHJpbmciLCJmYWxsYmFjayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/rockets/[id].jsx\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@mui/base/ClassNameGenerator":
/*!***********************************************!*\
  !*** external "@mui/base/ClassNameGenerator" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/base/ClassNameGenerator");

/***/ }),

/***/ "@mui/base/utils":
/*!**********************************!*\
  !*** external "@mui/base/utils" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/base/utils");

/***/ }),

/***/ "@mui/icons-material/ArrowUpward":
/*!**************************************************!*\
  !*** external "@mui/icons-material/ArrowUpward" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ArrowUpward");

/***/ }),

/***/ "@mui/icons-material/NavigateNext":
/*!***************************************************!*\
  !*** external "@mui/icons-material/NavigateNext" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/NavigateNext");

/***/ }),

/***/ "@mui/material/utils":
/*!**************************************!*\
  !*** external "@mui/material/utils" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/utils");

/***/ }),

/***/ "@mui/system":
/*!******************************!*\
  !*** external "@mui/system" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system");

/***/ }),

/***/ "@mui/system/colorManipulator":
/*!***********************************************!*\
  !*** external "@mui/system/colorManipulator" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/colorManipulator");

/***/ }),

/***/ "@mui/system/createStyled":
/*!*******************************************!*\
  !*** external "@mui/system/createStyled" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/createStyled");

/***/ }),

/***/ "@mui/system/createTheme":
/*!******************************************!*\
  !*** external "@mui/system/createTheme" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/createTheme");

/***/ }),

/***/ "@mui/system/styleFunctionSx":
/*!**********************************************!*\
  !*** external "@mui/system/styleFunctionSx" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/styleFunctionSx");

/***/ }),

/***/ "@mui/system/useThemeProps":
/*!********************************************!*\
  !*** external "@mui/system/useThemeProps" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/useThemeProps");

/***/ }),

/***/ "@mui/utils/capitalize":
/*!****************************************!*\
  !*** external "@mui/utils/capitalize" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/capitalize");

/***/ }),

/***/ "@mui/utils/chainPropTypes":
/*!********************************************!*\
  !*** external "@mui/utils/chainPropTypes" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/chainPropTypes");

/***/ }),

/***/ "@mui/utils/composeClasses":
/*!********************************************!*\
  !*** external "@mui/utils/composeClasses" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/composeClasses");

/***/ }),

/***/ "@mui/utils/createChainedFunction":
/*!***************************************************!*\
  !*** external "@mui/utils/createChainedFunction" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/createChainedFunction");

/***/ }),

/***/ "@mui/utils/debounce":
/*!**************************************!*\
  !*** external "@mui/utils/debounce" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/debounce");

/***/ }),

/***/ "@mui/utils/deepmerge":
/*!***************************************!*\
  !*** external "@mui/utils/deepmerge" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/deepmerge");

/***/ }),

/***/ "@mui/utils/deprecatedPropType":
/*!************************************************!*\
  !*** external "@mui/utils/deprecatedPropType" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/deprecatedPropType");

/***/ }),

/***/ "@mui/utils/elementAcceptingRef":
/*!*************************************************!*\
  !*** external "@mui/utils/elementAcceptingRef" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/elementAcceptingRef");

/***/ }),

/***/ "@mui/utils/elementTypeAcceptingRef":
/*!*****************************************************!*\
  !*** external "@mui/utils/elementTypeAcceptingRef" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/elementTypeAcceptingRef");

/***/ }),

/***/ "@mui/utils/formatMuiErrorMessage":
/*!***************************************************!*\
  !*** external "@mui/utils/formatMuiErrorMessage" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/formatMuiErrorMessage");

/***/ }),

/***/ "@mui/utils/generateUtilityClass":
/*!**************************************************!*\
  !*** external "@mui/utils/generateUtilityClass" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/generateUtilityClass");

/***/ }),

/***/ "@mui/utils/generateUtilityClasses":
/*!****************************************************!*\
  !*** external "@mui/utils/generateUtilityClasses" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/generateUtilityClasses");

/***/ }),

/***/ "@mui/utils/integerPropType":
/*!*********************************************!*\
  !*** external "@mui/utils/integerPropType" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/integerPropType");

/***/ }),

/***/ "@mui/utils/isMuiElement":
/*!******************************************!*\
  !*** external "@mui/utils/isMuiElement" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/isMuiElement");

/***/ }),

/***/ "@mui/utils/ownerDocument":
/*!*******************************************!*\
  !*** external "@mui/utils/ownerDocument" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/ownerDocument");

/***/ }),

/***/ "@mui/utils/ownerWindow":
/*!*****************************************!*\
  !*** external "@mui/utils/ownerWindow" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/ownerWindow");

/***/ }),

/***/ "@mui/utils/refType":
/*!*************************************!*\
  !*** external "@mui/utils/refType" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/refType");

/***/ }),

/***/ "@mui/utils/requirePropFactory":
/*!************************************************!*\
  !*** external "@mui/utils/requirePropFactory" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/requirePropFactory");

/***/ }),

/***/ "@mui/utils/resolveProps":
/*!******************************************!*\
  !*** external "@mui/utils/resolveProps" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/resolveProps");

/***/ }),

/***/ "@mui/utils/setRef":
/*!************************************!*\
  !*** external "@mui/utils/setRef" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/setRef");

/***/ }),

/***/ "@mui/utils/unsupportedProp":
/*!*********************************************!*\
  !*** external "@mui/utils/unsupportedProp" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/unsupportedProp");

/***/ }),

/***/ "@mui/utils/useControlled":
/*!*******************************************!*\
  !*** external "@mui/utils/useControlled" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useControlled");

/***/ }),

/***/ "@mui/utils/useEnhancedEffect":
/*!***********************************************!*\
  !*** external "@mui/utils/useEnhancedEffect" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useEnhancedEffect");

/***/ }),

/***/ "@mui/utils/useEventCallback":
/*!**********************************************!*\
  !*** external "@mui/utils/useEventCallback" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useEventCallback");

/***/ }),

/***/ "@mui/utils/useForkRef":
/*!****************************************!*\
  !*** external "@mui/utils/useForkRef" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useForkRef");

/***/ }),

/***/ "@mui/utils/useId":
/*!***********************************!*\
  !*** external "@mui/utils/useId" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useId");

/***/ }),

/***/ "@mui/utils/useIsFocusVisible":
/*!***********************************************!*\
  !*** external "@mui/utils/useIsFocusVisible" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useIsFocusVisible");

/***/ }),

/***/ "@mui/utils/useTimeout":
/*!****************************************!*\
  !*** external "@mui/utils/useTimeout" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useTimeout");

/***/ }),

/***/ "clsx":
/*!***********************!*\
  !*** external "clsx" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("clsx");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-is":
/*!***************************!*\
  !*** external "react-is" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-is");

/***/ }),

/***/ "react-transition-group":
/*!*****************************************!*\
  !*** external "react-transition-group" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ "framer-motion":
/*!********************************!*\
  !*** external "framer-motion" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = import("framer-motion");;

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/@mui","vendor-chunks/react-icons","vendor-chunks/@babel"], () => (__webpack_exec__("./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Frockets%2F%5Bid%5D&preferredRegion=&absolutePagePath=.%2Fpages%5Crockets%5C%5Bid%5D.jsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();